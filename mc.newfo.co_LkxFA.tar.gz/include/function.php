<?php
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect($u){ header("Location: $u"); exit; }
function alert($m,$u=''){ echo "<script>alert('".addslashes($m)."');".($u?"location.href='$u';":"")."</script>"; exit; }
function fmtTime($t){ return $t ? date('Y-m-d H:i',$t) : '-'; }
function paginate($total,$page,$size,$url){
    $tp=ceil($total/$size); $h='<div class="pagination">';
    for($i=1;$i<=$tp;$i++){ $a=$i==$page?' class="active"':''; $h.="<a href=\"{$url}&page={$i}\"$a>$i</a>"; }
    return $h.'</div>';
}
function executeTask($userId,$taskKey){
    $task=DB::one("SELECT * FROM task_config WHERE task_key=? AND status=1",[$taskKey]);
    if(!$task) return ['success'=>false,'msg'=>'任务不存在','integral'=>0];
    if($task['max_times']>0){
        $c=DB::one("SELECT COUNT(*) c FROM user_task_log WHERE user_id=? AND task_id=? AND created_at>=?",[$userId,$task['id'],strtotime('today')])['c'];
        if($c>=$task['max_times']) return ['success'=>false,'msg'=>'今日已完成','integral'=>0];
    }
    DB::conn()->beginTransaction();
    try{
        DB::exec("UPDATE user SET integral=integral+? WHERE id=?",[$task['integral'],$userId]);
        DB::insert("INSERT INTO integral_log (user_id,amount,reason,task_id,created_at) VALUES (?,?,?,?,?)",[$userId,$task['integral'],$task['task_name'],$task['id'],time()]);
        DB::insert("INSERT INTO user_task_log (user_id,task_id,integral,created_at) VALUES (?,?,?,?)",[$userId,$task['id'],$task['integral'],time()]);
        DB::conn()->commit();
        return ['success'=>true,'msg'=>'完成','integral'=>$task['integral']];
    }catch(Exception $e){ DB::conn()->rollBack(); return ['success'=>false,'msg'=>$e->getMessage(),'integral'=>0]; }
}
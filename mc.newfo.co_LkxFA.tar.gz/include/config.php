<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'nightride');
define('DB_USER', 'nightride');
define('DB_PASS', 'nightride');
define('SITE_NAME', 'NIGHT RIDE 车音坊');
define('UPLOAD_DIR', __DIR__ . '/../uploads/audio/');
define('UPLOAD_URL', '/uploads/audio/');
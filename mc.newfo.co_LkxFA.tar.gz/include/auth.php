<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/db.php';
require_once __DIR__.'/function.php';
session_start();
if(empty($_SESSION['admin_id'])) redirect('login.php');
<?php
class DB {
    private static $pdo = null;
    public static function conn() {
        if (self::$pdo === null) {
            try {
                self::$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
            } catch (PDOException $e) { die('DB Error: '.$e->getMessage()); }
        }
        return self::$pdo;
    }
    public static function query($sql, $p=[]) { $s=self::conn()->prepare($sql); $s->execute($p); return $s->fetchAll(); }
    public static function one($sql, $p=[])   { $s=self::conn()->prepare($sql); $s->execute($p); return $s->fetch(); }
    public static function exec($sql, $p=[])  { $s=self::conn()->prepare($sql); $s->execute($p); return $s->rowCount(); }
    public static function insert($sql, $p=[]){ self::exec($sql,$p); return self::conn()->lastInsertId(); }
}
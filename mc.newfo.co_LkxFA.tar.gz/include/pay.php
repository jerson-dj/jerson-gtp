<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/db.php';
require_once __DIR__.'/function.php';

// 加载 Composer 自动加载
$autoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

/**
 * 读取所有支付配置
 */
function pay_config() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    foreach (DB::query("SELECT * FROM setting") as $row) {
        $cache[$row['key']] = $row['value'];
    }
    return $cache;
}

/**
 * 生成唯一订单号
 */
function pay_gen_order_no() {
    return date('YmdHis') . rand(100000, 999999);
}

/**
 * 支付成功后发放积分/VIP
 */
function pay_grant($order) {
    if ($order['pay_status'] === 'paid') {
        return ['success' => false, 'msg' => '订单已处理'];
    }

    DB::conn()->beginTransaction();
    try {
        if ($order['type'] === 'integral') {
            DB::exec("UPDATE user SET integral=integral+?, updated_at=? WHERE id=?",
                [$order['integral_amount'], time(), $order['user_id']]);
            DB::insert("INSERT INTO integral_log (user_id, amount, reason, created_at) VALUES (?,?,?,?)",
                [$order['user_id'], $order['integral_amount'], '在线充值（订单'.$order['order_no'].'）', time()]);
            DB::insert("INSERT INTO recharge_log (user_id, type, amount, remark, created_at) VALUES (?,'integral',?,?,?)",
                [$order['user_id'], $order['integral_amount'], '在线充值：'.$order['order_no'], time()]);
        } else {
            $plan = DB::one("SELECT * FROM vip_plan WHERE id=?", [$order['vip_plan_id']]);
            if ($plan) {
                $user = DB::one("SELECT vip_expire FROM user WHERE id=?", [$order['user_id']]);
                $expire = max(time(), (int)$user['vip_expire']) + $plan['days'] * 86400;
                DB::exec("UPDATE user SET vip_level=?, vip_expire=?, updated_at=? WHERE id=?",
                    [$plan['level'], $expire, time(), $order['user_id']]);
                DB::insert("INSERT INTO recharge_log (user_id, type, amount, remark, created_at) VALUES (?,'vip',?,?,?)",
                    [$order['user_id'], $plan['days'], '在线开通：'.$plan['name'], time()]);
            }
        }

        DB::exec("UPDATE recharge_order SET status=1, pay_status='paid', pay_time=?, reviewed_at=? WHERE id=?",
            [time(), time(), $order['id']]);

        DB::conn()->commit();
        return ['success' => true, 'msg' => '发放成功'];
    } catch (Exception $e) {
        DB::conn()->rollBack();
        return ['success' => false, 'msg' => $e->getMessage()];
    }
}
<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';
session_start();

// 已登录则同步用户积分
if (!empty($_SESSION['user_id'])) {
    $currentUser = DB::one("SELECT integral, nickname FROM user WHERE id=?", [$_SESSION['user_id']]);
    if ($currentUser) {
        $_SESSION['user_integral'] = $currentUser['integral'];
        $_SESSION['user_name'] = $currentUser['nickname'];
    }
}

$audios = DB::query("SELECT * FROM audio WHERE status=1 ORDER BY sort, id DESC LIMIT 20");
$posts  = DB::query("SELECT a.*, c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id WHERE a.status=1 ORDER BY a.is_top DESC, a.id DESC LIMIT 10");
$cates  = DB::query("SELECT * FROM category ORDER BY sort ASC");
$firstAudio = !empty($audios) ? $audios[0] : null;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#080a12">
    <title>NIGHT RIDE | 车载DJ & 沉浸式汽车美感空间</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-neon: #00f3ff;
            --secondary-neon: #ff0055;
            --bg-dark: #080a12;
            --glass-bg: rgba(18, 22, 36, 0.65);
            --glass-border: rgba(255, 255, 255, 0.12);
            --text-main: #f0f3f8;
            --text-sub: #8a99ad;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'PingFang SC', 'Microsoft YaHei', -apple-system, sans-serif; user-select: none; -webkit-tap-highlight-color: transparent; }
        input, textarea { user-select: text; -webkit-user-select: text; }
        body, html { width: 100%; height: 100%; overflow: hidden; background-color: var(--bg-dark); color: var(--text-main); }

        #viewport-container { position: relative; width: 100vw; height: 100vh; overflow: hidden; }
        #canvas-layer { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; display: block; }
        .cockpit-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: url('https://images.unsplash.com/photo-1508253730651-e5ace80a7025?auto=format&fit=crop&w=1920&q=80') center/cover no-repeat; z-index: 2; opacity: 0.35; mix-blend-mode: lighten; filter: contrast(110%) brightness(90%); pointer-events: none; }
        .vignette-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: radial-gradient(circle at center, transparent 30%, rgba(8, 10, 18, 0.85) 90%); z-index: 3; pointer-events: none; }

        /* ===== 顶部区域 ===== */
        .top-header { position: absolute; top: 15px; left: 0; width: 100%; z-index: 20; display: flex; justify-content: space-between; align-items: center; padding: 0 5%; pointer-events: none; }
        .brand-logo { display: flex; align-items: center; gap: 10px; font-size: 20px; font-weight: 700; letter-spacing: 1px; color: #fff; text-shadow: 0 0 10px rgba(0, 243, 255, 0.5); pointer-events: auto; }
        .brand-logo i { color: var(--primary-neon); text-shadow: 0 0 15px var(--primary-neon); }
        .top-search { position: absolute; left: 50%; transform: translateX(-50%); width: 40%; max-width: 500px; height: 40px; background: var(--glass-bg); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid var(--glass-border); border-radius: 20px; display: flex; align-items: center; padding: 0 16px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); pointer-events: auto; }
        .top-search i { color: var(--text-sub); font-size: 13px; margin-right: 8px; }
        .top-search input { width: 100%; background: transparent; border: none; color: #fff; outline: none; font-size: 13px; }
        .top-search input::placeholder { color: var(--text-sub); }
        .user-actions { display: flex; align-items: center; gap: 12px; pointer-events: auto; }
        .user-points-tag { background: linear-gradient(135deg, rgba(255, 0, 85, 0.2), rgba(0, 243, 255, 0.2)); border: 1px solid var(--glass-border); padding: 6px 16px; border-radius: 20px; font-size: 13px; color: var(--text-main); display: flex; align-items: center; gap: 8px; white-space: nowrap; }
        .user-points-tag span { color: var(--primary-neon); font-weight: bold; }
        .auth-btn { background: linear-gradient(90deg, var(--primary-neon), #0077ff); color: #000; border: none; border-radius: 20px; padding: 6px 18px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 10px rgba(0, 243, 255, 0.3); white-space: nowrap; text-decoration: none; display: inline-block; }
        .auth-btn:hover { box-shadow: 0 0 15px rgba(0, 243, 255, 0.6); transform: translateY(-1px); }
        .auth-btn.gray { background: #30363d; color: #c9d1d9; box-shadow: none; }
        .auth-btn.gray:hover { background: #3d444d; }

        /* ===== 导航栏 ===== */
        .navbar { position: absolute; top: 70px; left: 50%; transform: translateX(-50%); width: 90%; max-width: 1200px; height: 56px; background: transparent; border: none; box-shadow: none; z-index: 15; display: flex; align-items: center; justify-content: center; padding: 0 28px; }
        .nav-links { display: flex; gap: 28px; list-style: none; justify-content: center; flex-wrap: wrap; }
        .nav-links a { color: var(--text-sub); text-decoration: none; font-size: 17px; font-weight: 600; transition: all 0.3s ease; cursor: pointer; white-space: nowrap; padding: 4px 0; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.8); }
        .nav-links a:hover, .nav-links a.active { color: var(--primary-neon); text-shadow: 0 0 12px rgba(0, 243, 255, 0.8); }

        /* ===== 频谱显示区 ===== */
        .spectrum-area { position: absolute; top: 134px; left: 50%; transform: translateX(-50%); width: 90%; max-width: 1200px; height: 60px; background: transparent; border: none; box-shadow: none; z-index: 15; overflow: hidden; }
        #spectrum-canvas { width: 100%; height: 100%; display: block; }

        /* ===== 主内容区 ===== */
        .main-content { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 5; display: grid; grid-template-columns: 1fr 380px; padding: 250px 5% 80px 5%; gap: 40px; pointer-events: none; }
        .main-content * { pointer-events: auto; }
        .hero-section { display: flex; flex-direction: column; justify-content: flex-end; margin-bottom: 10px; }
        .hero-title { font-size: 44px; font-weight: 800; line-height: 1.2; margin-bottom: 16px; background: linear-gradient(180deg, #ffffff 0%, var(--text-sub) 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-shadow: 0 10px 20px rgba(0, 0, 0, 0.5); }
        .hero-subtitle { font-size: 15px; color: var(--text-sub); margin-bottom: 32px; max-width: 540px; line-height: 1.6; }

        /* 播放器卡片 */
        .dj-player-card { width: 100%; max-width: 540px; background: var(--glass-bg); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid var(--glass-border); border-radius: 20px; padding: 18px; display: flex; align-items: center; gap: 16px; box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4); }
        .album-cover { width: 70px; height: 70px; border-radius: 12px; background: url('https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=200&q=80') center/cover; position: relative; flex-shrink: 0; box-shadow: 0 0 15px rgba(0, 243, 255, 0.3); overflow: hidden; }
        .play-btn-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.4); border-radius: 12px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 22px; color: #fff; transition: all 0.3s; border: none; }
        .play-btn-overlay:hover { color: var(--primary-neon); background: rgba(0, 0, 0, 0.6); }
        .icon-toggle .fa-pause { display: none; }
        .icon-toggle.playing .fa-play { display: none; }
        .icon-toggle.playing .fa-pause { display: block; }
        .player-info { flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; }
        .track-name { font-size: 15px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .track-artist { font-size: 12px; color: var(--text-sub); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .badge-hq { font-size: 10px; padding: 2px 6px; background: var(--secondary-neon); color: #fff; border-radius: 4px; font-weight: bold; margin-left: 6px; vertical-align: middle; }
        .progress-wrapper { display: flex; align-items: center; gap: 8px; }
        .time-label { font-size: 11px; color: var(--text-sub); flex-shrink: 0; min-width: 34px; text-align: center; font-variant-numeric: tabular-nums; }
        .progress-bar-bg { flex-grow: 1; background: rgba(255, 255, 255, 0.1); height: 4px; border-radius: 2px; overflow: hidden; cursor: pointer; position: relative; }
        .progress-bar-bg::after { content: ''; position: absolute; inset: -12px 0; }
        .progress-bar-fill { width: 0%; background: linear-gradient(90deg, var(--primary-neon), var(--secondary-neon)); height: 100%; transition: width 0.1s linear; }
        .volume-control { display: flex; align-items: center; gap: 8px; color: var(--text-sub); font-size: 13px; flex-shrink: 0; padding-left: 10px; border-left: 1px solid rgba(255, 255, 255, 0.1); }
        .volume-control i { cursor: pointer; transition: color 0.2s; width: 18px; text-align: center; }
        .volume-control i:hover { color: #fff; }
        .volume-control input[type="range"] { width: 60px; accent-color: var(--primary-neon); cursor: pointer; }

        /* 侧边栏 */
        .sidebar-cards { display: flex; flex-direction: column; gap: 20px; justify-content: flex-end; margin-bottom: 10px; }
        .glass-card { background: var(--glass-bg); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid var(--glass-border); border-radius: 20px; padding: 24px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3); transition: transform 0.3s ease; }
        .glass-card:hover { transform: translateY(-5px); border-color: rgba(0, 243, 255, 0.4); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; gap: 8px; }
        .card-title { font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .card-title i { color: var(--primary-neon); }
        .card-desc { font-size: 13px; color: var(--text-sub); line-height: 1.5; margin-bottom: 18px; }
        .action-btn { width: 100%; padding: 12px; border: none; border-radius: 12px; background: linear-gradient(90deg, var(--primary-neon), #0077ff); color: #000; font-weight: 700; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.3s; box-shadow: 0 4px 15px rgba(0, 243, 255, 0.3); text-decoration: none; }
        .action-btn:hover { opacity: 0.9; box-shadow: 0 6px 20px rgba(0, 243, 255, 0.5); }

        /* 页脚 */
        .site-footer { position: absolute; bottom: 8px; left: 0; width: 100%; text-align: center; font-size: 11px; color: var(--text-sub); z-index: 20; pointer-events: none; line-height: 1.6; }
        .site-footer a { color: var(--text-sub); text-decoration: none; margin: 0 6px; transition: color 0.2s; pointer-events: auto; }
        .site-footer a:hover { color: var(--primary-neon); }
        .ambient-toggle { position: absolute; bottom: 50px; left: 50%; transform: translateX(-50%); z-index: 20; background: rgba(0, 0, 0, 0.5); border: 1px solid var(--glass-border); padding: 8px 18px; border-radius: 20px; font-size: 12px; color: var(--text-sub); cursor: pointer; backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); transition: all 0.3s; white-space: nowrap; }
        .ambient-toggle:hover { color: #fff; border-color: var(--primary-neon); }
        #viewport-container.saver .top-header, #viewport-container.saver .navbar, #viewport-container.saver .spectrum-area, #viewport-container.saver .main-content, #viewport-container.saver .site-footer, #viewport-container.saver .ambient-toggle { display: none; }

        /* ===== 手机端媒体查询 ===== */
        @media (max-width: 860px) {
            body, html { height: auto; min-height: 100%; overflow-x: hidden; overflow-y: auto; -webkit-overflow-scrolling: touch; }
            #viewport-container { width: 100%; height: auto; min-height: 100vh; min-height: 100dvh; overflow: visible; padding: 12px 16px calc(20px + env(safe-area-inset-bottom, 0px)); display: flex; flex-direction: column; gap: 14px; }
            #canvas-layer, .cockpit-bg, .vignette-overlay { position: fixed; }
            .top-header { position: static; padding: 0; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px; pointer-events: auto; }
            .brand-logo { font-size: 15px; gap: 6px; order: 1; }
            .brand-logo i { font-size: 14px; }
            .top-search { position: static; transform: none; width: 100%; max-width: none; height: 38px; padding: 0 14px; order: 3; flex: 1 0 100%; }
            .user-actions { order: 2; gap: 8px; }
            .user-points-tag { padding: 5px 10px; font-size: 12px; gap: 4px; }
            .auth-btn { padding: 6px 12px; font-size: 12px; }
            .navbar { position: static; transform: none; width: 100%; max-width: none; height: auto; padding: 0; justify-content: flex-start; overflow-x: auto; overflow-y: hidden; -webkit-overflow-scrolling: touch; scrollbar-width: none; }
            .navbar::-webkit-scrollbar { display: none; }
            .nav-links { gap: 20px; padding: 2px 2px 6px; flex-wrap: nowrap; justify-content: flex-start; }
            .nav-links a { font-size: 14px; padding: 4px 0; }
            .spectrum-area { position: static; transform: none; width: 100%; max-width: none; height: 40px; }
            .main-content { position: static; width: 100%; height: auto; padding: 0; display: flex; flex-direction: column; gap: 22px; pointer-events: auto; }
            .hero-section { justify-content: flex-start; margin-bottom: 0; }
            .hero-title { font-size: 26px; line-height: 1.3; margin-bottom: 12px; }
            .hero-subtitle { font-size: 13px; margin-bottom: 18px; line-height: 1.65; }
            .dj-player-card { max-width: none; display: grid; grid-template-columns: 60px minmax(0, 1fr); gap: 12px 14px; padding: 14px; border-radius: 16px; }
            .album-cover { grid-column: 1; grid-row: 1; width: 60px; height: 60px; border-radius: 10px; }
            .play-btn-overlay { font-size: 18px; border-radius: 10px; }
            .player-info { grid-column: 2; grid-row: 1; }
            .progress-wrapper { grid-column: 1 / -1; grid-row: 2; }
            .volume-control { grid-column: 1 / -1; grid-row: 3; width: 100%; padding-left: 0; padding-top: 10px; border-left: none; border-top: 1px solid rgba(255, 255, 255, 0.1); justify-content: flex-end; }
            .sidebar-cards { justify-content: flex-start; margin-bottom: 0; }
            .ambient-toggle { position: static; transform: none; margin: 4px auto 0; font-size: 11px; padding: 9px 16px; white-space: normal; }
            .site-footer { position: static; width: 100%; padding-top: 4px; }
        }
        @media (max-width: 380px) { .user-points-tag { display: none; } .hero-title { font-size: 22px; } }
        @media (prefers-reduced-motion: reduce) { * { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; } }
    </style>
</head>
<body>

    <audio id="audio-player" preload="metadata" crossorigin="anonymous">
        <?php if ($firstAudio): ?>
        <source src="<?= h($firstAudio['file_url']) ?>" type="audio/mpeg">
        <?php endif; ?>
    </audio>

    <div id="viewport-container">
        <canvas id="canvas-layer"></canvas>
        <div class="cockpit-bg"></div>
        <div class="vignette-overlay"></div>

        <div class="top-header">
            <div class="brand-logo">
                <i class="fa-solid fa-wave-square"></i>
                <span>NIGHT RIDE / 车音坊</span>
            </div>
            <div class="top-search">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" placeholder="搜索电台、频道或车主...">
            </div>
            <div class="user-actions">
                <?php if (!empty($_SESSION['user_id'])): ?>
                    <div class="user-points-tag">
                        <i class="fa-solid fa-bolt" style="color: #ff0055;"></i>
                        积分: <span><?= (int)$_SESSION['user_integral'] ?></span>
                    </div>
                    <a href="/user/index.php" class="auth-btn">👤 <?= h($_SESSION['user_name']) ?></a>
                    <a href="/user/logout.php" class="auth-btn gray">退出</a>
                <?php else: ?>
                    <div class="user-points-tag">
                        <i class="fa-solid fa-bolt" style="color: #ff0055;"></i>
                        积分: <span>--</span>
                    </div>
                    <a href="/login.php" class="auth-btn">登录</a>
                    <a href="/register.php" class="auth-btn gray">注册</a>
                <?php endif; ?>
            </div>
        </div>

        <nav class="navbar">
            <ul class="nav-links">
                <li><a href="/" class="active">首页</a></li>
                <?php foreach ($cates as $c): ?>
                <li><a href="/article_list.php?cate_id=<?= $c['id'] ?>"><?= h($c['name']) ?></a></li>
                <?php endforeach; ?>
                <li><a href="/article_list.php">全部文章</a></li>
            </ul>
        </nav>

        <div class="spectrum-area">
            <canvas id="spectrum-canvas"></canvas>
        </div>

        <div class="main-content">
            <div class="hero-section">
                <h1 class="hero-title">深夜车舱避风港<br>海量无损 DJ 随心享</h1>
                <p class="hero-subtitle">专为车主打造的沉浸式音浪空间。分享你的爱车故事获取音浪积分，免费解锁 24BIT/96KHZ 车载顶级舞曲，享受全国合作门店养车优惠。</p>

                <div class="dj-player-card">
                    <div class="album-cover">
                        <button class="play-btn-overlay icon-toggle" id="play-btn" aria-label="播放/暂停">
                            <i class="fa-solid fa-play"></i>
                            <i class="fa-solid fa-pause"></i>
                        </button>
                    </div>
                    <div class="player-info">
                        <div class="track-name" id="track-name"><?= h($firstAudio['title'] ?? '夜驰车载重低音串烧') ?> <span class="badge-hq">FLAC</span></div>
                        <div class="track-artist" id="track-artist"><?= h($firstAudio['artist'] ?? '驻场 DJ / Electro House Megamix') ?></div>
                        <div class="progress-wrapper">
                            <span class="time-label" id="time-current">00:00</span>
                            <div class="progress-bar-bg" id="progress-bg">
                                <div class="progress-bar-fill" id="progress-fill"></div>
                            </div>
                            <span class="time-label" id="time-total">00:00</span>
                        </div>
                    </div>
                    <div class="volume-control">
                        <i class="fa-solid fa-volume-high" id="volume-icon"></i>
                        <input type="range" id="volume-slider" min="0" max="100" value="70">
                    </div>
                </div>
            </div>

            <div class="sidebar-cards">
                <?php foreach (array_slice($posts, 0, 2) as $p): ?>
                <div class="glass-card">
                    <div class="card-header">
                        <div class="card-title"><i class="fa-solid fa-pen-to-square"></i> <?= h($p['title']) ?></div>
                    </div>
                    <div class="card-desc"><?= h(mb_substr(strip_tags($p['intro'] ?: $p['content']), 0, 80)) ?>...</div>
                    <a href="/post_view.php?id=<?= $p['id'] ?>" class="action-btn"><i class="fa-solid fa-arrow-right"></i> 查看详情</a>
                </div>
                <?php endforeach; ?>

                <div class="glass-card">
                    <div class="card-header">
                        <div class="card-title"><i class="fa-solid fa-ticket"></i> 合作门店养车券</div>
                        <span style="color: var(--primary-neon); font-size: 12px;">可抵扣</span>
                    </div>
                    <div class="card-desc">使用 500 音浪积分，兑换周边合作门店【精细洗车/全车镀膜/小保养】专属折扣。</div>
                    <a href="/user/index.php" class="action-btn" style="background: linear-gradient(90deg, #ff0055, #ff6b6b); color: #fff;"><i class="fa-solid fa-gift"></i> 进入会员中心</a>
                </div>
            </div>
        </div>

        <button class="ambient-toggle" id="saver-toggle">点击开启全屏车载屏保模式 (仅留音频与流星音浪)</button>

        <div class="site-footer">
            <div>© 2026 NIGHT RIDE. 保留所有权利.</div>
            <div><a href="#">粤ICP备2026000000号-1</a> | <a href="#">隐私政策</a> | <a href="#">服务条款</a> | <a href="#">联系我们</a></div>
        </div>
    </div>

    <script>
    (function() {
        var audio = document.getElementById('audio-player');
        var playBtn = document.getElementById('play-btn');
        var progressBg = document.getElementById('progress-bg');
        var progressFill = document.getElementById('progress-fill');
        var timeCurrent = document.getElementById('time-current');
        var timeTotal = document.getElementById('time-total');
        var volumeSlider = document.getElementById('volume-slider');
        var volumeIcon = document.getElementById('volume-icon');

        function formatTime(s) {
            if (isNaN(s)) return '00:00';
            var m = Math.floor(s / 60);
            var sec = Math.floor(s % 60);
            return (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec;
        }

        if (playBtn) {
            playBtn.addEventListener('click', function() {
                if (audio.paused) {
                    audio.play();
                    playBtn.classList.add('playing');
                } else {
                    audio.pause();
                    playBtn.classList.remove('playing');
                }
            });
        }

        audio.addEventListener('timeupdate', function() {
            if (audio.duration) {
                var pct = (audio.currentTime / audio.duration) * 100;
                progressFill.style.width = pct + '%';
                timeCurrent.textContent = formatTime(audio.currentTime);
                timeTotal.textContent = formatTime(audio.duration);
            }
        });

        audio.addEventListener('loadedmetadata', function() {
            timeTotal.textContent = formatTime(audio.duration);
        });

        if (progressBg) {
            progressBg.addEventListener('click', function(e) {
                var rect = progressBg.getBoundingClientRect();
                var pct = (e.clientX - rect.left) / rect.width;
                if (audio.duration) audio.currentTime = pct * audio.duration;
            });
        }

        if (volumeSlider) {
            volumeSlider.addEventListener('input', function() {
                audio.volume = this.value / 100;
            });
        }
        if (volumeIcon) {
            volumeIcon.addEventListener('click', function() {
                if (audio.muted) {
                    audio.muted = false;
                    volumeIcon.className = 'fa-solid fa-volume-high';
                } else {
                    audio.muted = true;
                    volumeIcon.className = 'fa-solid fa-volume-xmark';
                }
            });
        }

        var saverToggle = document.getElementById('saver-toggle');
        var viewport = document.getElementById('viewport-container');
        if (saverToggle) {
            saverToggle.addEventListener('click', function() {
                viewport.classList.toggle('saver');
                saverToggle.textContent = viewport.classList.contains('saver')
                    ? '点击退出全屏车载屏保模式'
                    : '点击开启全屏车载屏保模式 (仅留音频与流星音浪)';
            });
        }

        var spectrumCanvas = document.getElementById('spectrum-canvas');
        if (spectrumCanvas) {
            var sCtx = spectrumCanvas.getContext('2d');
            function drawSpectrum() {
                var w = spectrumCanvas.width = spectrumCanvas.offsetWidth;
                var h = spectrumCanvas.height = spectrumCanvas.offsetHeight;
                sCtx.clearRect(0, 0, w, h);
                var bars = 80;
                var barW = w / bars;
                for (var i = 0; i < bars; i++) {
                    var barH = Math.random() * h * 0.7 + 4;
                    var gradient = sCtx.createLinearGradient(0, h, 0, h - barH);
                    gradient.addColorStop(0, 'rgba(0, 243, 255, 0.8)');
                    gradient.addColorStop(1, 'rgba(255, 0, 85, 0.6)');
                    sCtx.fillStyle = gradient;
                    sCtx.fillRect(i * barW + 1, h - barH, barW - 2, barH);
                }
                requestAnimationFrame(drawSpectrum);
            }
            drawSpectrum();
        }

        var bgCanvas = document.getElementById('canvas-layer');
        if (bgCanvas) {
            var bgCtx = bgCanvas.getContext('2d');
            var particles = [];
            function resize() {
                bgCanvas.width = window.innerWidth;
                bgCanvas.height = window.innerHeight;
            }
            resize();
            window.addEventListener('resize', resize);
            for (var i = 0; i < 60; i++) {
                particles.push({
                    x: Math.random() * bgCanvas.width,
                    y: Math.random() * bgCanvas.height,
                    vx: (Math.random() - 0.5) * 0.5,
                    vy: (Math.random() - 0.5) * 0.5,
                    r: Math.random() * 1.5 + 0.5
                });
            }
            function drawBg() {
                bgCtx.clearRect(0, 0, bgCanvas.width, bgCanvas.height);
                particles.forEach(function(p) {
                    p.x += p.vx;
                    p.y += p.vy;
                    if (p.x < 0 || p.x > bgCanvas.width) p.vx *= -1;
                    if (p.y < 0 || p.y > bgCanvas.height) p.vy *= -1;
                    bgCtx.beginPath();
                    bgCtx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                    bgCtx.fillStyle = 'rgba(0, 243, 255, ' + (0.1 + Math.random() * 0.3) + ')';
                    bgCtx.fill();
                });
                requestAnimationFrame(drawBg);
            }
            drawBg();
        }
    })();
    </script>
</body>
</html>
<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';

$pdo = DB::conn();
$cols = $pdo->query("SHOW COLUMNS FROM `recharge_order`")->fetchAll(PDO::FETCH_COLUMN);

$adds = [];
if (!in_array('trade_no', $cols))    $adds[] = "ADD COLUMN `trade_no` varchar(64) DEFAULT NULL COMMENT '第三方交易号' AFTER `order_no`";
if (!in_array('pay_time', $cols))    $adds[] = "ADD COLUMN `pay_time` int(11) DEFAULT 0 COMMENT '支付时间' AFTER `trade_no`";
if (!in_array('pay_qr', $cols))      $adds[] = "ADD COLUMN `pay_qr` varchar(500) DEFAULT NULL COMMENT '二维码链接' AFTER `pay_time`";
if (!in_array('pay_status', $cols))  $adds[] = "ADD COLUMN `pay_status` varchar(20) DEFAULT 'pending' COMMENT 'pending/paid/closed' AFTER `pay_qr`";

if (empty($adds)) {
    echo "✅ 字段已存在，无需操作";
} else {
    $pdo->exec("ALTER TABLE `recharge_order` " . implode(', ', $adds));
    echo "✅ 已添加 " . count($adds) . " 个字段：<br>";
    foreach ($adds as $s) {
        preg_match('/ADD COLUMN `(\w+)`/', $s, $m);
        echo "- {$m[1]}<br>";
    }
}
echo "<br><br><strong style='color:red;'>请立即删除 alter10.php</strong>";
<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';

$pdo = DB::conn();

$sqls = [
"CREATE TABLE IF NOT EXISTS `article_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_article` (`user_id`,`article_id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

"CREATE TABLE IF NOT EXISTS `article_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `content` text,
  `status` tinyint(1) DEFAULT 1 COMMENT '0待审核 1已通过 2已拒绝',
  `like_count` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
];

foreach ($sqls as $sql) $pdo->exec($sql);

// 初始化设置
$defaults = [
    'like_enabled'      => '1',
    'comment_enabled'   => '1',
    'comment_need_audit'=> '1',
];
foreach ($defaults as $k => $v) {
    $exists = $pdo->query("SELECT COUNT(*) FROM setting WHERE `key`='$k'")->fetchColumn();
    if (!$exists) {
        $stmt = $pdo->prepare("INSERT INTO setting (`key`,`value`) VALUES (?,?)");
        $stmt->execute([$k, $v]);
    }
}

echo "✅ 建表完成<br>";
echo "已创建：article_like（点赞）、article_comment（评论）<br>";
echo "已初始化：like_enabled、comment_enabled、comment_need_audit<br>";
echo "<br><strong style='color:red;'>请立即删除 alter12.php</strong>";
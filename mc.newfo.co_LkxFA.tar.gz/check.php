<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';

echo "<h2>1. 数据库里所有文章</h2>";
$all = DB::query("SELECT id, title, status, cate_id, created_at FROM article ORDER BY id DESC");
echo "<table border='1' cellpadding='8' style='border-collapse:collapse;'>";
echo "<tr><th>ID</th><th>标题</th><th>状态</th><th>分类ID</th><th>时间</th></tr>";
foreach ($all as $a) {
    $statusText = ['0'=>'待审核','1'=>'已发布','2'=>'草稿','3'=>'已拒绝'][$a['status']] ?? '未知';
    echo "<tr><td>{$a['id']}</td><td>{$a['title']}</td><td>{$statusText} ({$a['status']})</td><td>{$a['cate_id']}</td><td>".date('Y-m-d H:i', $a['created_at'])."</td></tr>";
}
echo "</table>";

echo "<h2>2. 前台查询（status=1）能查到的文章</h2>";
$published = DB::query("SELECT id, title FROM article WHERE status=1 ORDER BY id DESC");
if (empty($published)) {
    echo "<p style='color:red;'>❌ 没有任何已发布的文章！</p>";
} else {
    echo "<ul>";
    foreach ($published as $p) {
        echo "<li>ID:{$p['id']} - {$p['title']}</li>";
    }
    echo "</ul>";
}

echo "<h2>3. category 表数据</h2>";
$cates = DB::query("SELECT * FROM category ORDER BY sort");
echo "<table border='1' cellpadding='8' style='border-collapse:collapse;'>";
echo "<tr><th>ID</th><th>名称</th><th>slug</th><th>link</th></tr>";
foreach ($cates as $c) {
    echo "<tr><td>{$c['id']}</td><td>{$c['name']}</td><td>{$c['slug']}</td><td>".($c['link'] ?? '空')."</td></tr>";
}
echo "</table>";

echo "<h2>4. 前台 index.php 里的文章查询语句</h2>";
echo "<p>SQL: <code>SELECT a.*, c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id WHERE a.status=1 ORDER BY a.is_top DESC, a.id DESC LIMIT 10</code></p>";
$test = DB::query("SELECT a.*, c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id WHERE a.status=1 ORDER BY a.is_top DESC, a.id DESC LIMIT 10");
echo "<p>实际查到：<strong>".count($test)."</strong> 条</p>";
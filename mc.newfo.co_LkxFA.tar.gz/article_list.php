<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';
session_start();

$cateId = (int)($_GET['cate_id'] ?? 0);
$keyword = trim($_GET['keyword'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 12;

$where = "WHERE a.status=1";
$params = [];
if ($cateId) { $where .= " AND a.cate_id=?"; $params[] = $cateId; }
if ($keyword !== '') { $where .= " AND a.title LIKE ?"; $params[] = "%{$keyword}%"; }

$total = DB::one("SELECT COUNT(*) c FROM article a $where", $params)['c'];
$list = DB::query("SELECT a.*, c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id $where ORDER BY a.is_top DESC, a.id DESC LIMIT ".($page-1)*$ps.",$ps", $params);
$cates = DB::query("SELECT * FROM category ORDER BY sort ASC");

$currentCateName = '全部';
if ($cateId) {
    $currentCate = DB::one("SELECT name FROM category WHERE id=?", [$cateId]);
    if ($currentCate) $currentCateName = $currentCate['name'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($currentCateName) ?> - NIGHT RIDE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0a0a0f;color:#e0e0e0;-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}

/* ===== 头部导航 ===== */
.site-header{background:#161b22;border-bottom:1px solid #21262d;position:sticky;top:0;z-index:100}
.header-inner{max-width:1200px;margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;height:60px}
.logo{font-size:18px;font-weight:800;color:#00f3ff;display:flex;align-items:center;gap:8px;letter-spacing:1px}
.logo i{font-size:16px}
.header-nav{display:flex;gap:4px;flex-wrap:wrap}
.header-nav a{padding:8px 16px;border-radius:6px;font-size:14px;color:#8a99ad;transition:all .2s}
.header-nav a:hover,.header-nav a.active{color:#00f3ff;background:rgba(0,243,255,.08)}

/* ===== 面包屑 + 标题 ===== */
.page-hero{max-width:1200px;margin:0 auto;padding:36px 24px 20px}
.breadcrumbs{font-size:13px;color:#8a99ad;margin-bottom:12px}
.breadcrumbs a{color:#8a99ad}
.breadcrumbs a:hover{color:#00f3ff}
.breadcrumbs .sep{margin:0 8px}
.breadcrumbs .current{color:#e0e0e0}
.page-title{font-size:28px;font-weight:700;color:#fff;display:flex;align-items:center;gap:12px}
.page-title .count{font-size:14px;color:#8a99ad;font-weight:400}

/* ===== 分类筛选条 ===== */
.filter-bar{max-width:1200px;margin:0 auto;padding:0 24px 28px;display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.filter-bar .filter-label{font-size:13px;color:#8a99ad;margin-right:4px}
.filter-bar a{padding:6px 16px;border-radius:20px;font-size:13px;color:#8a99ad;background:#161b22;border:1px solid #21262d;transition:all .2s}
.filter-bar a:hover,.filter-bar a.active{color:#0a0a0f;background:#00f3ff;border-color:#00f3ff;font-weight:600}
.search-box{max-width:1200px;margin:0 auto;padding:0 24px 28px;display:flex;gap:10px}
.search-box input{flex:1;padding:10px 16px;background:#161b22;border:1px solid #21262d;border-radius:8px;color:#e0e0e0;font-size:14px;outline:none}
.search-box input:focus{border-color:#00f3ff}
.search-box button{padding:10px 24px;background:#00f3ff;color:#0a0a0f;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px}

/* ===== 卡片网格（一排三个） ===== */
.grid-wrap{max-width:1200px;margin:0 auto;padding:0 24px 60px}
.content-loop{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;}
@media(max-width:900px){.content-loop{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:520px){.content-loop{grid-template-columns:1fr;gap:14px}}

/* 卡片 */
.hentry{background:#161b22;border:1px solid #21262d;border-radius:10px;overflow:hidden;transition:transform .25s ease,box-shadow .25s ease,border-color .25s ease;position:relative}
.hentry:hover{transform:translateY(-4px);box-shadow:0 12px 36px rgba(0,243,255,.12);border-color:rgba(0,243,255,.3)}
.hentry .thumbnail-link{display:block;position:relative;overflow:hidden;line-height:0}
.hentry .thumbnail-wrap{position:relative;padding-top:56.25%;background:#0d1117}
.hentry .thumbnail-wrap img{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;transition:transform .4s ease}
.hentry:hover .thumbnail-wrap img{transform:scale(1.05)}
.hentry .thumbnail-wrap .no-cover{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:32px;color:#30363d}

/* 置顶标记 */
.entry-istop{position:absolute;top:10px;left:10px;background:#f85149;color:#fff;font-size:11px;font-weight:700;padding:3px 10px;border-radius:4px;letter-spacing:1px;z-index:2}

/* 播放角标 */
.play-icon{position:absolute;bottom:10px;right:10px;width:28px;height:28px;background:rgba(0,0,0,.6);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;opacity:0;transition:opacity .25s}
.hentry:hover .play-icon{opacity:1}

/* 卡片信息区 */
.entry-header{padding:14px 16px 16px}
.entry-title{font-size:15px;font-weight:600;line-height:1.45;margin-bottom:10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:44px}
.entry-title a{color:#e0e0e0;transition:color .2s}
.entry-title a:hover{color:#00f3ff}
.entry-meta{font-size:12px;color:#8a99ad;display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.entry-meta .view-count i{font-size:11px;margin-right:3px}
.entry-meta .author i{font-size:11px;margin-right:3px}
.entry-meta .sep{color:#30363d}
.entry-meta .entry-date{color:#8a99ad}

/* 空状态 */
.empty-state{text-align:center;padding:80px 20px;color:#8a99ad}
.empty-state i{font-size:48px;color:#30363d;margin-bottom:16px;display:block}
.empty-state p{font-size:15px}

/* 分页 */
.pagination{max-width:1200px;margin:0 auto;padding:0 24px 60px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
.pagination a{padding:8px 16px;background:#161b22;border:1px solid #21262d;border-radius:8px;color:#8a99ad;font-size:14px;transition:all .2s}
.pagination a:hover{border-color:#00f3ff;color:#00f3ff}
.pagination a.active{background:#00f3ff;color:#0a0a0f;border-color:#00f3ff;font-weight:700}

/* 底部 */
.site-footer{text-align:center;padding:32px 24px;color:#8a99ad;font-size:12px;border-top:1px solid #21262d;line-height:1.8}
.site-footer a{color:#8a99ad;margin:0 6px}
.site-footer a:hover{color:#00f3ff}
</style>
</head>
<body>

<!-- 头部 -->
<header class="site-header">
    <div class="header-inner">
        <a href="/" class="logo"><i class="fa-solid fa-wave-square"></i> NIGHT RIDE / 车音坊</a>
        <nav class="header-nav">
            <a href="/" class="<?= !$cateId ? 'active' : '' ?>">首页</a>
            <?php foreach ($cates as $c): ?>
            <a href="/article_list.php?cate_id=<?= $c['id'] ?>" class="<?= $cateId==$c['id'] ? 'active' : '' ?>"><?= h($c['name']) ?></a>
            <?php endforeach; ?>
        </nav>
    </div>
</header>

<!-- 面包屑 + 标题 -->
<div class="page-hero">
    <div class="breadcrumbs">
        <a href="/">首页</a>
        <span class="sep">/</span>
        <span class="current"><?= h($currentCateName) ?></span>
    </div>
    <h1 class="page-title">
        <?= h($currentCateName) ?>
        <span class="count">共 <?= $total ?> 篇</span>
    </h1>
</div>

<!-- 分类筛选 -->
<div class="filter-bar">
    <span class="filter-label">分类：</span>
    <a href="/article_list.php" class="<?= !$cateId ? 'active' : '' ?>">全部</a>
    <?php foreach ($cates as $c): ?>
    <a href="/article_list.php?cate_id=<?= $c['id'] ?>" class="<?= $cateId==$c['id'] ? 'active' : '' ?>"><?= h($c['name']) ?></a>
    <?php endforeach; ?>
</div>

<!-- 搜索 -->
<form class="search-box" method="get" action="/article_list.php">
    <input type="hidden" name="cate_id" value="<?= $cateId ?>">
    <input type="text" name="keyword" placeholder="搜索文章标题..." value="<?= h($keyword) ?>">
    <button type="submit"><i class="fa-solid fa-magnifying-glass"></i> 搜索</button>
</form>

<!-- 文章列表 -->
<div class="grid-wrap">
    <?php if (empty($list)): ?>
        <div class="empty-state">
            <i class="fa-solid fa-inbox"></i>
            <p>暂无文章</p>
        </div>
    <?php else: ?>
    <div class="content-loop">
        <?php foreach ($list as $a): ?>
        <div class="hentry">
            <a class="thumbnail-link" href="/post_view.php?id=<?= $a['id'] ?>">
                <div class="thumbnail-wrap">
                    <?php if (!empty($a['cover'])): ?>
                    <img src="<?= h($a['cover']) ?>" alt="<?= h($a['title']) ?>" loading="lazy">
                    <?php else: ?>
                    <div class="no-cover"><i class="fa-solid fa-music"></i></div>
                    <?php endif; ?>
                </div>
                <?php if (!empty($a['is_top'])): ?>
                <span class="entry-istop">置顶</span>
                <?php endif; ?>
                <span class="play-icon"><i class="fa-solid fa-play"></i></span>
            </a>
            <div class="entry-header">
                <h2 class="entry-title">
                    <a href="/post_view.php?id=<?= $a['id'] ?>"><?= h($a['title']) ?></a>
                </h2>
                <div class="entry-meta">
                    <span class="author"><i class="fa-regular fa-user"></i> <?= h($a['author'] ?: 'admin') ?></span>
                    <span class="sep">·</span>
                    <span class="entry-date"><?= date('Y-m-d', $a['created_at']) ?></span>
                    <span class="sep">·</span>
                    <span class="view-count"><i class="fa-solid fa-eye"></i> <?= $a['views'] ?></span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- 分页 -->
<?php
$totalPage = ceil($total / $ps);
if ($totalPage > 1):
    $urlBase = '/article_list.php?cate_id='.$cateId.'&keyword='.urlencode($keyword);
?>
<div class="pagination">
    <?php if ($page > 1): ?>
    <a href="<?= $urlBase ?>&page=<?= $page-1 ?>">上一页</a>
    <?php endif; ?>
    <?php for ($i=1; $i<=$totalPage; $i++): ?>
    <a href="<?= $urlBase ?>&page=<?= $i ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($page < $totalPage): ?>
    <a href="<?= $urlBase ?>&page=<?= $page+1 ?>">下一页</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- 底部 -->
<footer class="site-footer">
    <div>© 2026 NIGHT RIDE. 保留所有权利.</div>
    <div><a href="#">粤ICP备2026000000号-1</a> | <a href="#">隐私政策</a> | <a href="#">服务条款</a> | <a href="#">联系我们</a></div>
</footer>

</body>
</html>
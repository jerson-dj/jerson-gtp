<?php
include __DIR__.'/header.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 20;

$total = DB::one("SELECT COUNT(*) c FROM integral_log WHERE user_id=?", [$uid])['c'];
$logs  = DB::query("SELECT * FROM integral_log WHERE user_id=? ORDER BY id DESC LIMIT ".($page-1)*$ps.",$ps", [$uid]);
?>

<h1><i class="fa-solid fa-coins"></i> 积分明细</h1>

<div class="stats" style="grid-template-columns:repeat(2,1fr);">
    <div class="stat-card">
        <div class="label">当前积分</div>
        <div class="value gold"><?= (int)$currentUser['integral'] ?></div>
    </div>
    <div class="stat-card">
        <div class="label">累计获得</div>
        <div class="value"><?= DB::one("SELECT SUM(amount) s FROM integral_log WHERE user_id=? AND amount>0", [$uid])['s'] ?: 0 ?></div>
    </div>
</div>

<?php if (empty($logs)): ?>
    <p style="color:#8a99ad;text-align:center;padding:40px;">暂无积分记录</p>
<?php else: ?>
<table>
    <thead>
        <tr><th>ID</th><th>变动</th><th>原因</th><th>时间</th></tr>
    </thead>
    <tbody>
    <?php foreach ($logs as $l): ?>
    <tr>
        <td><?= $l['id'] ?></td>
        <td class="<?= $l['amount']>0?'plus':'minus' ?>"><?= $l['amount']>0?'+':'' ?><?= $l['amount'] ?></td>
        <td><?= h($l['reason']) ?></td>
        <td><?= date('Y-m-d H:i', $l['created_at']) ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php
$totalPage = ceil($total / $ps);
if ($totalPage > 1):
?>
<div style="margin-top:20px;display:flex;gap:8px;justify-content:center;">
    <?php for ($i=1; $i<=$totalPage; $i++): ?>
    <a href="?page=<?= $i ?>" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:<?= $i==$page?'#0a0a0f':'#8a99ad' ?>;<?= $i==$page?'background:#00f3ff;font-weight:700;':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
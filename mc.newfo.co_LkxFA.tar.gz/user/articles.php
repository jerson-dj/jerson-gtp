<?php
include __DIR__.'/header.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 15;

$total = DB::one("SELECT COUNT(*) c FROM article WHERE author=?", [$currentUser['nickname']])['c'];
$list  = DB::query("SELECT * FROM article WHERE author=? ORDER BY id DESC LIMIT ".($page-1)*$ps.",$ps", [$currentUser['nickname']]);
?>

<h1><i class="fa-solid fa-file-lines"></i> 我的文章</h1>

<?php if (empty($list)): ?>
    <p style="color:#8a99ad;text-align:center;padding:40px;">还没有发布过文章</p>
<?php else: ?>
<table>
    <thead>
        <tr><th>ID</th><th>标题</th><th>状态</th><th>阅读</th><th>发布时间</th><th>操作</th></tr>
    </thead>
    <tbody>
    <?php foreach ($list as $a): ?>
    <tr>
        <td><?= $a['id'] ?></td>
        <td><?= h($a['title']) ?></td>
        <td>
            <?php if ($a['status']==0): ?><span style="color:#f0b90b;">待审核</span>
            <?php elseif ($a['status']==1): ?><span style="color:#3fb950;">已发布</span>
            <?php elseif ($a['status']==2): ?><span style="color:#8a99ad;">草稿</span>
            <?php elseif ($a['status']==3): ?><span style="color:#f85149;">已拒绝</span>
            <?php endif; ?>
        </td>
        <td><?= $a['views'] ?></td>
        <td><?= date('Y-m-d H:i', $a['created_at']) ?></td>
        <td><a href="/post_view.php?id=<?= $a['id'] ?>" target="_blank">查看</a></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php
$totalPage = ceil($total / $ps);
if ($totalPage > 1):
?>
<div style="margin-top:20px;display:flex;gap:8px;justify-content:center;">
    <?php for ($i=1; $i<=$totalPage; $i++): ?>
    <a href="?page=<?= $i ?>" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:<?= $i==$page?'#0a0a0f':'#8a99ad' ?>;<?= $i==$page?'background:#00f3ff;font-weight:700;':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();

if (empty($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$uid = $_SESSION['user_id'];
$currentUser = DB::one("SELECT * FROM user WHERE id=?", [$uid]);
if (!$currentUser) {
    session_destroy();
    header('Location: /login.php');
    exit;
}
$_SESSION['user_name'] = $currentUser['nickname'];
$_SESSION['user_integral'] = $currentUser['integral'];

$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>会员中心 - NIGHT RIDE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0a0a0f;color:#e0e0e0;min-height:100vh}
a{color:#00f3ff;text-decoration:none}
a:hover{text-decoration:underline}

/* 顶部 */
.top-bar{background:#161b22;border-bottom:1px solid #21262d;padding:0 24px;height:60px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.top-bar .logo{font-size:16px;font-weight:800;color:#00f3ff}
.top-bar .user-info{display:flex;align-items:center;gap:16px;font-size:14px}
.top-bar .user-info .points{color:#f0b90b;font-weight:700}
.top-bar .user-info a{color:#8a99ad}
.top-bar .user-info a:hover{color:#00f3ff}

/* 布局 */
.layout{display:grid;grid-template-columns:220px 1fr;gap:24px;max-width:1200px;margin:24px auto;padding:0 24px;min-height:calc(100vh - 60px)}
@media(max-width:768px){.layout{grid-template-columns:1fr;gap:16px}}

/* 侧边栏 */
.sidebar{background:#161b22;border:1px solid #21262d;border-radius:12px;padding:16px 0;height:fit-content;position:sticky;top:84px}
.sidebar .avatar-box{padding:0 20px 16px;text-align:center;border-bottom:1px solid #21262d;margin-bottom:12px}
.sidebar .avatar-box img{width:64px;height:64px;border-radius:50%;object-fit:cover;border:2px solid #00f3ff;margin-bottom:8px}
.sidebar .avatar-box .name{font-size:15px;font-weight:700;color:#fff}
.sidebar .avatar-box .vip{font-size:11px;color:#f0b90b;margin-top:4px}
.sidebar .menu{padding:0 12px}
.sidebar .menu a{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:8px;color:#8a99ad;font-size:14px;transition:all .2s}
.sidebar .menu a:hover{background:#0d1117;color:#00f3ff;text-decoration:none}
.sidebar .menu a.active{background:linear-gradient(90deg,rgba(0,243,255,.15),transparent);color:#00f3ff;font-weight:600;border-left:3px solid #00f3ff}
.sidebar .menu a i{width:18px;text-align:center}
.sidebar .menu .sep{height:1px;background:#21262d;margin:8px 14px}

/* 主内容 */
.main{background:#161b22;border:1px solid #21262d;border-radius:12px;padding:28px}
.main h1{font-size:20px;margin-bottom:24px;color:#fff;display:flex;align-items:center;gap:10px}

/* 表单 */
.form-group{margin-bottom:18px}
.form-group label{display:block;color:#8b949e;font-size:13px;margin-bottom:8px}
.form-group input[type=text],.form-group input[type=password],.form-group input[type=email],.form-group input[type=date],.form-group select,.form-group textarea{width:100%;padding:11px 14px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#c9d1d9;font-size:14px;outline:none;transition:border-color .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:#00f3ff}
.form-group .hint{font-size:12px;color:#8a99ad;margin-top:6px}

.btn{display:inline-block;padding:11px 24px;background:#00f3ff;color:#0a0a0f;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px;transition:all .2s}
.btn:hover{background:#00b8e0;text-decoration:none}
.btn-outline{background:transparent;color:#00f3ff;border:1px solid #00f3ff}
.btn-outline:hover{background:#00f3ff;color:#0a0a0f}
.btn-danger{background:#f85149;color:#fff}
.btn-danger:hover{background:#d43f3a}

.alert{padding:12px 16px;border-radius:8px;margin-bottom:20px;font-size:14px}
.alert-ok{background:rgba(63,185,80,.1);color:#3fb950;border:1px solid rgba(63,185,80,.3)}
.alert-err{background:rgba(248,81,73,.1);color:#f85149;border:1px solid rgba(248,81,73,.3)}

/* 表格 */
table{width:100%;border-collapse:collapse;background:#0d1117;border-radius:10px;overflow:hidden;border:1px solid #21262d}
th,td{padding:12px 16px;text-align:left;border-bottom:1px solid #21262d;font-size:14px}
th{background:#161b22;color:#8b949e;font-weight:600;font-size:13px}
tr:last-child td{border-bottom:none}
.plus{color:#3fb950}
.minus{color:#f85149}

/* 统计卡片 */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px}
@media(max-width:768px){.stats{grid-template-columns:repeat(2,1fr)}}
.stat-card{background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:20px;transition:border-color .2s}
.stat-card:hover{border-color:#00f3ff33}
.stat-card .label{font-size:12px;color:#8a99ad;margin-bottom:8px}
.stat-card .value{font-size:24px;font-weight:700;color:#00f3ff}
.stat-card .value.gold{color:#f0b90b}
</style>
</head>
<body>

<div class="top-bar">
    <a href="/" class="logo">🎵 NIGHT RIDE / 车音坊</a>
    <div class="user-info">
        <span class="points">⚡ <?= (int)$currentUser['integral'] ?></span>
        <span>👤 <?= h($currentUser['nickname']) ?></span>
        <a href="/user/logout.php">退出</a>
    </div>
</div>

<div class="layout">

    <!-- 侧边栏 -->
    <aside class="sidebar">
        <div class="avatar-box">
            <img src="<?= h($currentUser['avatar'] ?: 'https://ui-avatars.com/api/?name='.urlencode($currentUser['nickname']).'&background=00f3ff&color=0a0a0f&size=128') ?>" alt="avatar">
            <div class="name"><?= h($currentUser['nickname']) ?></div>
            <?php if (!empty($currentUser['vip_level']) && $currentUser['vip_expire'] > time()): ?>
            <div class="vip">👑 VIP<?= (int)$currentUser['vip_level'] ?></div>
            <?php else: ?>
            <div class="vip" style="color:#8a99ad;">普通会员</div>
            <?php endif; ?>
        </div>
  <nav class="menu">
    <a href="/user/index.php" class="<?= $currentPage=='index.php'?'active':'' ?>"><i class="fa-solid fa-house"></i> 会员中心</a>
    <a href="/user/profile.php" class="<?= $currentPage=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> 修改资料</a>
    <a href="/user/password.php" class="<?= $currentPage=='password.php'?'active':'' ?>"><i class="fa-solid fa-lock"></i> 修改密码</a>
    <a href="/user/verify.php" class="<?= $currentPage=='verify.php'?'active':'' ?>"><i class="fa-solid fa-id-card"></i> 实名认证</a>
    <a href="/user/bind_phone.php" class="<?= $currentPage=='bind_phone.php'?'active':'' ?>"><i class="fa-solid fa-mobile-screen"></i> 手机绑定</a>
    <div class="sep"></div>
    <a href="/user/recharge.php" class="<?= $currentPage=='recharge.php'?'active':'' ?>"><i class="fa-solid fa-bolt"></i> 充值中心</a>
    <a href="/user/recharge_log.php" class="<?= $currentPage=='recharge_log.php'?'active':'' ?>"><i class="fa-solid fa-list"></i> 充值记录</a>
    <div class="sep"></div>
    <a href="/user/post_submit.php" class="<?= $currentPage=='post_submit.php'?'active':'' ?>"><i class="fa-solid fa-pen-to-square"></i> 我要投稿</a>
    <a href="/user/articles.php" class="<?= $currentPage=='articles.php'?'active':'' ?>"><i class="fa-solid fa-file-lines"></i> 我的文章</a>
    <a href="/user/favorites.php" class="<?= $currentPage=='favorites.php'?'active':'' ?>"><i class="fa-solid fa-star"></i> 我的收藏</a>
    <a href="/user/messages.php" class="<?= $currentPage=='messages.php'?'active':'' ?>"><i class="fa-solid fa-comments"></i> 我的留言</a>
    <div class="sep"></div>
    <a href="/user/integral.php" class="<?= $currentPage=='integral.php'?'active':'' ?>"><i class="fa-solid fa-coins"></i> 积分明细</a>
    <div class="sep"></div>
    <a href="/" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> 返回首页</a>
    <a href="/user/logout.php"><i class="fa-solid fa-right-from-bracket"></i> 退出登录</a>
</nav>
    </aside>

    <!-- 主内容 -->
    <main class="main">
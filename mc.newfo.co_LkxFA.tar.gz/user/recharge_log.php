<?php
include __DIR__.'/header.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 20;
$total = DB::one("SELECT COUNT(*) c FROM recharge_log WHERE user_id=?", [$uid])['c'];
$list = DB::query("SELECT * FROM recharge_log WHERE user_id=? ORDER BY id DESC LIMIT ".($page-1)*$ps.",$ps", [$uid]);
?>

<h1><i class="fa-solid fa-list"></i> 充值记录</h1>

<?php if (empty($list)): ?>
<p style="color:#8a99ad;text-align:center;padding:60px;">还没有充值记录</p>
<?php else: ?>
<table>
    <thead><tr><th>ID</th><th>类型</th><th>金额/天数</th><th>备注</th><th>时间</th></tr></thead>
    <tbody>
    <?php foreach ($list as $l): ?>
    <tr>
        <td><?= $l['id'] ?></td>
        <td><?= $l['type'] === 'integral' ? '⚡ 积分' : '👑 VIP' ?></td>
        <td class="plus">+<?= $l['amount'] ?></td>
        <td><?= h($l['remark']) ?></td>
        <td><?= date('Y-m-d H:i', $l['created_at']) ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
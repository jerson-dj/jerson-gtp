<?php
include __DIR__.'/header.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 15;
$total = DB::one("SELECT COUNT(*) c FROM article_comment WHERE user_id=?", [$uid])['c'];
$list = DB::query(
    "SELECT c.*, a.title article_title FROM article_comment c 
     LEFT JOIN article a ON c.article_id=a.id 
     WHERE c.user_id=? ORDER BY c.id DESC LIMIT ".($page-1)*$ps.",$ps",
    [$uid]
);
?>

<h1><i class="fa-solid fa-comments"></i> 我的评论</h1>

<?php if (empty($list)): ?>
<p style="color:#8a99ad;text-align:center;padding:60px;">还没有发表过评论</p>
<?php else: ?>
<?php foreach ($list as $c): ?>
<div style="background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:18px;margin-bottom:14px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <div style="font-size:13px;color:#8a99ad;">
            评论于 <a href="/post_view.php?id=<?= $c['article_id'] ?>" target="_blank">《<?= h($c['article_title'] ?? '文章#'.$c['article_id']) ?>》</a>
        </div>
        <div style="font-size:12px;color:#8a99ad;">
            <?php if ($c['status']==0): ?><span style="color:#f0b90b;">⏳ 待审核</span>
            <?php elseif ($c['status']==1): ?><span style="color:#3fb950;">✅ 已通过</span>
            <?php else: ?><span style="color:#f85149;">❌ 已拒绝</span><?php endif; ?>
            · <?= date('Y-m-d H:i', $c['created_at']) ?>
        </div>
    </div>
    <div style="font-size:14px;line-height:1.7;color:#c9d1d9;margin-bottom:8px;"><?= nl2br(h($c['content'])) ?></div>
    <a href="javascript:;" onclick="delComment(<?= $c['id'] ?>, this)" style="font-size:12px;color:#f85149;">删除</a>
</div>
<?php endforeach; ?>
<?php endif; ?>

<script>
function delComment(id, el) {
    if (!confirm('确定删除？')) return;
    var fd = new FormData();
    fd.append('action', 'delete');
    fd.append('id', id);
    fetch('/api/comment.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(function(res) {
            if (res.success) el.closest('div[style*="background:#0d1117"]').remove();
            else alert(res.msg);
        });
}
</script>

<?php
$totalPage = ceil($total / $ps);
if ($totalPage > 1):
?>
<div style="margin-top:20px;display:flex;gap:8px;justify-content:center;">
    <?php for ($i=1; $i<=$totalPage; $i++): ?>
    <a href="?page=<?= $i ?>" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:<?= $i==$page?'#0a0a0f':'#8a99ad' ?>;<?= $i==$page?'background:#00f3ff;font-weight:700;':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
<?php
include __DIR__.'/header.php';

$cates = DB::query("SELECT * FROM category ORDER BY sort ASC");
$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = trim($_POST['title'] ?? '');
    $cateId  = (int)($_POST['cate_id'] ?? 0);
    $intro   = trim($_POST['intro'] ?? '');
    $content = $_POST['content'] ?? '';

    if (empty($title)) {
        $msg = '标题不能为空'; $msgType = 'err';
    } elseif (mb_strlen($title) > 100) {
        $msg = '标题不超过 100 字'; $msgType = 'err';
    } elseif (empty($content)) {
        $msg = '内容不能为空'; $msgType = 'err';
    } else {
        // 简单敏感词检测
        $badWords = ['敏感词1', '敏感词2'];
        $fullText = $title . $content;
        foreach ($badWords as $w) {
            if (strpos($fullText, $w) !== false) {
                $msg = '内容包含敏感词，请修改后重试'; $msgType = 'err';
                break;
            }
        }

        if (!$msg) {
            $alias = preg_replace('/[^\p{L}\p{N}\-]+/u', '-', $title);
            $alias = trim($alias, '-');
            if (empty($alias)) $alias = 'post-' . time();

            $aid = DB::insert(
                "INSERT INTO article (cate_id, title, alias, content, intro, author, type, status, created_at, updated_at) VALUES (?,?,?,?,?,?,'article',0,?,?)",
                [$cateId, $title, $alias, $content, $intro, $currentUser['nickname'], time(), time()]
            );

            $msg = '投稿成功！等待管理员审核，审核通过后将展示在网站。';
            $msgType = 'ok';
        }
    }
}
?>

<h1><i class="fa-solid fa-pen-to-square"></i> 我要投稿</h1>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= h($msg) ?></div><?php endif; ?>

<form method="post" style="max-width:820px;">
    <div class="form-group">
        <label>标题 <span style="color:#f85149;">*</span></label>
        <input type="text" name="title" placeholder="请输入文章标题" required maxlength="100" value="<?= h($_POST['title'] ?? '') ?>">
    </div>

    <div class="form-group">
        <label>分类</label>
        <select name="cate_id">
            <option value="0">-- 未分类 --</option>
            <?php foreach ($cates as $c): ?>
            <option value="<?= $c['id'] ?>" <?= ($_POST['cate_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>摘要（可选）</label>
        <input type="text" name="intro" placeholder="一句话概括文章内容" value="<?= h($_POST['intro'] ?? '') ?>">
    </div>

    <div class="form-group">
        <label>正文内容 <span style="color:#f85149;">*</span></label>
        <textarea name="content" rows="14" placeholder="支持 HTML 标签，如 <p>段落</p>、<h2>标题</h2>、<img src=...>" style="font-family:monospace;line-height:1.7;"><?= h($_POST['content'] ?? '') ?></textarea>
        <div class="hint">提示：审核通过后，文章将展示在网站，作者显示为你的昵称。</div>
    </div>

    <div style="display:flex;gap:12px;">
        <button type="submit" class="btn">提交投稿</button>
        <a href="/user/articles.php" class="btn btn-outline">我的投稿记录</a>
    </div>
</form>

<?php include __DIR__.'/footer.php'; ?>
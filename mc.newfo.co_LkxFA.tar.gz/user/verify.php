<?php
include __DIR__.'/header.php';

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $realName = trim($_POST['real_name'] ?? '');
    $idCard   = strtoupper(trim($_POST['id_card'] ?? ''));

    if (empty($realName)) {
        $msg = '请填写真实姓名'; $msgType = 'err';
    } elseif (mb_strlen($realName) < 2 || mb_strlen($realName) > 20) {
        $msg = '真实姓名长度不正确'; $msgType = 'err';
    } elseif (!preg_match('/^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dX]$/', $idCard)) {
        $msg = '身份证号格式不正确'; $msgType = 'err';
    } else {
        // 检查身份证是否已被其他账号使用
        $exists = DB::one("SELECT id FROM user WHERE id_card=? AND id!=?", [$idCard, $uid]);
        if ($exists) {
            $msg = '该身份证已被其他账号绑定'; $msgType = 'err';
        } else {
            DB::exec("UPDATE user SET real_name=?, id_card=?, is_verified=1, verify_time=?, updated_at=? WHERE id=?",
                [$realName, $idCard, time(), time(), $uid]);
            $msg = '✅ 实名认证成功'; $msgType = 'ok';
            $currentUser = DB::one("SELECT * FROM user WHERE id=?", [$uid]);
        }
    }
}
?>

<h1><i class="fa-solid fa-id-card"></i> 实名认证</h1>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= h($msg) ?></div><?php endif; ?>

<?php if (!empty($currentUser['is_verified'])): ?>
    <div style="background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:24px;max-width:520px;">
        <div style="font-size:16px;color:#3fb950;font-weight:700;margin-bottom:16px;">✅ 已通过实名认证</div>
        <table>
            <tr><th style="width:120px;">真实姓名</th><td><?= h($currentUser['real_name']) ?></td></tr>
            <tr><th>身份证号</th><td><?= h(substr($currentUser['id_card'], 0, 6)) . '********' . substr($currentUser['id_card'], -4) ?></td></tr>
            <tr><th>认证时间</th><td><?= date('Y-m-d H:i', $currentUser['verify_time']) ?></td></tr>
        </table>
    </div>
<?php else: ?>
    <div style="background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:24px;max-width:520px;">
        <p style="color:#8a99ad;font-size:13px;margin-bottom:20px;line-height:1.8;">
            ⚠️ 实名认证后不可修改，请确认信息准确。<br>
            实名信息仅用于身份验证，不会对外公开。
        </p>

        <form method="post">
            <div class="form-group">
                <label>真实姓名 <span style="color:#f85149;">*</span></label>
                <input type="text" name="real_name" placeholder="与身份证一致" required value="<?= h($_POST['real_name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>身份证号 <span style="color:#f85149;">*</span></label>
                <input type="text" name="id_card" placeholder="18位身份证号" required maxlength="18" value="<?= h($_POST['id_card'] ?? '') ?>">
                <div class="hint">最后一位可以是数字或大写 X</div>
            </div>
            <button type="submit" class="btn" onclick="return confirm('确认提交？提交后不可修改。')">提交认证</button>
        </form>
    </div>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
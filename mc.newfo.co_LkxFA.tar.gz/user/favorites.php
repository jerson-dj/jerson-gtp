<?php
include __DIR__.'/header.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 15;

$total = DB::one("SELECT COUNT(*) c FROM user_favorite WHERE user_id=?", [$uid])['c'];
$list  = DB::query(
    "SELECT f.id fid, f.created_at fcreate, a.* 
     FROM user_favorite f 
     LEFT JOIN article a ON f.article_id = a.id 
     WHERE f.user_id=? AND a.id IS NOT NULL 
     ORDER BY f.id DESC 
     LIMIT ".($page-1)*$ps.",$ps",
    [$uid]
);
?>

<h1><i class="fa-solid fa-star"></i> 我的收藏</h1>

<?php if (empty($list)): ?>
    <p style="color:#8a99ad;text-align:center;padding:60px;">还没有收藏任何文章<br><a href="/article_list.php" style="margin-top:12px;display:inline-block;">去逛逛 →</a></p>
<?php else: ?>
<table>
    <thead>
        <tr><th>标题</th><th>作者</th><th>收藏时间</th><th>操作</th></tr>
    </thead>
    <tbody>
    <?php foreach ($list as $a): ?>
    <tr>
        <td><a href="/post_view.php?id=<?= $a['id'] ?>" target="_blank"><?= h($a['title']) ?></a></td>
        <td><?= h($a['author'] ?: 'admin') ?></td>
        <td><?= date('Y-m-d H:i', $a['fcreate']) ?></td>
        <td>
            <a href="javascript:;" onclick="removeFav(<?= $a['id'] ?>, this)" style="color:#f85149;">取消收藏</a>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php
$totalPage = ceil($total / $ps);
if ($totalPage > 1):
?>
<div style="margin-top:20px;display:flex;gap:8px;justify-content:center;">
    <?php for ($i=1; $i<=$totalPage; $i++): ?>
    <a href="?page=<?= $i ?>" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:<?= $i==$page?'#0a0a0f':'#8a99ad' ?>;<?= $i==$page?'background:#00f3ff;font-weight:700;':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<script>
function removeFav(aid, el) {
    if (!confirm('确定取消收藏？')) return;
    fetch('/api/favorite.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=remove&article_id=' + aid
    })
    .then(r => r.json())
    .then(function(res) {
        if (res.success) {
            el.closest('tr').remove();
        } else {
            alert(res.msg || '操作失败');
        }
    });
}
</script>

<?php include __DIR__.'/footer.php'; ?>
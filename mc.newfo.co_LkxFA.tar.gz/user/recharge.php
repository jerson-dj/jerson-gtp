<?php
include __DIR__.'/header.php';

$msg = '';
$msgType = '';

// 卡密充值
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'card') {
    $cardNo  = trim($_POST['card_no'] ?? '');
    $cardPwd = trim($_POST['card_pwd'] ?? '');
    if (empty($cardNo) || empty($cardPwd)) {
        $msg = '请填写卡号和密码'; $msgType = 'err';
    } else {
        $card = DB::one("SELECT * FROM recharge_card WHERE card_no=? AND card_pwd=?", [$cardNo, $cardPwd]);
        if (!$card) { $msg = '卡号或密码错误'; $msgType = 'err'; }
        elseif ($card['status'] == 1) { $msg = '该卡已被使用'; $msgType = 'err'; }
        else {
            DB::conn()->beginTransaction();
            try {
                if ($card['type'] === 'integral') {
                    DB::exec("UPDATE user SET integral=integral+?, updated_at=? WHERE id=?", [$card['amount'], time(), $uid]);
                    DB::insert("INSERT INTO integral_log (user_id, amount, reason, created_at) VALUES (?,?,?,?)", [$uid, $card['amount'], '充值卡充值', time()]);
                    DB::insert("INSERT INTO recharge_log (user_id, type, amount, card_id, remark, created_at) VALUES (?,'integral',?,?,?,?)", [$uid, $card['amount'], $card['id'], '卡密充值', time()]);
                    $msg = "✅ 充值成功，获得 {$card['amount']} 积分";
                } else {
                    $plan = DB::one("SELECT * FROM vip_plan WHERE id=?", [$card['vip_plan_id']]);
                    if ($plan) {
                        $expire = max(time(), $currentUser['vip_expire']) + $plan['days'] * 86400;
                        DB::exec("UPDATE user SET vip_level=?, vip_expire=?, updated_at=? WHERE id=?", [$plan['level'], $expire, time(), $uid]);
                        DB::insert("INSERT INTO recharge_log (user_id, type, amount, card_id, remark, created_at) VALUES (?,'vip',?,?,?,?)", [$uid, $plan['days'], $card['id'], 'VIP充值：'.$plan['name'], time()]);
                        $msg = "✅ VIP 充值成功：{$plan['name']}";
                    }
                }
                DB::exec("UPDATE recharge_card SET status=1, used_by=?, used_at=? WHERE id=?", [$uid, time(), $card['id']]);
                DB::conn()->commit();
                $msgType = 'ok';
                $currentUser = DB::one("SELECT * FROM user WHERE id=?", [$uid]);
            } catch (Exception $e) {
                DB::conn()->rollBack();
                $msg = '充值失败'; $msgType = 'err';
            }
        }
    }
}

$cfg = [];
foreach (DB::query("SELECT * FROM setting") as $row) $cfg[$row['key']] = $row['value'];
$integralRate = (int)($cfg['integral_rate'] ?? 100);
$payMode = $cfg['pay_mode'] ?? 'manual';
$alipayQr = $cfg['alipay_qrcode'] ?? '';
$wechatQr = $cfg['wechat_qrcode'] ?? '';
$plans = DB::query("SELECT * FROM vip_plan WHERE status=1 ORDER BY sort ASC");
$myOrders = DB::query("SELECT * FROM recharge_order WHERE user_id=? ORDER BY id DESC LIMIT 10", [$uid]);
?>

<h1><i class="fa-solid fa-bolt"></i> 充值中心</h1>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= h($msg) ?></div><?php endif; ?>

<div class="stats" style="grid-template-columns:repeat(2,1fr);">
    <div class="stat-card"><div class="label">⚡ 当前积分</div><div class="value gold"><?= (int)$currentUser['integral'] ?></div></div>
    <div class="stat-card"><div class="label">👑 VIP 状态</div>
        <div class="value" style="font-size:16px;">
            <?php if (!empty($currentUser['vip_level']) && $currentUser['vip_expire'] > time()): ?>
                VIP<?= (int)$currentUser['vip_level'] ?> · <?= date('Y-m-d', $currentUser['vip_expire']) ?>
            <?php else: ?>普通会员<?php endif; ?>
        </div>
    </div>
</div>

<h1 style="font-size:16px;"><i class="fa-solid fa-credit-card"></i> 在线充值</h1>
<p style="color:#8a99ad;font-size:13px;margin-bottom:16px;">1 元 = <?= $integralRate ?> 积分</p>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;margin-bottom:32px;">
    <div style="background:#0d1117;border:1px solid #21262d;border-radius:12px;padding:20px;">
        <div style="font-size:14px;font-weight:700;color:#00f3ff;margin-bottom:12px;">⚡ 积分充值</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <?php foreach ([10, 30, 50, 100, 200, 500] as $m): ?>
            <button type="button" onclick="createPay('integral', <?= $m ?>, 0)" style="padding:8px 14px;background:#161b22;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;cursor:pointer;font-size:13px;"><?= $m ?>元</button>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<h1 style="font-size:16px;"><i class="fa-solid fa-crown"></i> VIP 套餐</h1>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;margin-bottom:32px;">
    <?php foreach ($plans as $p): ?>
    <div style="background:#0d1117;border:1px solid #21262d;border-radius:12px;padding:20px;text-align:center;">
        <div style="font-size:16px;font-weight:700;color:#00f3ff;margin-bottom:10px;"><?= h($p['name']) ?></div>
        <div style="font-size:12px;color:#8a99ad;margin-bottom:16px;min-height:32px;"><?= h($p['desc']) ?></div>
        <div style="font-size:22px;font-weight:700;color:#f0b90b;margin-bottom:6px;">¥<?= number_format($p['price_money'], 2) ?></div>
        <div style="font-size:12px;color:#8a99ad;margin-bottom:14px;">或 <?= (int)$p['price_integral'] ?> 积分</div>
        <div style="display:flex;gap:8px;">
            <button type="button" class="btn" onclick="createPay('vip', 0, <?= $p['id'] ?>)" style="flex:1;padding:9px;font-size:13px;">在线支付</button>
            <button type="button" class="btn" style="flex:1;padding:9px;font-size:13px;background:#30363d;color:#c9d1d9;" onclick="buyVipByIntegral(<?= $p['id'] ?>)">积分支付</button>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<h1 style="font-size:16px;"><i class="fa-solid fa-ticket"></i> 卡密充值</h1>
<form method="post" style="max-width:520px;margin-bottom:32px;">
    <input type="hidden" name="action" value="card">
    <div class="form-group"><label>卡号</label><input type="text" name="card_no" required></div>
    <div class="form-group"><label>卡密</label><input type="text" name="card_pwd" required></div>
    <button type="submit" class="btn">立即充值</button>
</form>

<?php if (!empty($myOrders)): ?>
<h1 style="font-size:16px;"><i class="fa-solid fa-list"></i> 我的充值订单</h1>
<table>
<thead><tr><th>订单号</th><th>类型</th><th>金额</th><th>支付方式</th><th>状态</th><th>时间</th></tr></thead>
<tbody>
<?php foreach ($myOrders as $o): ?>
<tr>
    <td><code style="font-size:12px;"><?= h($o['order_no']) ?></code></td>
    <td><?= $o['type']==='integral'?'⚡ 积分':'👑 VIP' ?></td>
    <td>¥<?= number_format($o['amount_money'], 2) ?></td>
    <td><?= $o['pay_method']==='alipay'?'支付宝':'微信' ?></td>
    <td>
        <?php if ($o['pay_status']==='paid'): ?><span style="color:#3fb950;">✅ 已支付</span>
        <?php elseif ($o['status']==2): ?><span style="color:#f85149;">❌ 已拒绝</span>
        <?php else: ?><span style="color:#f0b90b;">⏳ 待审核</span><?php endif; ?>
    </td>
    <td><?= date('Y-m-d H:i', $o['created_at']) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php endif; ?>

<!-- 支付弹窗 -->
<div id="payModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#161b22;border:1px solid #30363d;border-radius:12px;width:480px;max-width:92vw;padding:28px;text-align:center;max-height:90vh;overflow-y:auto;">
        <h3 style="color:#00f3ff;font-size:16px;margin-bottom:16px;">扫码支付</h3>
        <div id="payAmount" style="font-size:22px;font-weight:700;color:#f0b90b;margin-bottom:20px;"></div>

        <div style="display:flex;gap:10px;margin-bottom:20px;">
            <button type="button" id="tabAlipay" onclick="switchMethod('alipay')" style="flex:1;padding:10px;border-radius:6px;border:1px solid #00f3ff;background:rgba(0,243,255,.15);color:#00f3ff;cursor:pointer;">支付宝</button>
            <button type="button" id="tabWechat" onclick="switchMethod('wechat')" style="flex:1;padding:10px;border-radius:6px;border:1px solid #30363d;background:transparent;color:#8a99ad;cursor:pointer;">微信</button>
        </div>

        <!-- 二维码区域 -->
        <div id="qrArea" style="margin-bottom:20px;">
            <div id="qrcodeBox" style="background:#fff;padding:12px;border-radius:8px;display:inline-block;min-width:220px;min-height:220px;"></div>
        </div>

        <p id="payTip" style="font-size:12px;color:#8a99ad;margin-bottom:12px;">请用对应 App 扫码付款</p>

        <!-- 收款码模式：填写付款账号 -->
        <div id="manualArea" style="display:none;text-align:left;margin-bottom:16px;">
            <label style="display:block;color:#8b949e;font-size:13px;margin-bottom:8px;">付款账号后4位（便于核对）</label>
            <input type="text" id="payAccountInput" maxlength="20" placeholder="例如：8888" style="width:100%;padding:11px 14px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#c9d1d9;font-size:14px;outline:none;">
            <input type="file" id="proofFile" accept="image/*" style="display:none;">
            <button type="button" onclick="document.getElementById('proofFile').click()" style="width:100%;padding:10px;background:transparent;border:1px dashed #30363d;border-radius:8px;color:#8a99ad;cursor:pointer;font-size:13px;margin-top:10px;">📎 上传付款截图（可选）</button>
            <div id="proofName" style="font-size:12px;color:#3fb950;margin-top:6px;display:none;"></div>
        </div>

        <p id="payStatus" style="font-size:13px;color:#f0b90b;margin-bottom:16px;"></p>

        <div style="display:flex;gap:10px;">
            <button type="button" id="submitBtn" class="btn" onclick="submitOrder()" style="flex:1;display:none;">我已付款，提交审核</button>
            <button type="button" class="btn" onclick="closePay()" style="flex:1;background:#30363d;color:#c9d1d9;">关闭</button>
        </div>
    </div>
</div>

<script src="https://cdn.bootcdn.net/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
var PAY_MODE = '<?= $payMode ?>';
var ALIPAY_QR = '<?= h($alipayQr) ?>';
var WECHAT_QR = '<?= h($wechatQr) ?>';

var currentType = '', currentAmount = 0, currentVipPlanId = 0;
var currentOrderId = 0, currentMethod = 'alipay', queryTimer = null, proofUrl = '';

function createPay(type, amount, vipPlanId) {
    currentType = type;
    currentAmount = amount;
    currentVipPlanId = vipPlanId;
    currentMethod = 'alipay';
    proofUrl = '';

    document.getElementById('payModal').style.display = 'flex';
    document.getElementById('qrcodeBox').innerHTML = '';
    document.getElementById('payAmount').textContent = amount > 0 ? '¥' + amount.toFixed(2) : 'VIP 套餐';
    document.getElementById('payAccountInput').value = '';
    document.getElementById('proofName').style.display = 'none';
    document.getElementById('payStatus').textContent = '';

    switchMethod('alipay');
}

function switchMethod(method) {
    currentMethod = method;
    var tabA = document.getElementById('tabAlipay');
    var tabW = document.getElementById('tabWechat');

    if (method === 'alipay') {
        tabA.style.borderColor = '#00f3ff'; tabA.style.background = 'rgba(0,243,255,.15)'; tabA.style.color = '#00f3ff';
        tabW.style.borderColor = '#30363d'; tabW.style.background = 'transparent'; tabW.style.color = '#8a99ad';
    } else {
        tabW.style.borderColor = '#3fb950'; tabW.style.background = 'rgba(63,185,80,.15)'; tabW.style.color = '#3fb950';
        tabA.style.borderColor = '#30363d'; tabA.style.background = 'transparent'; tabA.style.color = '#8a99ad';
    }

    // 收款码模式
    if (PAY_MODE === 'manual') {
        showManualQR();
    } else {
        // 官方接口模式
        doCreateOrder(method);
    }
}

function showManualQR() {
    document.getElementById('manualArea').style.display = 'block';
    document.getElementById('submitBtn').style.display = 'block';
    document.getElementById('payTip').textContent = '请用对应 App 扫码付款，付款后填写付款账号后4位';

    var qrUrl = currentMethod === 'alipay' ? ALIPAY_QR : WECHAT_QR;
    var box = document.getElementById('qrcodeBox');
    box.innerHTML = '';

    if (!qrUrl) {
        box.innerHTML = '<div style="color:#f85149;padding:60px 20px;font-size:13px;">收款码未配置<br>请联系管理员</div>';
        document.getElementById('payStatus').textContent = '';
        return;
    }

    // 如果是图片 URL，直接显示图片
    if (qrUrl.match(/\.(jpg|jpeg|png|gif|webp)$/i) || qrUrl.indexOf('/uploads/') >= 0) {
        box.innerHTML = '<img src="' + qrUrl + '" style="max-width:220px;display:block;">';
    } else {
        // 否则用 qrcodejs 生成
        new QRCode(box, {
            text: qrUrl,
            width: 220,
            height: 220,
            correctLevel: QRCode.CorrectLevel.M
        });
    }
    document.getElementById('payStatus').textContent = '';
}

function doCreateOrder(method) {
    document.getElementById('manualArea').style.display = 'none';
    document.getElementById('submitBtn').style.display = 'none';
    document.getElementById('qrcodeBox').innerHTML = '';
    document.getElementById('payStatus').textContent = '⏳ 正在创建订单...';
    document.getElementById('payStatus').style.color = '#f0b90b';

    var fd = new FormData();
    fd.append('type', currentType);
    fd.append('method', method);
    fd.append('amount', currentAmount);
    fd.append('vip_plan_id', currentVipPlanId);

    fetch('/api/pay_create.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(function(res) {
            if (!res.success) {
                document.getElementById('payStatus').textContent = '❌ ' + res.msg;
                document.getElementById('payStatus').style.color = '#f85149';
                return;
            }
            currentOrderId = res.order_id;
            document.getElementById('qrcodeBox').innerHTML = '';
            new QRCode(document.getElementById('qrcodeBox'), {
                text: res.qr,
                width: 220,
                height: 220,
                correctLevel: QRCode.CorrectLevel.M
            });
            document.getElementById('payStatus').textContent = '⏳ 等待支付...';
            document.getElementById('payStatus').style.color = '#f0b90b';
            document.getElementById('payAmount').textContent = '¥' + res.amount.toFixed(2);

            if (queryTimer) clearInterval(queryTimer);
            queryTimer = setInterval(function() {
                fetch('/api/pay_query.php?order_id=' + currentOrderId)
                    .then(r => r.json())
                    .then(function(q) {
                        if (q.success && q.pay_status === 'paid') {
                            clearInterval(queryTimer);
                            document.getElementById('payStatus').textContent = '✅ 支付成功！';
                            document.getElementById('payStatus').style.color = '#3fb950';
                            setTimeout(function() { location.reload(); }, 2000);
                        }
                    });
            }, 3000);
        })
        .catch(function() {
            document.getElementById('payStatus').textContent = '❌ 网络错误';
            document.getElementById('payStatus').style.color = '#f85149';
        });
}

document.getElementById('proofFile').addEventListener('change', function() {
    var file = this.files[0];
    if (!file) return;
    var fd = new FormData();
    fd.append('file', file);
    fetch('/admin/upload.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(function(res) {
            if (res.success) {
                proofUrl = res.url;
                document.getElementById('proofName').textContent = '✅ 截图已上传';
                document.getElementById('proofName').style.display = 'block';
            }
        });
});

function submitOrder() {
    var account = document.getElementById('payAccountInput').value.trim();
    if (!account) {
        document.getElementById('payStatus').textContent = '请填写付款账号后4位';
        document.getElementById('payStatus').style.color = '#f85149';
        return;
    }
    var fd = new FormData();
    fd.append('type', currentType);
    fd.append('amount', currentAmount);
    fd.append('vip_plan_id', currentVipPlanId);
    fd.append('pay_method', currentMethod);
    fd.append('pay_account', account);
    fd.append('pay_proof', proofUrl);

    fetch('/api/recharge_submit.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(function(res) {
            if (res.success) {
                alert('提交成功！管理员审核通过后积分/VIP将自动到账');
                location.reload();
            } else {
                document.getElementById('payStatus').textContent = res.msg || '提交失败';
                document.getElementById('payStatus').style.color = '#f85149';
            }
        });
}

function closePay() {
    if (queryTimer) clearInterval(queryTimer);
    document.getElementById('payModal').style.display = 'none';
}

function buyVipByIntegral(planId) {
    if (!confirm('确定用积分购买该 VIP 套餐？')) return;
    fetch('/api/vip_buy.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'plan_id=' + planId
    })
    .then(r => r.json())
    .then(function(res) { alert(res.msg); if (res.success) location.reload(); });
}
</script>

<?php include __DIR__.'/footer.php'; ?>
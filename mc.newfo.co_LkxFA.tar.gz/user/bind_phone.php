<?php
include __DIR__.'/header.php';

$msg = '';
$msgType = '';

// 生成/刷新验证码
if (empty($_SESSION['sms_code']) || isset($_GET['refresh'])) {
    $_SESSION['sms_code'] = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $_SESSION['sms_code_time'] = time();
}

// 处理绑定
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');
    $code  = trim($_POST['code'] ?? '');

    if (empty($phone)) {
        $msg = '请填写手机号'; $msgType = 'err';
    } elseif (!preg_match('/^1[3-9]\d{9}$/', $phone)) {
        $msg = '手机号格式不正确'; $msgType = 'err';
    } elseif ($code !== $_SESSION['sms_code']) {
        $msg = '验证码错误'; $msgType = 'err';
    } else {
        // 检查手机号是否已被其他账号使用
        $exists = DB::one("SELECT id FROM user WHERE phone=? AND id!=?", [$phone, $uid]);
        if ($exists) {
            $msg = '该手机号已被其他账号绑定'; $msgType = 'err';
        } else {
            DB::exec("UPDATE user SET phone=?, phone_verified=1, updated_at=? WHERE id=?",
                [$phone, time(), $uid]);
            unset($_SESSION['sms_code'], $_SESSION['sms_code_time']);
            $msg = '✅ 手机绑定成功'; $msgType = 'ok';
            $currentUser = DB::one("SELECT * FROM user WHERE id=?", [$uid]);
        }
    }
}
?>

<h1><i class="fa-solid fa-mobile-screen"></i> 手机绑定</h1>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= h($msg) ?></div><?php endif; ?>

<?php if (!empty($currentUser['phone_verified']) && !empty($currentUser['phone'])): ?>
    <div style="background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:24px;max-width:520px;">
        <div style="font-size:16px;color:#3fb950;font-weight:700;margin-bottom:16px;">✅ 已绑定手机</div>
        <div style="font-size:16px;color:#c9d1d9;margin-bottom:20px;"><?= h(substr($currentUser['phone'], 0, 3)) . '****' . substr($currentUser['phone'], -4) ?></div>
        <a href="?rebind=1" class="btn" style="background:#30363d;color:#c9d1d9;">更换手机号</a>
    </div>
    <?php if (!isset($_GET['rebind'])) exit; ?>
<?php endif; ?>

<div style="background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:24px;max-width:520px;">
    <p style="color:#8a99ad;font-size:13px;margin-bottom:20px;line-height:1.8;">
        ⚠️ 当前未接入短信服务，验证码在本页面上显示。<br>
        正式上线后请接入短信服务商（阿里云短信、腾讯云短信等）。
    </p>

    <div style="background:#161b22;border:1px solid #00f3ff33;border-radius:8px;padding:14px;margin-bottom:20px;text-align:center;">
        <div style="font-size:12px;color:#8a99ad;margin-bottom:6px;">当前验证码（仅测试用）</div>
        <div style="font-size:24px;font-weight:700;color:#00f3ff;letter-spacing:6px;font-family:monospace;"><?= $_SESSION['sms_code'] ?></div>
        <a href="?refresh=1" style="display:inline-block;margin-top:8px;font-size:12px;color:#8a99ad;">🔄 刷新验证码</a>
    </div>

    <form method="post">
        <div class="form-group">
            <label>手机号 <span style="color:#f85149;">*</span></label>
            <input type="text" name="phone" placeholder="11位手机号" required maxlength="11" value="<?= h($_POST['phone'] ?? $currentUser['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>验证码 <span style="color:#f85149;">*</span></label>
            <input type="text" name="code" placeholder="6位验证码" required maxlength="6" style="letter-spacing:4px;font-family:monospace;">
        </div>
        <button type="submit" class="btn">确认绑定</button>
    </form>
</div>

<?php include __DIR__.'/footer.php'; ?>
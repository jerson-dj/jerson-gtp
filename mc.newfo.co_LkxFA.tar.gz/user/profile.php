<?php
include __DIR__.'/header.php';

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nickname = trim($_POST['nickname'] ?? '');
    $gender   = (int)($_POST['gender'] ?? 0);
    $birthday = trim($_POST['birthday'] ?? '');
    $realName = trim($_POST['real_name'] ?? '');
    $avatar   = trim($_POST['avatar'] ?? '');

    if (empty($nickname)) {
        $msg = '昵称不能为空'; $msgType = 'err';
    } else {
        DB::exec("UPDATE user SET nickname=?, gender=?, birthday=?, real_name=?, avatar=?, updated_at=? WHERE id=?",
            [$nickname, $gender, $birthday, $realName, $avatar, time(), $uid]);
        $_SESSION['user_name'] = $nickname;
        $currentUser = DB::one("SELECT * FROM user WHERE id=?", [$uid]);
        $msg = '保存成功'; $msgType = 'ok';
    }
}
?>

<h1><i class="fa-solid fa-user"></i> 修改资料</h1>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= h($msg) ?></div><?php endif; ?>

<form method="post">
    <div class="form-group">
        <label>昵称 <span style="color:#f85149;">*</span></label>
        <input type="text" name="nickname" value="<?= h($currentUser['nickname']) ?>" required>
    </div>

    <div class="form-group">
        <label>头像 URL</label>
        <input type="text" name="avatar" id="avatarInput" value="<?= h($currentUser['avatar']) ?>" placeholder="https://...">
        <div class="hint">建议 200x200 正方形图片</div>
        <div style="margin-top:10px;">
            <img id="avatarPreview" src="<?= h($currentUser['avatar'] ?: 'https://ui-avatars.com/api/?name='.urlencode($currentUser['nickname']).'&background=00f3ff&color=0a0a0f&size=128') ?>" style="width:80px;height:80px;border-radius:50%;border:2px solid #00f3ff;object-fit:cover;">
        </div>
    </div>

    <div class="form-group">
        <label>性别</label>
        <select name="gender">
            <option value="0" <?= $currentUser['gender']==0?'selected':'' ?>>保密</option>
            <option value="1" <?= $currentUser['gender']==1?'selected':'' ?>>男</option>
            <option value="2" <?= $currentUser['gender']==2?'selected':'' ?>>女</option>
        </select>
    </div>

    <div class="form-group">
        <label>生日</label>
        <input type="text" name="birthday" value="<?= h($currentUser['birthday']) ?>" placeholder="1990-01-01">
    </div>

    <div class="form-group">
        <label>真实姓名</label>
        <input type="text" name="real_name" value="<?= h($currentUser['real_name']) ?>" placeholder="用于实名认证">
    </div>

    <button type="submit" class="btn">保存修改</button>
</form>

<script>
document.getElementById('avatarInput').addEventListener('input', function() {
    document.getElementById('avatarPreview').src = this.value || 'https://ui-avatars.com/api/?name=<?= urlencode($currentUser['nickname']) ?>&background=00f3ff&color=0a0a0f&size=128';
});
</script>

<?php include __DIR__.'/footer.php'; ?>
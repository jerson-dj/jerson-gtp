<?php
include __DIR__.'/header.php';

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = $_POST['old_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $new2 = $_POST['new_password2'] ?? '';

    if (empty($old) || empty($new)) {
        $msg = '请填写完整'; $msgType = 'err';
    } elseif (!password_verify($old, $currentUser['password'])) {
        $msg = '原密码错误'; $msgType = 'err';
    } elseif (strlen($new) < 6) {
        $msg = '新密码至少6位'; $msgType = 'err';
    } elseif ($new !== $new2) {
        $msg = '两次新密码不一致'; $msgType = 'err';
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        DB::exec("UPDATE user SET password=? WHERE id=?", [$hash, $uid]);
        $msg = '密码修改成功，请牢记新密码'; $msgType = 'ok';
    }
}
?>

<h1><i class="fa-solid fa-lock"></i> 修改密码</h1>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= h($msg) ?></div><?php endif; ?>

<form method="post" style="max-width:480px;">
    <div class="form-group">
        <label>原密码</label>
        <input type="password" name="old_password" required>
    </div>
    <div class="form-group">
        <label>新密码</label>
        <input type="password" name="new_password" placeholder="至少6位" required>
    </div>
    <div class="form-group">
        <label>确认新密码</label>
        <input type="password" name="new_password2" required>
    </div>
    <button type="submit" class="btn">确认修改</button>
</form>

<?php include __DIR__.'/footer.php'; ?>
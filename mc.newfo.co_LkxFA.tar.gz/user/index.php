<?php include __DIR__.'/header.php'; ?>

<h1><i class="fa-solid fa-house"></i> 会员中心</h1>

<div class="stats">
    <div class="stat-card">
        <div class="label">⚡ 我的积分</div>
        <div class="value gold"><?= (int)$currentUser['integral'] ?></div>
    </div>
    <div class="stat-card">
        <div class="label">📝 我的文章</div>
        <div class="value"><?= DB::one("SELECT COUNT(*) c FROM article WHERE author=? OR cate_id=0 AND author=?", [$currentUser['nickname'], $currentUser['nickname']])['c'] ?: 0 ?></div>
    </div>
    <div class="stat-card">
        <div class="label">👥 邀请好友</div>
        <div class="value"><?= DB::one("SELECT COUNT(*) c FROM user WHERE invite_from=?", [$uid])['c'] ?: 0 ?></div>
    </div>
    <div class="stat-card">
        <div class="label">📅 注册天数</div>
        <div class="value"><?= floor((time() - $currentUser['created_at']) / 86400) ?> 天</div>
    </div>
</div>

<h1 style="font-size:16px;"><i class="fa-solid fa-circle-info"></i> 账户信息</h1>
<table>
    <tr><th style="width:160px;">昵称</th><td><?= h($currentUser['nickname']) ?></td></tr>
    <tr><th>手机号</th><td><?= h($currentUser['phone'] ?: '未绑定') ?></td></tr>
    <tr><th>邮箱</th><td><?= h($currentUser['email'] ?: '未绑定') ?></td></tr>
    <tr><th>VIP状态</th><td>
        <?php if (!empty($currentUser['vip_level']) && $currentUser['vip_expire'] > time()): ?>
            👑 VIP<?= (int)$currentUser['vip_level'] ?> · 到期：<?= date('Y-m-d', $currentUser['vip_expire']) ?>
        <?php else: ?>
            普通会员
        <?php endif; ?>
    </td></tr>
    <tr><th>实名认证</th><td><?= $currentUser['is_verified'] ? '✅ 已认证' : '<span style="color:#8a99ad;">未认证</span>' ?></td></tr>
    <tr><th>注册时间</th><td><?= date('Y-m-d H:i', $currentUser['created_at']) ?></td></tr>
    <tr><th>最后登录</th><td><?= $currentUser['last_login'] ? date('Y-m-d H:i', $currentUser['last_login']) : '-' ?></td></tr>
</table>

<?php include __DIR__.'/footer.php'; ?>
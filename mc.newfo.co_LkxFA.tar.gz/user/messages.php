<?php
include __DIR__.'/header.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$ps = 15;

$total = DB::one("SELECT COUNT(*) c FROM user_message WHERE user_id=?", [$uid])['c'];
$list  = DB::query(
    "SELECT m.*, a.title article_title 
     FROM user_message m 
     LEFT JOIN article a ON m.article_id = a.id 
     WHERE m.user_id=? 
     ORDER BY m.id DESC 
     LIMIT ".($page-1)*$ps.",$ps",
    [$uid]
);
?>

<h1><i class="fa-solid fa-comments"></i> 我的留言</h1>

<?php if (empty($list)): ?>
    <p style="color:#8a99ad;text-align:center;padding:60px;">还没有发表过留言</p>
<?php else: ?>
<?php foreach ($list as $m): ?>
<div style="background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:18px;margin-bottom:14px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <div style="font-size:13px;color:#8a99ad;">
            <?php if ($m['article_title']): ?>
                评论于 <a href="/post_view.php?id=<?= $m['article_id'] ?>" target="_blank">《<?= h($m['article_title']) ?>》</a>
            <?php else: ?>
                独立留言
            <?php endif; ?>
        </div>
        <div style="font-size:12px;color:#8a99ad;"><?= date('Y-m-d H:i', $m['created_at']) ?></div>
    </div>
    <div style="font-size:14px;line-height:1.7;color:#c9d1d9;margin-bottom:10px;"><?= nl2br(h($m['content'])) ?></div>
    <?php if (!empty($m['reply'])): ?>
    <div style="background:#161b22;border-left:3px solid #00f3ff;padding:12px 14px;border-radius:6px;margin-top:10px;">
        <div style="font-size:12px;color:#00f3ff;margin-bottom:6px;">管理员回复：</div>
        <div style="font-size:13px;color:#c9d1d9;line-height:1.6;"><?= nl2br(h($m['reply'])) ?></div>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php
$totalPage = ceil($total / $ps);
if ($totalPage > 1):
?>
<div style="margin-top:20px;display:flex;gap:8px;justify-content:center;">
    <?php for ($i=1; $i<=$totalPage; $i++): ?>
    <a href="?page=<?= $i ?>" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:<?= $i==$page?'#0a0a0f':'#8a99ad' ?>;<?= $i==$page?'background:#00f3ff;font-weight:700;':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
<?php
require_once __DIR__.'/../include/pay.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'msg' => '请先登录']); exit;
}

$uid = $_SESSION['user_id'];
$orderId = (int)($_GET['order_id'] ?? 0);

$order = DB::one("SELECT * FROM recharge_order WHERE id=? AND user_id=?", [$orderId, $uid]);
if (!$order) {
    echo json_encode(['success' => false, 'msg' => '订单不存在']); exit;
}

echo json_encode([
    'success' => true,
    'order_no' => $order['order_no'],
    'pay_status' => $order['pay_status'],
    'status' => (int)$order['status'],
    'amount' => $order['amount_money'],
]);
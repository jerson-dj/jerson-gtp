<?php
require_once __DIR__.'/../include/pay.php';

$logFile = '/tmp/alipay_notify.log';

try {
    $cfg = pay_config();

    if (empty($cfg['alipay_app_id'])) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 未配置支付宝\n", FILE_APPEND);
        echo 'fail'; exit;
    }

    $config = new \Alipay\EasySDK\Kernel\Config();
    $config->protocol = 'https';
    $config->gatewayHost = 'openapi.alipay.com';
    $config->signType = 'RSA2';
    $config->appId = $cfg['alipay_app_id'];
    $config->merchantPrivateKey = $cfg['alipay_private_key'];
    $config->alipayPublicKey = $cfg['alipay_public_key'];

    \Alipay\EasySDK\Kernel\Factory::setOptions($config);

    // 1. 验证签名
    $verify = \Alipay\EasySDK\Kernel\Factory::payment()->common()->verifyNotify($_POST);
    if (!$verify) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 签名验证失败\n", FILE_APPEND);
        echo 'fail'; exit;
    }

    // 2. 检查交易状态
    $tradeStatus = $_POST['trade_status'] ?? '';
    if ($tradeStatus !== 'TRADE_SUCCESS' && $tradeStatus !== 'TRADE_FINISHED') {
        echo 'success'; exit;
    }

    $orderNo = $_POST['out_trade_no'] ?? '';
    $tradeNo = $_POST['trade_no'] ?? '';
    $notifyAmount = (float)($_POST['total_amount'] ?? 0);

    file_put_contents($logFile, date('Y-m-d H:i:s')." 订单 $orderNo 交易号 $tradeNo 金额 $notifyAmount\n", FILE_APPEND);

    // 3. 查找订单
    $order = DB::one("SELECT * FROM recharge_order WHERE order_no=?", [$orderNo]);
    if (!$order) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 订单不存在: $orderNo\n", FILE_APPEND);
        echo 'fail'; exit;
    }

    // 4. 校验金额
    if (abs($notifyAmount - (float)$order['amount_money']) > 0.01) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 金额不符: 通知=$notifyAmount 订单={$order['amount_money']}\n", FILE_APPEND);
        echo 'fail'; exit;
    }

    // 5. 记录交易号
    DB::exec("UPDATE recharge_order SET trade_no=? WHERE id=?", [$tradeNo, $order['id']]);

    // 6. 发放积分/VIP
    $result = pay_grant($order);
    if (!$result['success']) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 发放失败: {$result['msg']}\n", FILE_APPEND);
        echo 'fail'; exit;
    }

    file_put_contents($logFile, date('Y-m-d H:i:s')." 处理成功: $orderNo\n", FILE_APPEND);
    echo 'success';
} catch (Exception $e) {
    file_put_contents($logFile, date('Y-m-d H:i:s')." 异常: ".$e->getMessage()."\n", FILE_APPEND);
    echo 'fail';
}
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'msg' => '请先登录']);
    exit;
}

$uid = $_SESSION['user_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$articleId = (int)($_POST['article_id'] ?? $_GET['article_id'] ?? 0);

if (!$articleId) {
    echo json_encode(['success' => false, 'msg' => '参数错误']);
    exit;
}

$exists = DB::one("SELECT id FROM user_favorite WHERE user_id=? AND article_id=?", [$uid, $articleId]);

if ($action === 'add') {
    if ($exists) {
        echo json_encode(['success' => true, 'msg' => '已收藏']);
        exit;
    }
    DB::insert("INSERT INTO user_favorite (user_id, article_id, created_at) VALUES (?,?,?)",
        [$uid, $articleId, time()]);
    echo json_encode(['success' => true, 'msg' => '收藏成功']);
} elseif ($action === 'remove') {
    if ($exists) {
        DB::exec("DELETE FROM user_favorite WHERE user_id=? AND article_id=?", [$uid, $articleId]);
        echo json_encode(['success' => true, 'msg' => '已取消收藏']);
    } else {
        echo json_encode(['success' => false, 'msg' => '尚未收藏']);
    }
} elseif ($action === 'toggle') {
    if ($exists) {
        DB::exec("DELETE FROM user_favorite WHERE user_id=? AND article_id=?", [$uid, $articleId]);
        echo json_encode(['success' => true, 'favorited' => false, 'msg' => '已取消收藏']);
    } else {
        DB::insert("INSERT INTO user_favorite (user_id, article_id, created_at) VALUES (?,?,?)",
            [$uid, $articleId, time()]);
        echo json_encode(['success' => true, 'favorited' => true, 'msg' => '收藏成功']);
    }
} else {
    echo json_encode(['success' => false, 'msg' => '无效操作']);
}
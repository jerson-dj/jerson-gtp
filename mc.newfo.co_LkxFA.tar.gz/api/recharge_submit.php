<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success'=>false,'msg'=>'请先登录']); exit;
}

$uid = $_SESSION['user_id'];
$type = $_POST['type'] ?? '';
$amount = (float)($_POST['amount'] ?? 0);
$vipPlanId = (int)($_POST['vip_plan_id'] ?? 0);
$payMethod = $_POST['pay_method'] ?? 'alipay';
$payAccount = trim($_POST['pay_account'] ?? '');
$payProof = trim($_POST['pay_proof'] ?? '');

if (!in_array($type, ['integral','vip'])) {
    echo json_encode(['success'=>false,'msg'=>'类型错误']); exit;
}
if ($amount <= 0) {
    echo json_encode(['success'=>false,'msg'=>'金额无效']); exit;
}
if (empty($payAccount)) {
    echo json_encode(['success'=>false,'msg'=>'请填写付款账号后4位']); exit;
}

$cfg = [];
foreach (DB::query("SELECT * FROM setting") as $row) $cfg[$row['key']] = $row['value'];
$rate = (int)($cfg['integral_rate'] ?? 100);

$integralAmount = $type === 'integral' ? (int)($amount * $rate) : 0;

$orderNo = date('YmdHis') . rand(1000, 9999);

DB::insert(
    "INSERT INTO recharge_order (order_no,user_id,type,amount_money,integral_amount,vip_plan_id,pay_method,pay_account,pay_proof,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,0,?)",
    [$orderNo, $uid, $type, $amount, $integralAmount, $vipPlanId, $payMethod, $payAccount, $payProof, time()]
);

echo json_encode(['success'=>true, 'msg'=>'提交成功', 'order_no'=>$orderNo]);
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
header('Content-Type: application/json; charset=utf-8');
$cateId=(int)($_GET['cate_id']??0);
$sql="SELECT id,title,artist,cover,file_url,source_type,duration,play_count FROM audio WHERE status=1";
$p=[]; if($cateId){ $sql.=" AND cate_id=?"; $p[]=$cateId; }
$sql.=" ORDER BY sort,id DESC LIMIT 50";
echo json_encode(['data'=>DB::query($sql,$p)]);
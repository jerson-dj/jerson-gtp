<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success'=>false, 'msg'=>'请先登录']); exit;
}

$uid = $_SESSION['user_id'];
$planId = (int)($_POST['plan_id'] ?? 0);
$plan = DB::one("SELECT * FROM vip_plan WHERE id=? AND status=1", [$planId]);

if (!$plan) {
    echo json_encode(['success'=>false, 'msg'=>'套餐不存在']); exit;
}

$user = DB::one("SELECT * FROM user WHERE id=?", [$uid]);
if ($user['integral'] < $plan['price_integral']) {
    echo json_encode(['success'=>false, 'msg'=>'积分不足，当前 '.$user['integral'].' 积分，需要 '.$plan['price_integral'].' 积分']); exit;
}

DB::conn()->beginTransaction();
try {
    DB::exec("UPDATE user SET integral=integral-?, vip_level=?, vip_expire=?, updated_at=? WHERE id=?",
        [$plan['price_integral'], $plan['level'], max(time(), $user['vip_expire']) + $plan['days']*86400, time(), $uid]);
    DB::insert("INSERT INTO integral_log (user_id, amount, reason, created_at) VALUES (?,?,?,?)",
        [$uid, -$plan['price_integral'], '购买 '.$plan['name'], time()]);
    DB::insert("INSERT INTO recharge_log (user_id, type, amount, remark, created_at) VALUES (?,'vip',?,?,?)",
        [$uid, $plan['days'], '积分购买：'.$plan['name'], time()]);
    DB::conn()->commit();
    echo json_encode(['success'=>true, 'msg'=>'开通成功！'.$plan['name']]);
} catch (Exception $e) {
    DB::conn()->rollBack();
    echo json_encode(['success'=>false, 'msg'=>'失败：'.$e->getMessage()]);
}
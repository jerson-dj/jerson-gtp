<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){ echo json_encode(['success'=>false,'msg'=>'无效请求']); exit; }
$title=trim($_POST['title']??''); $content=trim($_POST['content']??''); $cateId=(int)($_POST['cate_id']??0);
if(empty($title)||empty($content)){ echo json_encode(['success'=>false,'msg'=>'标题和内容不能为空']); exit; }
$id=DB::insert("INSERT INTO article (cate_id,title,content,type,status,created_at) VALUES (?,?,?,'article',0,?)",[$cateId,$title,$content,time()]);
echo json_encode(['success'=>true,'msg'=>'提交成功，等待审核','id'=>$id]);
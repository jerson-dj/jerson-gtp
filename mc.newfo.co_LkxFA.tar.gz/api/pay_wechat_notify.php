<?php
require_once __DIR__.'/../include/pay.php';

$logFile = '/tmp/wechat_notify.log';

try {
    $cfg = pay_config();

    $apiv3Key = $cfg['wechat_apiv3_key'] ?? '';
    $platformCertPath = $cfg['wechat_platform_cert_path'] ?? '';

    if (empty($apiv3Key) || !file_exists($platformCertPath)) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 配置不完整\n", FILE_APPEND);
        http_response_code(500);
        echo json_encode(['code'=>'FAIL','message'=>'配置不完整']); exit;
    }

    // 1. 获取 HTTP 头
    $signature = $_SERVER['HTTP_WECHATPAY_SIGNATURE'] ?? '';
    $timestamp = $_SERVER['HTTP_WECHATPAY_TIMESTAMP'] ?? '';
    $nonce = $_SERVER['HTTP_WECHATPAY_NONCE'] ?? '';
    $serial = $_SERVER['HTTP_WECHATPAY_SERIAL'] ?? '';
    $body = file_get_contents('php://input');

    if (!$signature || !$timestamp || !$nonce || !$body) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 缺少必要参数\n", FILE_APPEND);
        echo json_encode(['code'=>'FAIL','message'=>'缺少参数']); exit;
    }

    // 2. 验证签名
    $platformPublicKey = \WeChatPay\Crypto\Rsa::from(
        'file://' . $platformCertPath,
        \WeChatPay\Crypto\Rsa::KEY_TYPE_PUBLIC
    );

    $message = "$timestamp\n$nonce\n$body\n";
    $verify = \WeChatPay\Crypto\Rsa::verify($message, $signature, $platformPublicKey);
    if (!$verify) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 签名验证失败\n", FILE_APPEND);
        echo json_encode(['code'=>'FAIL','message'=>'签名验证失败']); exit;
    }

    // 3. 解密 resource
    $data = json_decode($body, true);
    $resource = $data['resource'] ?? [];
    $ciphertext = base64_decode($resource['ciphertext'] ?? '');
    $nonceStr = $resource['nonce'] ?? '';
    $associatedData = $resource['associated_data'] ?? '';

    $plaintext = \WeChatPay\Crypto\AesGcm::decrypt($ciphertext, $apiv3Key, $nonceStr, $associatedData);
    $result = json_decode($plaintext, true);

    file_put_contents($logFile, date('Y-m-d H:i:s')." 解密: ".json_encode($result, JSON_UNESCAPED_UNICODE)."\n", FILE_APPEND);

    // 4. 检查交易状态
    $tradeState = $result['trade_state'] ?? '';
    if ($tradeState !== 'SUCCESS') {
        echo json_encode(['code'=>'SUCCESS','message'=>'已接收']); exit;
    }

    $orderNo = $result['out_trade_no'] ?? '';
    $tradeNo = $result['transaction_id'] ?? '';
    $totalFen = (int)($result['amount']['total'] ?? 0);
    $notifyAmount = $totalFen / 100;

    // 5. 查找订单
    $order = DB::one("SELECT * FROM recharge_order WHERE order_no=?", [$orderNo]);
    if (!$order) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 订单不存在: $orderNo\n", FILE_APPEND);
        echo json_encode(['code'=>'FAIL','message'=>'订单不存在']); exit;
    }

    // 6. 校验金额
    if (abs($notifyAmount - (float)$order['amount_money']) > 0.01) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 金额不符\n", FILE_APPEND);
        echo json_encode(['code'=>'FAIL','message'=>'金额不符']); exit;
    }

    // 7. 记录交易号
    DB::exec("UPDATE recharge_order SET trade_no=? WHERE id=?", [$tradeNo, $order['id']]);

    // 8. 发放
    $grantResult = pay_grant($order);
    if (!$grantResult['success']) {
        file_put_contents($logFile, date('Y-m-d H:i:s')." 发放失败: {$grantResult['msg']}\n", FILE_APPEND);
        echo json_encode(['code'=>'FAIL','message'=>$grantResult['msg']]); exit;
    }

    file_put_contents($logFile, date('Y-m-d H:i:s')." 处理成功: $orderNo\n", FILE_APPEND);
    echo json_encode(['code'=>'SUCCESS','message'=>'成功']);
} catch (Exception $e) {
    file_put_contents($logFile, date('Y-m-d H:i:s')." 异常: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['code'=>'FAIL','message'=>$e->getMessage()]);
}
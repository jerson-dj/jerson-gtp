<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

// 检查开关
$cfg = [];
foreach (DB::query("SELECT * FROM setting") as $row) $cfg[$row['key']] = $row['value'];
if (($cfg['like_enabled'] ?? '1') !== '1') {
    echo json_encode(['success'=>false, 'msg'=>'点赞功能已关闭']); exit;
}

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success'=>false, 'msg'=>'请先登录']); exit;
}

$uid = $_SESSION['user_id'];
$articleId = (int)($_POST['article_id'] ?? 0);

if (!$articleId) {
    echo json_encode(['success'=>false, 'msg'=>'参数错误']); exit;
}

$exists = DB::one("SELECT id FROM article_like WHERE user_id=? AND article_id=?", [$uid, $articleId]);

if ($exists) {
    DB::exec("DELETE FROM article_like WHERE user_id=? AND article_id=?", [$uid, $articleId]);
    $liked = false;
} else {
    DB::insert("INSERT INTO article_like (user_id, article_id, created_at) VALUES (?,?,?)", [$uid, $articleId, time()]);
    $liked = true;
}

$count = DB::one("SELECT COUNT(*) c FROM article_like WHERE article_id=?", [$articleId])['c'];

echo json_encode(['success'=>true, 'liked'=>$liked, 'count'=>$count]);
<?php
require_once __DIR__.'/../include/pay.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'msg' => '请先登录']); exit;
}

$uid = $_SESSION['user_id'];
$type = $_POST['type'] ?? '';
$method = $_POST['method'] ?? '';
$amount = (float)($_POST['amount'] ?? 0);
$vipPlanId = (int)($_POST['vip_plan_id'] ?? 0);

if (!in_array($type, ['integral', 'vip'])) {
    echo json_encode(['success' => false, 'msg' => '类型错误']); exit;
}
if (!in_array($method, ['alipay', 'wechat'])) {
    echo json_encode(['success' => false, 'msg' => '支付方式错误']); exit;
}

$cfg = pay_config();
$rate = (int)($cfg['integral_rate'] ?? 100);

// 计算订单金额和积分
$subject = '';
$integralAmount = 0;
if ($type === 'integral') {
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'msg' => '金额无效']); exit;
    }
    $integralAmount = (int)($amount * $rate);
    $subject = "积分充值 ¥{$amount}";
} else {
    $plan = DB::one("SELECT * FROM vip_plan WHERE id=? AND status=1", [$vipPlanId]);
    if (!$plan) {
        echo json_encode(['success' => false, 'msg' => '套餐不存在']); exit;
    }
    $amount = (float)$plan['price_money'];
    $subject = "开通VIP：{$plan['name']}";
}

$orderNo = pay_gen_order_no();

// 创建订单
$orderId = DB::insert(
    "INSERT INTO recharge_order (order_no, user_id, type, amount_money, integral_amount, vip_plan_id, pay_method, pay_status, status, created_at) VALUES (?,?,?,?,?,?,?,?,0,?)",
    [$orderNo, $uid, $type, $amount, $integralAmount, $vipPlanId, $method, 'pending', time()]
);

// ============ 支付宝 ============
if ($method === 'alipay') {
    try {
        $config = new \Alipay\EasySDK\Kernel\Config();
        $config->protocol = 'https';
        $config->gatewayHost = 'openapi.alipay.com';
        $config->signType = 'RSA2';
        $config->appId = $cfg['alipay_app_id'] ?? '';
        $config->merchantPrivateKey = $cfg['alipay_private_key'] ?? '';
        $config->alipayPublicKey = $cfg['alipay_public_key'] ?? '';
        $config->notifyUrl = $cfg['alipay_notify_url'] ?? '';

        \Alipay\EasySDK\Kernel\Factory::setOptions($config);

        $result = \Alipay\EasySDK\Kernel\Factory::payment()->common()
            ->create($subject, $orderNo, number_format($amount, 2, '.', ''));

        if ($result->code !== '10000') {
            echo json_encode(['success' => false, 'msg' => '支付宝创建失败：'.$result->subMsg]); exit;
        }

        $qrCode = $result->qrCode;
        DB::exec("UPDATE recharge_order SET pay_qr=? WHERE id=?", [$qrCode, $orderId]);

        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'order_no' => $orderNo,
            'qr' => $qrCode,
            'amount' => $amount,
            'pay_method' => 'alipay',
        ]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'msg' => '支付宝异常：'.$e->getMessage()]);
    }
    exit;
}

// ============ 微信 Native 支付 ============
if ($method === 'wechat') {
    try {
        $mchid = $cfg['wechat_mchid'] ?? '';
        $appid = $cfg['wechat_appid'] ?? '';
        $serial = $cfg['wechat_serial_no'] ?? '';
        $keyPath = $cfg['wechat_private_key_path'] ?? '';

        if (!$mchid || !$appid || !$serial || !file_exists($keyPath)) {
            echo json_encode(['success' => false, 'msg' => '微信支付配置不完整']); exit;
        }

        $merchantPrivateKey = \WeChatPay\Crypto\Rsa::from(
            'file://' . $keyPath,
            \WeChatPay\Crypto\Rsa::KEY_TYPE_PRIVATE
        );

        // 加载平台证书（首次需调用 /v3/certificates 获取）
        $platformCertPath = $cfg['wechat_platform_cert_path'] ?? '';
        $platformSerial = $cfg['wechat_platform_serial'] ?? '';

        if (!$platformCertPath || !file_exists($platformCertPath)) {
            echo json_encode(['success' => false, 'msg' => '请先在后台配置微信平台证书']); exit;
        }

        $platformPublicKey = \WeChatPay\Crypto\Rsa::from(
            'file://' . $platformCertPath,
            \WeChatPay\Crypto\Rsa::KEY_TYPE_PUBLIC
        );

        $instance = \WeChatPay\Builder::factory([
            'mchid' => $mchid,
            'serial' => $serial,
            'privateKey' => $merchantPrivateKey,
            'certs' => [
                $platformSerial => $platformPublicKey,
            ],
        ]);

        $totalFen = (int)round($amount * 100);

        $resp = $instance->chain('v3/pay/transactions/native')->post([
            'json' => [
                'mchid' => $mchid,
                'out_trade_no' => $orderNo,
                'appid' => $appid,
                'description' => $subject,
                'notify_url' => $cfg['wechat_notify_url'] ?? '',
                'amount' => [
                    'total' => $totalFen,
                    'currency' => 'CNY',
                ],
            ],
        ]);

        $body = json_decode((string)$resp->getBody(), true);
        $codeUrl = $body['code_url'] ?? '';

        if (!$codeUrl) {
            echo json_encode(['success' => false, 'msg' => '微信下单失败']); exit;
        }

        DB::exec("UPDATE recharge_order SET pay_qr=? WHERE id=?", [$codeUrl, $orderId]);

        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'order_no' => $orderNo,
            'qr' => $codeUrl,
            'amount' => $amount,
            'pay_method' => 'wechat',
        ]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'msg' => '微信异常：'.$e->getMessage()]);
    }
    exit;
}

echo json_encode(['success' => false, 'msg' => '不支持的支付方式']);
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

// 调试日志
$logFile = '/tmp/comment_debug.log';
file_put_contents($logFile, date('Y-m-d H:i:s') . " POST=" . json_encode($_POST) . " GET=" . json_encode($_GET) . "\n", FILE_APPEND);

try {
    $cfg = [];
    foreach (DB::query("SELECT * FROM setting") as $row) $cfg[$row['key']] = $row['value'];

    if (($cfg['comment_enabled'] ?? '1') !== '1') {
        echo json_encode(['success'=>false, 'msg'=>'评论功能已关闭'], JSON_UNESCAPED_UNICODE); exit;
    }

    if (empty($_SESSION['user_id'])) {
        echo json_encode(['success'=>false, 'msg'=>'请先登录'], JSON_UNESCAPED_UNICODE); exit;
    }

    // 兼容 POST、GET
    $action = $_POST['action'] ?? $_GET['action'] ?? '';

    if ($action === 'add') {
        $uid = $_SESSION['user_id'];
        $articleId = (int)($_POST['article_id'] ?? 0);
        $parentId  = (int)($_POST['parent_id'] ?? 0);
        $content   = trim($_POST['content'] ?? '');

        if (!$articleId) { echo json_encode(['success'=>false, 'msg'=>'文章ID错误'], JSON_UNESCAPED_UNICODE); exit; }
        if (empty($content)) { echo json_encode(['success'=>false, 'msg'=>'内容不能为空'], JSON_UNESCAPED_UNICODE); exit; }
        if (mb_strlen($content) > 1500) { echo json_encode(['success'=>false, 'msg'=>'评论不超过500字'], JSON_UNESCAPED_UNICODE); exit; }

        $articleExists = DB::one("SELECT id FROM article WHERE id=?", [$articleId]);
        if (!$articleExists) { echo json_encode(['success'=>false, 'msg'=>'文章不存在'], JSON_UNESCAPED_UNICODE); exit; }

        $needAudit = ($cfg['comment_need_audit'] ?? '1') === '1';
        $status = $needAudit ? 0 : 1;

        $id = DB::insert(
            "INSERT INTO article_comment (user_id, article_id, parent_id, content, status, created_at) VALUES (?,?,?,?,?,?)",
            [$uid, $articleId, $parentId, $content, $status, time()]
        );

        echo json_encode([
            'success' => true,
            'id' => $id,
            'status' => $status,
            'need_audit' => $needAudit,
            'msg' => $needAudit ? '评论已提交，等待审核' : '评论成功'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'delete') {
        $uid = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);
        $comment = DB::one("SELECT * FROM article_comment WHERE id=? AND user_id=?", [$id, $uid]);
        if (!$comment) { echo json_encode(['success'=>false, 'msg'=>'评论不存在或无权限'], JSON_UNESCAPED_UNICODE); exit; }
        DB::exec("DELETE FROM article_comment WHERE id=?", [$id]);
        echo json_encode(['success'=>true, 'msg'=>'删除成功'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(['success'=>false, 'msg'=>'无效操作（action='.$action.'）'], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode(['success'=>false, 'msg'=>'服务器错误: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
<?php
header('Content-Type: application/json');

// 连接数据库（记得改成你的数据库账号密码）
$host = '127.0.0.1';
$db   = 'nightride';
$user = 'nightride';
$pass = 'nightride';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(['code' => 500, 'msg' => '数据库连接失败']);
    exit;
}

$keyword = $_GET['keyword'] ?? '';

if (empty($keyword)) {
    echo json_encode(['code' => 400, 'msg' => '关键词不能为空']);
    exit;
}

// 模糊查询（这里假设你有一张 articles 表，包含 title 和 content 字段）
$sql = "SELECT id, title FROM articles WHERE title LIKE :keyword OR content LIKE :keyword LIMIT 20";
$stmt = $pdo->prepare($sql);
$stmt->execute([':keyword' => "%{$keyword}%"]);
$results = $stmt->fetchAll();

// 注意：如果你有多个表（电台、频道、车主），需要在这里分别查询然后合并。

if ($results) {
    echo json_encode(['code' => 200, 'data' => $results]);
} else {
    echo json_encode(['code' => 404, 'msg' => '没有找到相关内容']);
}
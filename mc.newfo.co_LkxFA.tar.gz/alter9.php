<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';

$pdo = DB::conn();

$pdo->exec("CREATE TABLE IF NOT EXISTS `recharge_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('integral','vip') DEFAULT 'integral',
  `amount_money` decimal(10,2) DEFAULT 0.00,
  `integral_amount` int(11) DEFAULT 0,
  `vip_plan_id` int(11) DEFAULT 0,
  `pay_method` enum('alipay','wechat') DEFAULT 'alipay',
  `pay_account` varchar(100) DEFAULT NULL,
  `pay_proof` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0 COMMENT '0待审核 1已通过 2已拒绝',
  `admin_remark` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  `reviewed_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// 初始化收款设置
$defaults = [
    'alipay_qrcode'   => '',
    'wechat_qrcode'   => '',
    'integral_rate'   => '100',  // 1元 = 100积分
    'pay_remark'      => '付款后请填写付款账号后4位，管理员会尽快审核。',
];
foreach ($defaults as $k => $v) {
    $exists = $pdo->query("SELECT COUNT(*) FROM setting WHERE `key`='$k'")->fetchColumn();
    if (!$exists) {
        $stmt = $pdo->prepare("INSERT INTO setting (`key`,`value`) VALUES (?,?)");
        $stmt->execute([$k, $v]);
    }
}

echo "✅ 完成<br>已创建：recharge_order 表<br>已初始化：支付宝/微信收款码、积分比例配置<br>";
echo "<br><strong style='color:red;'>请立即删除 alter9.php</strong>";
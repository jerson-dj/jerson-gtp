<?php
session_start();
if (empty($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['error' => '未登录']);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['file'])) {
    echo json_encode(['error' => '没有文件']); exit;
}

$file = $_FILES['file'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed = ['jpg','jpeg','png','gif','webp','bmp'];

if (!in_array($ext, $allowed)) {
    echo json_encode(['error' => '仅支持 jpg/png/gif/webp/bmp']); exit;
}
if ($file['size'] > 5 * 1024 * 1024) {
    echo json_encode(['error' => '图片不能超过 5MB']); exit;
}

$uploadDir = __DIR__ . '/../uploads/cover/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$filename = date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$target = $uploadDir . $filename;

if (move_uploaded_file($file['tmp_name'], $target)) {
    echo json_encode([
        'success' => true,
        'url' => '/uploads/cover/' . $filename
    ]);
} else {
    echo json_encode(['error' => '上传失败']);
}
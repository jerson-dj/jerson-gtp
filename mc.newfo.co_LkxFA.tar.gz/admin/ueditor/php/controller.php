<?php
/**
 * UEditor 后端上传接口
 * 支持：图片 / 视频 / 音频 / 文件
 */

// 加载项目公共文件（用 __DIR__ 确保路径不受工作目录影响）
require_once __DIR__ . '/../../../include/config.php';
require_once __DIR__ . '/../../../include/db.php';
require_once __DIR__ . '/../../../include/function.php';

// 上传根目录与访问 URL
$uploadDir = __DIR__ . '/../../../uploads/ueditor/';
$uploadUrl = '/uploads/ueditor/';

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$action = $_GET['action'] ?? '';

// ============ 1. 返回配置信息（前端初始化时会请求） ============
if ($action === 'config') {
    $config = [
        'imageActionName'   => 'uploadimage',
        'imageFieldName'    => 'upfile',
        'imageMaxSize'      => 20480000,
        'imageAllowFiles'   => ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'],
        'imageUrlPrefix'    => '',
        'imagePathFormat'   => '/uploads/ueditor/image/{yyyy}{mm}{dd}/{time}{rand:6}',

        'videoActionName'   => 'uploadvideo',
        'videoFieldName'    => 'upfile',
        'videoMaxSize'      => 204800000,
        'videoAllowFiles'   => ['.mp4', '.mov', '.avi', '.mkv', '.flv'],
        'videoUrlPrefix'    => '',
        'videoPathFormat'   => '/uploads/ueditor/video/{yyyy}{mm}{dd}/{time}{rand:6}',

        'audioActionName'   => 'uploadaudio',
        'audioFieldName'    => 'upfile',
        'audioMaxSize'      => 20480000,
        'audioAllowFiles'   => ['.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac'],
        'audioUrlPrefix'    => '',
        'audioPathFormat'   => '/uploads/ueditor/audio/{yyyy}{mm}{dd}/{time}{rand:6}',

        'fileActionName'    => 'uploadfile',
        'fileFieldName'     => 'upfile',
        'fileMaxSize'       => 20480000,
        'fileAllowFiles'    => ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.zip', '.rar', '.7z'],
        'fileUrlPrefix'     => '',
        'filePathFormat'    => '/uploads/ueditor/file/{yyyy}{mm}{dd}/{time}{rand:6}',
    ];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($config);
    exit;
}

// ============ 2. 处理上传 ============
if (in_array($action, ['uploadimage', 'uploadvideo', 'uploadaudio', 'uploadfile'])) {
    header('Content-Type: application/json; charset=utf-8');

    if (empty($_FILES['upfile'])) {
        echo json_encode(['state' => '没有文件被上传']);
        exit;
    }

    $file = $_FILES['upfile'];
    $name = $file['name'];
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $mime = $file['type'] ?? '';

    // 各类型：允许的扩展名、MIME 类型、大小上限
    $allowMap = [
        'uploadimage' => [
            'ext'  => ['jpg','jpeg','png','gif','bmp','webp'],
            'mime' => ['image/jpeg','image/png','image/gif','image/bmp','image/webp'],
            'max'  => 20 * 1024 * 1024,
        ],
        'uploadvideo' => [
            'ext'  => ['mp4','mov','avi','mkv','flv'],
            'mime' => ['video/mp4','video/quicktime','video/x-msvideo','video/x-matroska','video/x-flv'],
            'max'  => 200 * 1024 * 1024,
        ],
        'uploadaudio' => [
            'ext'  => ['mp3','wav','ogg','m4a','aac','flac','wma','mpeg'],
            'mime' => [
                'audio/mpeg','audio/mp3','audio/wav','audio/x-wav',
                'audio/ogg','audio/mp4','audio/x-m4a','audio/aac',
                'audio/flac','audio/x-ms-wma'
            ],
            'max'  => 20 * 1024 * 1024,
        ],
        'uploadfile' => [
            'ext'  => ['pdf','doc','docx','xls','xlsx','zip','rar','7z'],
            'mime' => [],
            'max'  => 20 * 1024 * 1024,
        ],
    ];

    $rule = $allowMap[$action] ?? null;
    if (!$rule) {
        echo json_encode(['state' => '未知的上传类型']);
        exit;
    }

    // 扩展名 或 MIME 任一匹配即通过（避免某些浏览器上传 mp3 时 MIME 识别不准）
    $extOk  = in_array($ext, $rule['ext']);
    $mimeOk = !empty($rule['mime']) && in_array($mime, $rule['mime']);

    if (!$extOk && !$mimeOk) {
        // 记录被拒绝的文件信息，便于排查
        @file_put_contents(
            '/tmp/upload_reject.log',
            date('Y-m-d H:i:s') . " 拒绝上传: name={$name} ext={$ext} mime={$mime} action={$action}\n",
            FILE_APPEND
        );
        echo json_encode(['state' => "不支持的文件格式: 扩展名={$ext} MIME={$mime}"]);
        exit;
    }

    if ($file['size'] > $rule['max']) {
        echo json_encode(['state' => '文件大小超出限制（最大 ' . round($rule['max'] / 1024 / 1024) . 'MB）']);
        exit;
    }

    // 根据类型决定子目录
    $subDir = str_replace('upload', '', $action); // image / video / audio / file
    $dateDir = date('Ymd');
    $saveDir = $uploadDir . $subDir . '/' . $dateDir . '/';
    if (!is_dir($saveDir)) {
        mkdir($saveDir, 0755, true);
    }

    // 生成唯一文件名
    $safeExt  = $ext ?: 'bin';
    $filename = date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $safeExt;
    $savePath = $saveDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $savePath)) {
        $url = $uploadUrl . $subDir . '/' . $dateDir . '/' . $filename;
        echo json_encode(['state' => 'SUCCESS', 'url' => $url]);
    } else {
        echo json_encode(['state' => '文件保存失败，请检查目录权限']);
    }
    exit;
}

// ============ 3. 其他请求 ============
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['state' => '无效的请求']);
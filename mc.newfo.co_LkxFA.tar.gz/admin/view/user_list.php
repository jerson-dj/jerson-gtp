<?php include __DIR__.'/header.php'; ?>

<h1>用户管理 <a href="index.php?action=user&do=edit" class="btn">+ 新增用户</a></h1>

<form method="get" class="search-bar">
    <input type="hidden" name="action" value="user">
    <input type="text" name="keyword" placeholder="搜索昵称或手机号..." value="<?= h($keyword) ?>">
    <button type="submit" class="btn-sm">搜索</button>
    <?php if ($keyword): ?>
        <a href="index.php?action=user" class="btn-sm" style="background:#30363d;color:#c9d1d9;">清空</a>
    <?php endif; ?>
</form>

<table>
<thead>
    <tr>
        <th>ID</th>
        <th>头像</th>
        <th>昵称</th>
        <th>手机号</th>
        <th>积分</th>
        <th>注册时间</th>
        <th>操作</th>
    </tr>
</thead>
<tbody>
<?php if (empty($list)): ?>
    <tr><td colspan="7" style="text-align:center;color:#8b949e;padding:30px;">暂无用户数据</td></tr>
<?php endif; ?>
<?php foreach ($list as $u): ?>
<tr>
    <td><?= $u['id'] ?></td>
    <td>
        <?php if ($u['avatar']): ?>
            <img src="<?= h($u['avatar']) ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
        <?php else: ?>
            <span style="display:inline-block;width:36px;height:36px;border-radius:50%;background:#30363d;text-align:center;line-height:36px;color:#8b949e;">?</span>
        <?php endif; ?>
    </td>
    <td><?= h($u['nickname']) ?></td>
    <td><?= h($u['phone']) ?></td>
    <td class="<?= $u['integral'] >= 0 ? 'plus' : 'minus' ?>"><?= $u['integral'] ?></td>
    <td><?= fmtTime($u['created_at']) ?></td>
    <td>
        <a href="index.php?action=user&do=edit&id=<?= $u['id'] ?>">编辑</a> |
        <a href="index.php?action=user&do=delete&id=<?= $u['id'] ?>" class="text-danger"
           onclick="return confirm('确定删除该用户？该用户的积分流水也会被删除！')">删除</a> |
        <a href="javascript:;" onclick="showAdjust(<?= $u['id'] ?>, '<?= h(addslashes($u['nickname'])) ?>')">调整积分</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?= paginate($total, $page, $pageSize ?? 15, 'index.php?action=user&keyword='.urlencode($keyword)) ?>

<div id="adjustModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.6);z-index:999;justify-content:center;align-items:center;">
    <div style="background:#161b22;padding:28px;border-radius:12px;border:1px solid #30363d;width:400px;">
        <h3 style="margin-bottom:20px;">调整积分 - <span id="adjustName"></span></h3>
        <form method="post" action="index.php?action=user&do=integral">
            <input type="hidden" name="uid" id="adjustUid">
            <label style="display:block;margin-bottom:14px;color:#8b949e;font-size:14px;">
                变动值（正数增加，负数扣减）
                <input type="number" name="amount" required style="width:100%;margin-top:6px;padding:10px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
            </label>
            <label style="display:block;margin-bottom:20px;color:#8b949e;font-size:14px;">
                原因
                <input type="text" name="reason" placeholder="如：活动奖励 / 手动扣减" style="width:100%;margin-top:6px;padding:10px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
            </label>
            <div style="display:flex;gap:10px;justify-content:flex-end;">
                <button type="button" class="btn-sm" style="background:#30363d;color:#c9d1d9;" onclick="document.getElementById('adjustModal').style.display='none'">取消</button>
                <button type="submit" class="btn-sm">确认调整</button>
            </div>
        </form>
    </div>
</div>

<script>
function showAdjust(uid, name) {
    document.getElementById('adjustUid').value = uid;
    document.getElementById('adjustName').textContent = name;
    document.getElementById('adjustModal').style.display = 'flex';
}
</script>

<?php include __DIR__.'/footer.php'; ?>
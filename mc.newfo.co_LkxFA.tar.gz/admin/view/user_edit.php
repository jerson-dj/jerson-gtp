<?php include __DIR__.'/header.php'; ?>

<h1><?= $user ? '编辑用户' : '新增用户' ?></h1>

<form method="post" class="form-box"
      action="index.php?action=user&do=save<?= $id ? '&id='.$id : '' ?>">

    <label>昵称 <span style="color:#f85149;">*</span>
        <input type="text" name="nickname" value="<?= h($user['nickname'] ?? '') ?>" required>
    </label>

    <label>手机号
        <input type="text" name="phone" value="<?= h($user['phone'] ?? '') ?>">
    </label>

    <label>头像 URL
        <input type="text" name="avatar" value="<?= h($user['avatar'] ?? '') ?>" placeholder="https://...">
    </label>

    <?php if (!$user): ?>
    <label>初始积分
        <input type="number" name="integral" value="0">
    </label>
    <?php else: ?>
    <label>当前积分
        <input type="text" value="<?= $user['integral'] ?>" disabled style="opacity:0.6;">
    </label>
    <p style="color:#8b949e;font-size:13px;margin-bottom:16px;">
        提示：积分变动请回到列表页使用“调整积分”按钮，这样会生成流水记录。
    </p>
    <?php endif; ?>

    <div style="display:flex;gap:12px;">
        <button type="submit" class="btn">保存</button>
        <a href="index.php?action=user" class="btn" style="background:#30363d;color:#c9d1d9;">返回</a>
    </div>
</form>

<?php include __DIR__.'/footer.php'; ?>
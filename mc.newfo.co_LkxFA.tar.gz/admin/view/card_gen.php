<?php include __DIR__.'/header.php'; ?>

<h1>生成充值卡</h1>

<form method="post" action="index.php?action=card&do=do_gen" class="form-box">
    <label>类型
        <select name="type" id="cardType" onchange="toggleType()">
            <option value="integral">⚡ 积分卡</option>
            <option value="vip">👑 VIP卡</option>
        </select>
    </label>

    <label id="amountLabel">积分数量（每张）
        <input type="number" name="amount" value="100" min="1">
    </label>

    <label id="vipLabel" style="display:none;">VIP 套餐
        <select name="vip_plan_id">
            <?php foreach ($plans as $p): ?>
            <option value="<?= $p['id'] ?>"><?= h($p['name']) ?>（<?= $p['days'] ?> 天）</option>
            <?php endforeach; ?>
        </select>
    </label>

    <label>生成数量
        <input type="number" name="count" value="10" min="1" max="500">
    </label>

    <div style="display:flex;gap:12px;">
        <button type="submit" class="btn">批量生成</button>
        <a href="index.php?action=card" class="btn" style="background:#30363d;color:#c9d1d9;">返回列表</a>
    </div>
</form>

<script>
function toggleType() {
    var t = document.getElementById('cardType').value;
    document.getElementById('amountLabel').style.display = t === 'integral' ? 'block' : 'none';
    document.getElementById('vipLabel').style.display = t === 'vip' ? 'block' : 'none';
}
</script>

<?php include __DIR__.'/footer.php'; ?>
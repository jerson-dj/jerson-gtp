<?php include __DIR__.'/header.php';?><h1>音频管理 <a href="index.php?action=audio&do=edit" class="btn">+ 添加</a></h1>
<table><thead><tr><th>ID</th><th>标题</th><th>来源</th><th>时长</th><th>播放</th><th>状态</th><th>操作</th></tr></thead><tbody>
<?php foreach($list as $r):?><tr>
<td><?=$r['id']?></td><td><?=h($r['title'])?><br><small><?=h($r['artist'])?></small></td>
<td><span class="badge <?=$r['source_type']=='local'?'badge-green':'badge-blue'?>"><?=$r['source_type']=='local'?'本地':'外链'?></span></td>
<td><?=$r['duration']?gmdate('i:s',$r['duration']):'-'?></td><td><?=$r['play_count']?></td>
<td><?=$r['status']?'上架':'下架'?></td>
<td><a href="index.php?action=audio&do=edit&id=<?=$r['id']?>">编辑</a> | <a href="index.php?action=audio&do=delete&id=<?=$r['id']?>" onclick="return confirm('删除？')">删除</a></td>
</tr><?php endforeach;?></tbody></table>
<?=paginate($total,$page,$ps,'index.php?action=audio')?>
<?php include __DIR__.'/footer.php';?>
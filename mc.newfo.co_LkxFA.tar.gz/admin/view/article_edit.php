<?php include __DIR__.'/header.php'; ?>

<link rel="stylesheet" href="/admin/ueditor/themes/default/css/ueditor.min.css">
<style>
.edit-wrap{display:grid;grid-template-columns:1fr 320px;gap:24px;}
.edit-main{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:24px;}
.edit-side{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:24px;height:fit-content;position:sticky;top:20px;}
.edit-main .title-input{width:100%;padding:14px 16px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#c9d1d9;font-size:20px;font-weight:600;margin-bottom:20px;}
.edit-main label,.edit-side label{display:block;color:#8b949e;font-size:13px;margin-bottom:6px;}
.edit-side .form-group{margin-bottom:18px;}
.edit-side select,.edit-side input[type=text]{width:100%;padding:8px 12px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;font-size:14px;}
.edit-main input[type=text],.edit-main textarea{width:100%;padding:10px 12px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;font-size:14px;}
.submit-bar{display:flex;gap:10px;margin-bottom:20px;}
.submit-bar .btn{flex:1;padding:12px;font-size:15px;text-align:center;}
.toolbar-extra{display:flex;flex-direction:column;gap:10px;margin:16px 0;padding:14px;background:#0d1117;border-radius:8px;border:1px solid #21262d;}
.toolbar-extra .row{display:flex;gap:10px;align-items:center;}
.toolbar-extra .row-label{color:#8b949e;font-size:13px;white-space:nowrap;min-width:80px;}
.toolbar-extra input[type=text]{flex:1;background:#161b22;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;padding:8px 12px;font-size:13px;outline:none;}
.toolbar-extra input[type=text]:focus{border-color:#00d4ff;}
#editor-container{background:#fff;border-radius:6px;line-height:1.6;}
.msg{font-size:12px;color:#8a99ad;margin-top:2px;}
.audio-preview{margin-top:6px;}
.audio-preview audio{width:100%;max-width:420px;}
.tip{font-size:12px;color:#8a99ad;line-height:1.6;margin-top:4px;}
</style>

<h1><?= $article ? '编辑文章' : '写文章' ?></h1>

<form method="post" id="articleForm" action="index.php?action=article&do=save<?= $id ? '&id='.$id : '' ?>">
<input type="hidden" name="content" id="contentInput" value="<?= h($article['content'] ?? '') ?>">

<div class="edit-wrap">

    <div class="edit-main">
        <input type="text" name="title" class="title-input" placeholder="输入文章标题..." value="<?= h($article['title'] ?? '') ?>" required>

        <div class="toolbar-extra">
            <!-- 封面 -->
            <div class="row">
                <span class="row-label">📷 封面图：</span>
                <input type="text" name="cover" id="coverInput" value="<?= h($article['cover'] ?? '') ?>" placeholder="封面图 URL，或点右侧上传">
                <input type="file" id="coverFile" accept="image/*" style="display:none;">
                <button type="button" onclick="document.getElementById('coverFile').click()" class="btn-sm" style="padding:8px 16px;white-space:nowrap;">上传图片</button>
            </div>
            <div class="msg" id="coverMsg"></div>
            <div id="coverPreviewWrap" style="display:<?= !empty($article['cover']) ? 'block' : 'none' ?>;">
                <img id="coverPreview" src="<?= h($article['cover'] ?? '') ?>" style="max-width:240px;border-radius:8px;border:1px solid #30363d;">
            </div>

            <!-- 音频 -->
            <div class="row" style="margin-top:8px;">
                <span class="row-label">🎵 音频：</span>
                <input type="text" name="audio_url" id="audioInput" value="<?= h($article['audio_url'] ?? '') ?>" placeholder="粘贴音频直链，或点右侧上传">
                <input type="file" id="audioFile" accept="audio/*" style="display:none;">
                <button type="button" onclick="document.getElementById('audioFile').click()" class="btn-sm" style="padding:8px 16px;white-space:nowrap;">上传音频</button>
            </div>
            <div class="msg" id="audioMsg"></div>
            <div class="audio-preview" id="audioPreviewWrap" style="display:<?= !empty($article['audio_url']) ? 'block' : 'none' ?>;">
                <audio id="audioPreview" controls src="<?= h($article['audio_url'] ?? '') ?>"></audio>
            </div>
            <div class="tip">💡 外链必须是直接的音频文件地址，以 .mp3 / .m4a / .wav 结尾。<br>例如：https://xxx.com/song.mp3（页面地址如 music.163.com 不能直接播放）</div>
        </div>

        <label style="color:#8b949e;font-size:13px;margin-bottom:8px;display:block;">正文</label>
        <script id="editor" type="text/plain" style="width:100%;height:480px;"></script>

        <div style="margin-top:20px;">
            <label style="color:#8b949e;font-size:13px;margin-bottom:6px;display:block;">摘要</label>
            <textarea name="intro" rows="3" placeholder="文章摘要..."><?= h($article['intro'] ?? '') ?></textarea>
        </div>

        <div style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <div><label>别名</label><input type="text" name="alias" value="<?= h($article['alias'] ?? '') ?>"></div>
            <div><label>标签</label><input type="text" name="tags" value="<?= h($article['tags'] ?? '') ?>"></div>
        </div>
    </div>

    <div class="edit-side">
        <div class="submit-bar"><button type="submit" class="btn">发布</button></div>
        <div class="form-group"><label>分类</label>
            <select name="cate_id">
                <option value="0">-- 未分类 --</option>
                <?php foreach ($cates as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($article['cate_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>状态</label>
            <select name="status">
                <option value="1" <?= ($article['status'] ?? 1) == 1 ? 'selected' : '' ?>>公开发布</option>
                <option value="2" <?= ($article['status'] ?? 1) == 2 ? 'selected' : '' ?>>草稿</option>
                <option value="0" <?= ($article['status'] ?? 1) == 0 ? 'selected' : '' ?>>待审核</option>
            </select>
        </div>
        <div class="form-group"><label>类型</label>
            <select name="type">
                <option value="article" <?= ($article['type'] ?? '') == 'article' ? 'selected' : '' ?>>文章</option>
                <option value="audio" <?= ($article['type'] ?? '') == 'audio' ? 'selected' : '' ?>>音频</option>
                <option value="video" <?= ($article['type'] ?? '') == 'video' ? 'selected' : '' ?>>视频</option>
            </select>
        </div>
        <div class="form-group"><label>作者</label><input type="text" name="author" value="<?= h($article['author'] ?? 'admin') ?>"></div>
        <div class="form-group"><label>浏览量</label><input type="text" name="views" value="<?= h($article['views'] ?? 0) ?>"></div>
        <div class="form-group"><label>置顶</label>
            <select name="is_top">
                <option value="0" <?= ($article['is_top'] ?? 0) == 0 ? 'selected' : '' ?>>不置顶</option>
                <option value="1" <?= ($article['is_top'] ?? 0) == 1 ? 'selected' : '' ?>>置顶</option>
            </select>
        </div>
        <div class="form-group"><label>允许评论</label>
            <select name="allow_comment">
                <option value="1" <?= ($article['allow_comment'] ?? 1) == 1 ? 'selected' : '' ?>>允许</option>
                <option value="0" <?= ($article['allow_comment'] ?? 1) == 0 ? 'selected' : '' ?>>禁止</option>
            </select>
        </div>
        <div class="form-group">
            <a href="index.php?action=article" class="btn" style="background:#30363d;color:#c9d1d9;display:block;text-align:center;padding:10px;">返回列表</a>
        </div>
    </div>

</div>
</form>

<script src="/admin/ueditor/ueditor.config.js"></script>
<script src="/admin/ueditor/ueditor.all.min.js"></script>
<script src="/admin/ueditor/lang/zh-cn/zh-cn.js"></script>
<script>
var ue = UE.getEditor('editor', {
    UEDITOR_HOME_URL: '/admin/ueditor/',
    serverUrl: '/admin/ueditor/php/controller.php',
    initialFrameHeight: 480,
    initialFrameWidth: '100%',
    autoHeightEnabled: false,
    toolbars: [[
        'source','undo','redo','|',
        'bold','italic','underline','strikethrough','subscript','superscript','forecolor','backcolor','|',
        'insertorderedlist','insertunorderedlist','|',
        'justifyleft','justifycenter','justifyright','justifyjustify','|',
        'indent','outdent','|',
        'removeformat','formatmatch','autotypeset','blockquote','pasteplain','|',
        'rowspacingtop','rowspacingbottom','lineheight','|',
        'link','unlink','anchor','|',
        'imagenone','imageleft','imageright','imagecenter','|',
        'insertimage','emotion','scrawl','insertvideo','attachment','map','|',
        'inserttable','insertcode','template','pagebreak','horizontal','|',
        'searchreplace','print','preview','fullscreen'
    ]],
    elementPathEnabled: true,
    wordCount: true
});

ue.ready(function() {
    ue.setContent(document.getElementById('contentInput').value || '<p><br></p>');
});

document.getElementById('articleForm').addEventListener('submit', function() {
    document.getElementById('contentInput').value = ue.getContent();
});

// ===== 封面：上传 + 链接预览 =====
document.getElementById('coverFile').addEventListener('change', function() {
    var file = this.files[0];
    if (!file) return;
    var msg = document.getElementById('coverMsg');
    msg.textContent = '上传中...';
    msg.style.color = '#8a99ad';
    var fd = new FormData();
    fd.append('file', file);
    fetch('/admin/upload.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(function(res) {
            if (res.success) {
                document.getElementById('coverInput').value = res.url;
                document.getElementById('coverPreview').src = res.url;
                document.getElementById('coverPreviewWrap').style.display = 'block';
                msg.textContent = '✅ 上传成功';
                msg.style.color = '#3fb950';
            } else {
                msg.textContent = '❌ ' + (res.error || '上传失败');
                msg.style.color = '#f85149';
            }
        });
});

document.getElementById('coverInput').addEventListener('input', function() {
    updateCoverPreview(this.value.trim());
});
document.getElementById('coverInput').addEventListener('paste', function() {
    var self = this;
    setTimeout(function(){ updateCoverPreview(self.value.trim()); }, 50);
});

function updateCoverPreview(url) {
    var wrap = document.getElementById('coverPreviewWrap');
    var img = document.getElementById('coverPreview');
    if (url) { img.src = url; wrap.style.display = 'block'; }
    else { wrap.style.display = 'none'; }
}

// ===== 音频：上传 + 链接预览 =====
document.getElementById('audioFile').addEventListener('change', function() {
    var file = this.files[0];
    if (!file) return;
    var msg = document.getElementById('audioMsg');
    msg.textContent = '上传中...';
    msg.style.color = '#8a99ad';

    var fd = new FormData();
    fd.append('upfile', file);

    fetch('/admin/ueditor/php/controller.php?action=uploadaudio', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            if (res.state === 'SUCCESS') {
                document.getElementById('audioInput').value = res.url;
                updateAudioPreview(res.url);
                msg.textContent = '✅ 上传成功';
                msg.style.color = '#3fb950';
            } else {
                msg.textContent = '❌ ' + (res.state || '上传失败');
                msg.style.color = '#f85149';
            }
        })
        .catch(function() {
            msg.textContent = '❌ 上传失败，请检查网络';
            msg.style.color = '#f85149';
        });

    this.value = '';
});

document.getElementById('audioInput').addEventListener('input', function() {
    updateAudioPreview(this.value.trim());
});
document.getElementById('audioInput').addEventListener('paste', function() {
    var self = this;
    setTimeout(function(){ updateAudioPreview(self.value.trim()); }, 50);
});

function updateAudioPreview(url) {
    var wrap = document.getElementById('audioPreviewWrap');
    var audio = document.getElementById('audioPreview');
    if (url) {
        audio.src = url;
        wrap.style.display = 'block';
    } else {
        wrap.style.display = 'none';
    }
}
</script>

<?php include __DIR__.'/footer.php'; ?>
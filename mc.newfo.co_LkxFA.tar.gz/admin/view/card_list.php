<?php include __DIR__.'/header.php'; ?>

<h1>充值卡管理 <a href="index.php?action=card&do=gen" class="btn">+ 生成卡密</a></h1>

<?php if (!empty($_SESSION['card_batch_msg'])): ?>
<div class="msg ok" style="padding:12px;background:rgba(63,185,80,.1);color:#3fb950;border-radius:8px;margin-bottom:16px;">
    <?= $_SESSION['card_batch_msg'] ?>
</div>
<?php unset($_SESSION['card_batch_msg']); endif; ?>

<form method="get" class="search-bar">
    <input type="hidden" name="action" value="card">
    <input type="text" name="keyword" placeholder="搜索卡号或批次号..." value="<?= h($keyword ?? '') ?>">
    <select name="status" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
        <option value="">全部</option>
        <option value="0" <?= ($status??'')==='0'?'selected':'' ?>>未使用</option>
        <option value="1" <?= ($status??'')==='1'?'selected':'' ?>>已使用</option>
    </select>
    <button type="submit" class="btn-sm">筛选</button>
</form>

<table>
<thead>
    <tr><th>ID</th><th>卡号</th><th>卡密</th><th>类型</th><th>金额/天数</th><th>批次</th><th>状态</th><th>使用人</th><th>生成时间</th></tr>
</thead>
<tbody>
<?php if (empty($list)): ?>
<tr><td colspan="9" style="text-align:center;color:#8b949e;padding:30px;">暂无卡密</td></tr>
<?php endif; ?>
<?php foreach ($list as $c): ?>
<tr>
    <td><?= $c['id'] ?></td>
    <td><code><?= h($c['card_no']) ?></code></td>
    <td><code><?= h($c['card_pwd']) ?></code></td>
    <td><?= $c['type']==='integral'?'⚡ 积分':'👑 VIP' ?></td>
    <td><?= $c['type']==='integral'?$c['amount'].' 积分':$c['amount'].' 天' ?></td>
    <td><?= h($c['batch_no']) ?></td>
    <td><?= $c['status']?'<span style="color:#f85149;">已使用</span>':'<span style="color:#3fb950;">未使用</span>' ?></td>
    <td><?= $c['used_by'] ? '用户#'.$c['used_by'] : '-' ?></td>
    <td><?= fmtTime($c['created_at']) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?= paginate($total, $page, $ps, 'index.php?action=card&keyword='.urlencode($keyword??'').'&status='.($status??'')) ?>

<?php include __DIR__.'/footer.php'; ?>
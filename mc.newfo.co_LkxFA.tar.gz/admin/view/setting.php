<?php include __DIR__.'/header.php'; ?>

<h1>系统设置</h1>

<form method="post" class="form-box" style="max-width:820px;">

    <h3 style="color:#00d4ff;font-size:15px;margin-bottom:16px;">基础设置</h3>

    <label>网站名称
        <input type="text" name="site_name" value="<?= h($settings['site_name'] ?? 'NIGHT RIDE') ?>">
    </label>
    <label>发帖积分
        <input type="number" name="post_integral" value="<?= h($settings['post_integral'] ?? 150) ?>">
    </label>
    <label>兑换门槛
        <input type="number" name="exchange_min" value="<?= h($settings['exchange_min'] ?? 500) ?>">
    </label>
    <label>积分兑换比例（1 元 = 多少积分）
        <input type="number" name="integral_rate" value="<?= h($settings['integral_rate'] ?? 100) ?>">
    </label>

    <h3 style="color:#00d4ff;font-size:15px;margin:28px 0 16px;">互动功能</h3>

    <label>启用文章点赞
        <select name="like_enabled">
            <option value="1" <?= ($settings['like_enabled'] ?? '1')==='1'?'selected':'' ?>>开启</option>
            <option value="0" <?= ($settings['like_enabled'] ?? '1')==='0'?'selected':'' ?>>关闭</option>
        </select>
    </label>

    <label>启用文章评论
        <select name="comment_enabled">
            <option value="1" <?= ($settings['comment_enabled'] ?? '1')==='1'?'selected':'' ?>>开启</option>
            <option value="0" <?= ($settings['comment_enabled'] ?? '1')==='0'?'selected':'' ?>>关闭</option>
        </select>
    </label>

    <label>评论需要审核
        <select name="comment_need_audit">
            <option value="1" <?= ($settings['comment_need_audit'] ?? '1')==='1'?'selected':'' ?>>需要审核（管理员通过后显示）</option>
            <option value="0" <?= ($settings['comment_need_audit'] ?? '1')==='0'?'selected':'' ?>>不需要审核（发布即显示）</option>
        </select>
    </label>

    <h3 style="color:#00d4ff;font-size:15px;margin:28px 0 16px;">支付方式</h3>

    <label>支付模式
        <select name="pay_mode">
            <option value="manual" <?= ($settings['pay_mode'] ?? 'manual')==='manual'?'selected':'' ?>>收款码 + 人工审核</option>
            <option value="auto" <?= ($settings['pay_mode'] ?? 'manual')==='auto'?'selected':'' ?>>官方接口（自动到账）</option>
        </select>
    </label>

    <h3 style="color:#00d4ff;font-size:15px;margin:28px 0 16px;">支付宝配置</h3>

    <label>AppID
        <input type="text" name="alipay_app_id" value="<?= h($settings['alipay_app_id'] ?? '') ?>" placeholder="例如 2021000000000000">
    </label>
    <label>应用私钥（RSA2）
        <textarea name="alipay_private_key" rows="4" style="font-family:monospace;font-size:12px;" placeholder="-----BEGIN RSA PRIVATE KEY-----"><?= h($settings['alipay_private_key'] ?? '') ?></textarea>
    </label>
    <label>支付宝公钥
        <textarea name="alipay_public_key" rows="4" style="font-family:monospace;font-size:12px;" placeholder="-----BEGIN PUBLIC KEY-----"><?= h($settings['alipay_public_key'] ?? '') ?></textarea>
    </label>
    <label>异步通知地址（notify_url）
        <input type="text" name="alipay_notify_url" value="<?= h($settings['alipay_notify_url'] ?? 'https://mc.newfo.co/api/pay_alipay_notify.php') ?>">
    </label>

    <h3 style="color:#00d4ff;font-size:15px;margin:28px 0 16px;">微信支付配置</h3>

    <label>商户号 mchid
        <input type="text" name="wechat_mchid" value="<?= h($settings['wechat_mchid'] ?? '') ?>" placeholder="例如 1900000000">
    </label>
    <label>AppID
        <input type="text" name="wechat_appid" value="<?= h($settings['wechat_appid'] ?? '') ?>" placeholder="公众号或小程序 AppID">
    </label>
    <label>APIv3 密钥
        <input type="text" name="wechat_apiv3_key" value="<?= h($settings['wechat_apiv3_key'] ?? '') ?>" placeholder="32 位字符串">
    </label>
    <label>商户证书序列号
        <input type="text" name="wechat_serial_no" value="<?= h($settings['wechat_serial_no'] ?? '') ?>" placeholder="上传商户证书后显示">
    </label>
    <label>商户私钥文件路径
        <input type="text" name="wechat_private_key_path" value="<?= h($settings['wechat_private_key_path'] ?? '/www/wwwroot/mc.newfo.co/cert/apiclient_key.pem') ?>">
    </label>
    <label>平台证书序列号
        <input type="text" name="wechat_platform_serial" value="<?= h($settings['wechat_platform_serial'] ?? '') ?>" placeholder="微信支付平台证书序列号">
    </label>
    <label>平台证书路径
        <input type="text" name="wechat_platform_cert_path" value="<?= h($settings['wechat_platform_cert_path'] ?? '/www/wwwroot/mc.newfo.co/cert/wechat_platform_cert.pem') ?>">
    </label>
    <label>异步通知地址
        <input type="text" name="wechat_notify_url" value="<?= h($settings['wechat_notify_url'] ?? 'https://mc.newfo.co/api/pay_wechat_notify.php') ?>">
    </label>

    <h3 style="color:#00d4ff;font-size:15px;margin:28px 0 16px;">收款码（人工审核模式备用）</h3>

    <label>支付宝收款码图片 URL
        <div style="display:flex;gap:10px;">
            <input type="text" name="alipay_qrcode" id="alipayInput" value="<?= h($settings['alipay_qrcode'] ?? '') ?>" style="flex:1;">
            <input type="file" id="alipayFile" accept="image/*" style="display:none;">
            <button type="button" class="btn-sm" onclick="document.getElementById('alipayFile').click()" style="padding:8px 16px;">上传</button>
        </div>
    </label>
    <?php if (!empty($settings['alipay_qrcode'])): ?>
    <img id="alipayPreview" src="<?= h($settings['alipay_qrcode']) ?>" style="max-width:180px;border-radius:8px;border:1px solid #30363d;margin-bottom:16px;display:block;">
    <?php else: ?>
    <img id="alipayPreview" style="display:none;max-width:180px;border-radius:8px;border:1px solid #30363d;margin-bottom:16px;">
    <?php endif; ?>

    <label>微信收款码图片 URL
        <div style="display:flex;gap:10px;">
            <input type="text" name="wechat_qrcode" id="wechatInput" value="<?= h($settings['wechat_qrcode'] ?? '') ?>" style="flex:1;">
            <input type="file" id="wechatFile" accept="image/*" style="display:none;">
            <button type="button" class="btn-sm" onclick="document.getElementById('wechatFile').click()" style="padding:8px 16px;">上传</button>
        </div>
    </label>
    <?php if (!empty($settings['wechat_qrcode'])): ?>
    <img id="wechatPreview" src="<?= h($settings['wechat_qrcode']) ?>" style="max-width:180px;border-radius:8px;border:1px solid #30363d;margin-bottom:16px;display:block;">
    <?php else: ?>
    <img id="wechatPreview" style="display:none;max-width:180px;border-radius:8px;border:1px solid #30363d;margin-bottom:16px;">
    <?php endif; ?>

    <h3 style="color:#00d4ff;font-size:15px;margin:28px 0 16px;">充值说明</h3>

    <label>充值说明文案
        <textarea name="pay_remark" rows="3"><?= h($settings['pay_remark'] ?? '') ?></textarea>
    </label>

    <div style="margin-top:24px;">
        <button type="submit" class="btn">保存设置</button>
    </div>
</form>

<script>
function bindUpload(fileId, inputId, previewId) {
    var fileEl = document.getElementById(fileId);
    if (!fileEl) return;
    fileEl.addEventListener('change', function() {
        var file = this.files[0];
        if (!file) return;
        var fd = new FormData();
        fd.append('file', file);
        fetch('/admin/upload.php', { method: 'POST', body: fd })
            .then(r => r.json())
            .then(function(res) {
                if (res.success) {
                    document.getElementById(inputId).value = res.url;
                    var p = document.getElementById(previewId);
                    p.src = res.url;
                    p.style.display = 'block';
                } else {
                    alert('上传失败：' + (res.error || '未知错误'));
                }
            });
    });
}
bindUpload('alipayFile', 'alipayInput', 'alipayPreview');
bindUpload('wechatFile', 'wechatInput', 'wechatPreview');
</script>

<?php include __DIR__.'/footer.php'; ?>
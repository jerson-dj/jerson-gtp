<?php include __DIR__.'/header.php';?><h1>帖子审核</h1>
<div class="tabs">
<a href="index.php?action=post&status=0" class="<?=($status??0)==0?'active':''?>">待审核</a>
<a href="index.php?action=post&status=1" class="<?=($status??0)==1?'active':''?>">已通过</a>
<a href="index.php?action=post&status=3" class="<?=($status??0)==3?'active':''?>">已拒绝</a>
<a href="index.php?action=post&status=" class="<?=($status??'')===''?'active':''?>">全部</a></div>
<table><thead><tr><th>ID</th><th>标题</th><th>分类</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody>
<?php foreach($list as $r):?><tr>
<td><?=$r['id']?></td><td><?=h($r['title'])?></td><td><?=h($r['cate_name']??'-')?></td>
<td><?php if($r['status']==0):?><span class="badge badge-yellow">待审</span><?php elseif($r['status']==1):?><span class="badge badge-green">通过</span><?php elseif($r['status']==3):?><span class="badge badge-red">拒绝</span><?php endif;?></td>
<td><?=fmtTime($r['created_at'])?></td>
<td><?php if($r['status']==0):?><a href="index.php?action=post&do=approve&id=<?=$r['id']?>" class="btn-sm">通过</a> <a href="index.php?action=post&do=reject&id=<?=$r['id']?>" class="btn-sm btn-danger" onclick="return confirm('拒绝？')">拒绝</a><?php endif;?></td>
</tr><?php endforeach;?></tbody></table>
<?=paginate($total,$page,$ps,'index.php?action=post&status='.$status)?>
<?php include __DIR__.'/footer.php';?>
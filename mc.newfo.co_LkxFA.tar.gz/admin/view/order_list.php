<?php include __DIR__.'/header.php'; ?>

<h1>充值订单</h1>

<form method="get" class="search-bar">
    <input type="hidden" name="action" value="order">
    <input type="text" name="keyword" placeholder="订单号 / 付款账号..." value="<?= h($keyword ?? '') ?>">
    <select name="status" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
        <option value="">全部</option>
        <option value="0" <?= ($status??'')==='0'?'selected':'' ?>>待审核</option>
        <option value="1" <?= ($status??'')==='1'?'selected':'' ?>>已通过</option>
        <option value="2" <?= ($status??'')==='2'?'selected':'' ?>>已拒绝</option>
    </select>
    <button type="submit" class="btn-sm">筛选</button>
</form>

<table>
<thead>
    <tr><th>ID</th><th>订单号</th><th>用户</th><th>类型</th><th>金额</th><th>支付</th><th>账号</th><th>截图</th><th>状态</th><th>时间</th><th>操作</th></tr>
</thead>
<tbody>
<?php if (empty($list)): ?>
<tr><td colspan="11" style="text-align:center;color:#8b949e;padding:30px;">暂无订单</td></tr>
<?php endif; ?>
<?php foreach ($list as $o): ?>
<tr>
    <td><?= $o['id'] ?></td>
    <td><code style="font-size:11px;"><?= h($o['order_no']) ?></code></td>
    <td><?= h($o['nickname'] ?? '用户#'.$o['user_id']) ?></td>
    <td><?= $o['type']==='integral'?'⚡ 积分':'👑 VIP' ?></td>
    <td>¥<?= number_format($o['amount_money'], 2) ?></td>
    <td><?= $o['pay_method']==='alipay'?'支付宝':'微信' ?></td>
    <td><?= h($o['pay_account']) ?></td>
    <td>
        <?php if ($o['pay_proof']): ?>
        <a href="<?= h($o['pay_proof']) ?>" target="_blank">查看</a>
        <?php else: ?>-<?php endif; ?>
    </td>
    <td>
        <?php if ($o['status']==0): ?><span style="color:#f0b90b;">⏳ 待审核</span>
        <?php elseif ($o['status']==1): ?><span style="color:#3fb950;">✅ 已通过</span>
        <?php else: ?><span style="color:#f85149;">❌ 已拒绝</span><?php endif; ?>
    </td>
    <td><?= fmtTime($o['created_at']) ?></td>
    <td>
        <?php if ($o['status']==0): ?>
        <a href="index.php?action=order&do=approve&id=<?= $o['id'] ?>" onclick="return confirm('确认通过？将自动发放积分/VIP')">通过</a> |
        <a href="index.php?action=order&do=reject&id=<?= $o['id'] ?>" class="text-danger" onclick="return confirm('确认拒绝？')">拒绝</a>
        <?php else: ?>-<?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?= paginate($total, $page, $ps, 'index.php?action=order&keyword='.urlencode($keyword??'').'&status='.($status??'')) ?>

<?php include __DIR__.'/footer.php'; ?>
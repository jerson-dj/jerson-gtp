<?php include __DIR__.'/header.php';?><h1>仪表盘</h1>
<div class="stats">
<div class="stat-card"><span>文章</span><strong><?=$stats['article']?></strong></div>
<div class="stat-card"><span>用户</span><strong><?=$stats['user']?></strong></div>
<div class="stat-card"><span>音频</span><strong><?=$stats['audio']?></strong></div>
<div class="stat-card"><span>积分总额</span><strong><?=$stats['integral']?></strong></div>
</div>
<?php include __DIR__.'/footer.php';?>
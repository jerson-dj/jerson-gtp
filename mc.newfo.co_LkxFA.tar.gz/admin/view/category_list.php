<?php include __DIR__.'/header.php'; ?>

<h1>分类/导航管理 <a href="index.php?action=category&do=edit" class="btn">+ 新增导航</a></h1>

<table>
<thead>
    <tr><th>ID</th><th>名称</th><th>别名</th><th>链接</th><th>排序</th><th>文章数</th><th>操作</th></tr>
</thead>
<tbody>
<?php if (empty($cates)): ?>
    <tr><td colspan="7" style="text-align:center;color:#8b949e;padding:30px;">暂无导航，点右上角“+ 新增导航”</td></tr>
<?php endif; ?>
<?php foreach ($cates as $c): ?>
<tr>
    <td><?= $c['id'] ?></td>
    <td><?= h($c['name']) ?></td>
    <td><code><?= h($c['slug']) ?></code></td>
    <td>
        <?php if (!empty($c['link'])): ?>
            <span class="badge badge-blue">自定义</span>
            <small style="color:#8b949e;"><?= h(mb_substr($c['link'], 0, 40)) ?><?= mb_strlen($c['link']) > 40 ? '...' : '' ?></small>
        <?php else: ?>
            <span class="badge badge-green">分类页</span>
        <?php endif; ?>
    </td>
    <td><?= $c['sort'] ?></td>
    <td><?= $c['article_count'] ?? 0 ?></td>
    <td>
        <a href="index.php?action=category&do=edit&id=<?= $c['id'] ?>">编辑</a> |
        <a href="index.php?action=category&do=delete&id=<?= $c['id'] ?>" class="text-danger"
           onclick="return confirm('确定删除该导航？该分类下的文章将变为未分类！')">删除</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?php include __DIR__.'/footer.php'; ?>
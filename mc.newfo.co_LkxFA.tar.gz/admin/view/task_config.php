<?php include __DIR__.'/header.php';?><h1>积分任务配置</h1>
<div class="two-col"><div><table><thead><tr><th>ID</th><th>标识</th><th>名称</th><th>积分</th><th>上限</th><th>状态</th><th>操作</th></tr></thead><tbody>
<?php foreach($tasks as $t):?><tr>
<td><?=$t['id']?></td><td><code><?=h($t['task_key'])?></code></td><td><?=h($t['task_name'])?></td>
<td class="<?=$t['integral']>0?'plus':'minus'?>"><?=$t['integral']>0?'+':''?><?=$t['integral']?></td>
<td><?=$t['max_times']?:'不限'?></td><td><?=$t['status']?'启用':'禁用'?></td>
<td><a href="index.php?action=task&do=edit&id=<?=$t['id']?>">编辑</a> | <a href="index.php?action=task&do=delete&id=<?=$t['id']?>" onclick="return confirm('删除？')">删除</a></td>
</tr><?php endforeach;?></tbody></table></div>
<div class="form-box"><h3><?=$task?'编辑':'新增'?>任务</h3>
<form method="post" action="index.php?action=task&do=save<?=$task?'&id='.$task['id']:''?>">
<label>标识<input type="text" name="task_key" value="<?=h($task['task_key']??'')?>" required></label>
<label>名称<input type="text" name="task_name" value="<?=h($task['task_name']??'')?>" required></label>
<label>描述<input type="text" name="task_desc" value="<?=h($task['task_desc']??'')?>"></label>
<label>积分<input type="number" name="integral" value="<?=h($task['integral']??0)?>" required></label>
<label>每日上限<input type="number" name="max_times" value="<?=h($task['max_times']??1)?>"></label>
<label>排序<input type="number" name="sort" value="<?=h($task['sort']??0)?>"></label>
<label>状态<select name="status"><option value="1" <?=($task['status']??1)==1?'selected':''?>>启用</option><option value="0" <?=($task['status']??1)==0?'selected':''?>>禁用</option></select></label>
<button type="submit" class="btn">保存</button></form></div></div>
<?php include __DIR__.'/footer.php';?>
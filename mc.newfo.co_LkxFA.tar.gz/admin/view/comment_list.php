<?php include __DIR__.'/header.php'; ?>

<h1>评论管理</h1>

<form method="get" class="search-bar">
    <input type="hidden" name="action" value="comment">
    <input type="text" name="keyword" placeholder="搜索内容..." value="<?= h($keyword ?? '') ?>">
    <select name="status" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
        <option value="">全部</option>
        <option value="0" <?= ($status??'')==='0'?'selected':'' ?>>待审核</option>
        <option value="1" <?= ($status??'')==='1'?'selected':'' ?>>已通过</option>
        <option value="2" <?= ($status??'')==='2'?'selected':'' ?>>已拒绝</option>
    </select>
    <button type="submit" class="btn-sm">筛选</button>
</form>

<table>
<thead>
    <tr><th>ID</th><th>用户</th><th>文章</th><th>内容</th><th>状态</th><th>时间</th><th>操作</th></tr>
</thead>
<tbody>
<?php if (empty($list)): ?>
<tr><td colspan="7" style="text-align:center;color:#8b949e;padding:30px;">暂无评论</td></tr>
<?php endif; ?>
<?php foreach ($list as $c): ?>
<tr>
    <td><?= $c['id'] ?></td>
    <td><?= h($c['nickname'] ?? '用户#'.$c['user_id']) ?></td>
    <td><a href="/post_view.php?id=<?= $c['article_id'] ?>" target="_blank"><?= h(mb_substr($c['article_title'] ?? '文章#'.$c['article_id'], 0, 20)) ?></a></td>
    <td style="max-width:300px;word-break:break-all;"><?= h(mb_substr($c['content'], 0, 80)) ?></td>
    <td>
        <?php if ($c['status']==0): ?><span style="color:#f0b90b;">⏳ 待审核</span>
        <?php elseif ($c['status']==1): ?><span style="color:#3fb950;">✅ 已通过</span>
        <?php else: ?><span style="color:#f85149;">❌ 已拒绝</span><?php endif; ?>
    </td>
    <td><?= fmtTime($c['created_at']) ?></td>
    <td>
        <?php if ($c['status']==0): ?>
        <a href="index.php?action=comment&do=approve&id=<?= $c['id'] ?>">通过</a> |
        <a href="index.php?action=comment&do=reject&id=<?= $c['id'] ?>" class="text-danger">拒绝</a> |
        <?php endif; ?>
        <a href="index.php?action=comment&do=delete&id=<?= $c['id'] ?>" class="text-danger" onclick="return confirm('确定删除？')">删除</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?= paginate($total, $page, $ps, 'index.php?action=comment&keyword='.urlencode($keyword??'').'&status='.($status??'')) ?>

<?php include __DIR__.'/footer.php'; ?>
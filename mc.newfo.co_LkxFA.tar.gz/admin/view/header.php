<?php
// 确保函数库已加载（无论从哪个入口进入）
if (!function_exists('h')) {
    require_once __DIR__.'/../../include/config.php';
    require_once __DIR__.'/../../include/db.php';
    require_once __DIR__.'/../../include/function.php';
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>后台</title>
<link rel="stylesheet" href="/assets/style.css">
</head><body>
<div class="admin-wrap"><aside class="sidebar"><h2>NIGHT RIDE</h2><nav>
<a href="/admin/index.php?action=dashboard">仪表盘</a>
<a href="/admin/index.php?action=article">文章管理</a>
<a href="/admin/index.php?action=category">分类/导航</a>
<a href="/admin/index.php?action=audio">音频管理</a>
<a href="/admin/index.php?action=post">帖子审核</a>
<a href="/admin/index.php?action=task">积分任务</a>
<a href="/admin/index.php?action=user">用户管理</a>
<a href="/admin/index.php?action=integral">积分流水</a>
<a href="index.php?action=card">充值卡</a>
<a href="index.php?action=order">充值订单</a>
<a href="/admin/totp_setup.php">安全设置</a>
<a href="index.php?action=comment">评论管理</a>
<a href="/admin/index.php?action=setting">系统设置</a>
<a href="/admin/logout.php" class="logout">退出</a>
</nav></aside><main class="main">
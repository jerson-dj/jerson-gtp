<?php include __DIR__.'/header.php';?><h1><?=$audio?'编辑':'添加'?>音频</h1>
<form method="post" class="form-box" enctype="multipart/form-data" action="index.php?action=audio&do=save<?=$id?'&id='.$id:''?>">
<label>标题<input type="text" name="title" value="<?=h($audio['title']??'')?>" required></label>
<label>艺术家<input type="text" name="artist" value="<?=h($audio['artist']??'')?>"></label>
<label>封面URL<input type="text" name="cover" value="<?=h($audio['cover']??'')?>"></label>
<label>分类<select name="cate_id"><?php foreach($cates as $c):?><option value="<?=$c['id']?>" <?=($audio['cate_id']??0)==$c['id']?'selected':''?>><?=h($c['name'])?></option><?php endforeach;?></select></label>
<label>来源<select name="source_type" id="st" onchange="toggle()"><option value="local" <?=($audio['source_type']??'local')=='local'?'selected':''?>>本地上传</option><option value="external" <?=($audio['source_type']??'')=='external'?'selected':''?>>外部链接</option></select></label>
<div id="local" style="display:<?=($audio['source_type']??'local')=='local'?'block':'none'?>"><label>文件<input type="file" name="audio_file" accept="audio/*"></label><?php if(!empty($audio['file_url'])&&$audio['source_type']=='local'):?><audio controls src="<?=h($audio['file_url'])?>" style="width:100%"></audio><?php endif;?></div>
<div id="ext" style="display:<?=($audio['source_type']??'')=='external'?'block':'none'?>"><label>链接<input type="text" name="external_url" value="<?=h($audio['source_type']=='external'?$audio['file_url']:'')?>" placeholder="https://..."></label><?php if(!empty($audio['file_url'])&&$audio['source_type']=='external'):?><audio controls src="<?=h($audio['file_url'])?>" style="width:100%"></audio><?php endif;?></div>
<label>排序<input type="number" name="sort" value="<?=h($audio['sort']??0)?>"></label>
<label>状态<select name="status"><option value="1" <?=($audio['status']??1)==1?'selected':''?>>上架</option><option value="0" <?=($audio['status']??1)==0?'selected':''?>>下架</option></select></label>
<button type="submit" class="btn">保存</button></form>
<script>function toggle(){var v=document.getElementById('st').value;document.getElementById('local').style.display=v=='local'?'block':'none';document.getElementById('ext').style.display=v=='external'?'block':'none';}</script>
<?php include __DIR__.'/footer.php';?>
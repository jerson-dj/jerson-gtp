<?php include __DIR__.'/header.php';?><h1>积分流水</h1>
<table><thead><tr><th>ID</th><th>用户</th><th>变动</th><th>原因</th><th>时间</th></tr></thead><tbody>
<?php foreach($logs as $l):?><tr>
<td><?=$l['id']?></td><td><?=h($l['nickname']??'未知')?></td>
<td class="<?=$l['amount']>0?'plus':'minus'?>"><?=$l['amount']>0?'+':''?><?=$l['amount']?></td>
<td><?=h($l['reason'])?></td><td><?=fmtTime($l['created_at'])?></td>
</tr><?php endforeach;?></tbody></table>
<?php include __DIR__.'/footer.php';?>
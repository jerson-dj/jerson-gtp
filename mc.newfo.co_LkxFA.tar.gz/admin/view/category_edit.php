<?php include __DIR__.'/header.php'; ?>

<h1><?= $editCate ? '编辑导航' : '新增导航' ?></h1>

<form method="post" class="form-box"
      action="index.php?action=category&do=save<?= $editCate ? '&id='.$editCate['id'] : '' ?>">

    <label>导航名称 <span style="color:#f85149;">*</span>
        <input type="text" name="name" value="<?= h($editCate['name'] ?? '') ?>" required placeholder="如：听车电台">
    </label>

    <label>别名 slug（URL 用，留空自动生成）
        <input type="text" name="slug" value="<?= h($editCate['slug'] ?? '') ?>" placeholder="例如 radio">
    </label>

    <label>自定义链接（留空则使用分类页链接）
        <input type="text" name="link" value="<?= h($editCate['link'] ?? '') ?>"
               placeholder="例如：https://example.com 或 /pages/about.php">
    </label>
    <p style="color:#8b949e;font-size:12px;margin-bottom:16px;">
        支持完整 URL（https://...）、站内绝对路径（/pages/xxx.php）或留空使用分类页。
    </p>

    <label>排序（数字越小越靠前）
        <input type="number" name="sort" value="<?= h($editCate['sort'] ?? 0) ?>">
    </label>

    <div style="display:flex;gap:12px;">
        <button type="submit" class="btn">保存</button>
        <a href="index.php?action=category" class="btn" style="background:#30363d;color:#c9d1d9;">返回列表</a>
    </div>
</form>

<?php include __DIR__.'/footer.php'; ?>
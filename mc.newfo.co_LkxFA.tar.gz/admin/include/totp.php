<?php
/**
 * 纯 PHP TOTP 实现（RFC 6238）
 * 用于 Google Authenticator / Microsoft Authenticator 等 App
 */
class TOTP {
    private static $base32Map = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    /** 生成随机 Base32 密钥（默认 20 字节 = 160 bit） */
    public static function generateSecret($length = 20) {
        return self::base32Encode(random_bytes($length));
    }

    /** Base32 编码 */
    public static function base32Encode($data) {
        $map = self::$base32Map;
        $binary = '';
        for ($i = 0; $i < strlen($data); $i++) {
            $binary .= str_pad(decbin(ord($data[$i])), 8, '0', STR_PAD_LEFT);
        }
        $result = '';
        foreach (str_split($binary, 5) as $chunk) {
            $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
            $result .= $map[bindec($chunk)];
        }
        return $result;
    }

    /** Base32 解码 */
    public static function base32Decode($secret) {
        $map = self::$base32Map;
        $secret = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $secret));
        $binary = '';
        for ($i = 0; $i < strlen($secret); $i++) {
            $pos = strpos($map, $secret[$i]);
            if ($pos === false) continue;
            $binary .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }
        $result = '';
        foreach (str_split($binary, 8) as $chunk) {
            if (strlen($chunk) < 8) break;
            $result .= chr(bindec($chunk));
        }
        return $result;
    }

    /** 生成指定时间片的动态码 */
    public static function getCode($secret, $timeSlice = null) {
        if ($timeSlice === null) $timeSlice = floor(time() / 30);
        $secretKey = self::base32Decode($secret);
        $time = pack('N*', 0) . pack('N*', $timeSlice);
        $hash = hash_hmac('sha1', $time, $secretKey, true);
        $offset = ord(substr($hash, -1)) & 0x0F;
        $value = (
            ((ord($hash[$offset])     & 0x7F) << 24) |
            ((ord($hash[$offset + 1]) & 0xFF) << 16) |
            ((ord($hash[$offset + 2]) & 0xFF) << 8)  |
             (ord($hash[$offset + 3]) & 0xFF)
        );
        return str_pad($value % 1000000, 6, '0', STR_PAD_LEFT);
    }

    /** 验证动态码（允许前后各 1 个时间窗口，共 ±30 秒误差） */
    public static function verify($secret, $code, $discrepancy = 1) {
        $code = str_pad(trim($code), 6, '0', STR_PAD_LEFT);
        $now = floor(time() / 30);
        for ($i = -$discrepancy; $i <= $discrepancy; $i++) {
            if (hash_equals(self::getCode($secret, $now + $i), $code)) {
                return true;
            }
        }
        return false;
    }

    /** 生成 otpauth:// URL（供二维码使用） */
    public static function getOtpauthUrl($label, $secret, $issuer = 'NIGHT RIDE') {
        return 'otpauth://totp/' . rawurlencode($issuer . ':' . $label)
             . '?secret=' . $secret
             . '&issuer=' . rawurlencode($issuer)
             . '&algorithm=SHA1&digits=6&period=30';
    }
}
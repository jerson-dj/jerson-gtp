<?php
require_once __DIR__.'/../include/auth.php';
require_once __DIR__.'/../include/totp.php';

$adminId = $_SESSION['admin_id'];
$admin = DB::one("SELECT * FROM admin WHERE id=?", [$adminId]);

$msg = '';
$error = '';

// 处理解绑
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'disable') {
    $code = trim($_POST['code'] ?? '');
    if (TOTP::verify($admin['totp_secret'], $code)) {
        DB::exec("UPDATE admin SET totp_secret=NULL, totp_enabled=0 WHERE id=?", [$adminId]);
        $admin['totp_enabled'] = 0;
        $admin['totp_secret'] = null;
        $msg = '已解绑 TOTP，下次登录只需密码和验证码';
    } else {
        $error = '动态码错误，解绑失败';
    }
}

// 处理绑定确认
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'enable') {
    $code = trim($_POST['code'] ?? '');
    $secret = $_POST['secret'] ?? '';
    if (TOTP::verify($secret, $code)) {
        DB::exec("UPDATE admin SET totp_secret=?, totp_enabled=1 WHERE id=?", [$secret, $adminId]);
        $admin['totp_enabled'] = 1;
        $admin['totp_secret'] = $secret;
        $msg = '✅ TOTP 绑定成功，下次登录需要输入动态码';
    } else {
        $error = '动态码错误，请检查 App 时间是否同步';
    }
}

// 生成新密钥（未绑定时）
$newSecret = null;
if (empty($admin['totp_enabled'])) {
    if (empty($_SESSION['new_totp_secret'])) {
        $_SESSION['new_totp_secret'] = TOTP::generateSecret();
    }
    $newSecret = $_SESSION['new_totp_secret'];
    $otpauthUrl = TOTP::getOtpauthUrl($admin['username'], $newSecret);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>双因素认证 - NIGHT RIDE 后台</title>
<link rel="stylesheet" href="../assets/style.css">
<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
<style>
.totp-wrap{max-width:640px;margin:0 auto;background:#161b22;border:1px solid #30363d;border-radius:12px;padding:32px;}
.totp-wrap h1{font-size:20px;margin-bottom:24px;color:#00d4ff;}
.totp-status{display:flex;align-items:center;gap:12px;padding:16px;border-radius:8px;margin-bottom:24px;}
.totp-status.on{background:rgba(63,185,80,.1);border:1px solid rgba(63,185,80,.3);}
.totp-status.off{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.3);}
.totp-status .icon{font-size:28px;}
.totp-status .text{font-size:14px;line-height:1.5;}
.qr-area{display:flex;gap:24px;align-items:flex-start;margin-bottom:24px;padding:20px;background:#0d1117;border-radius:10px;border:1px solid #30363d;}
.qr-box{background:#fff;padding:12px;border-radius:8px;flex-shrink:0;}
.qr-box canvas,.qr-box img{display:block;}
.secret-info{flex:1;font-size:13px;color:#8b949e;line-height:1.8;}
.secret-info .secret{display:inline-block;background:#161b22;border:1px solid #30363d;border-radius:4px;padding:6px 12px;font-family:monospace;color:#00d4ff;font-size:13px;letter-spacing:1px;word-break:break-all;margin-top:4px;}
.totp-form label{display:block;color:#8b949e;font-size:13px;margin-bottom:6px;}
.totp-form input[type=text]{width:200px;padding:12px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#00d4ff;font-size:20px;text-align:center;letter-spacing:6px;font-family:monospace;outline:none;}
.totp-form input[type=text]:focus{border-color:#00d4ff;}
.totp-form button{padding:12px 24px;background:#00d4ff;color:#0d1117;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px;margin-left:8px;}
.totp-form button.danger{background:#f85149;color:#fff;}
.msg{padding:12px 16px;border-radius:8px;margin-bottom:20px;font-size:14px;}
.msg.ok{background:rgba(63,185,80,.1);color:#3fb950;border:1px solid rgba(63,185,80,.3);}
.msg.err{background:rgba(248,81,73,.1);color:#f85149;border:1px solid rgba(248,81,73,.3);}
.steps{font-size:13px;color:#8b949e;line-height:1.8;margin-bottom:16px;}
.steps b{color:#c9d1d9;}
</style>
</head>
<body>
<?php include __DIR__.'/view/header.php'; ?>

<div class="totp-wrap">
    <h1>🔐 双因素认证（TOTP）</h1>

    <?php if ($msg): ?><div class="msg ok"><?= h($msg) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="msg err"><?= h($error) ?></div><?php endif; ?>

    <?php if (!empty($admin['totp_enabled'])): ?>
        <!-- 已绑定 -->
        <div class="totp-status on">
            <div class="icon">✅</div>
            <div class="text">
                <strong>已启用双因素认证</strong><br>
                登录时需要输入 Google Authenticator 的 6 位动态码。
            </div>
        </div>

        <form method="post" class="totp-form">
            <input type="hidden" name="action" value="disable">
            <label>解绑需验证当前动态码：</label>
            <input type="text" name="code" maxlength="6" pattern="\d{6}" placeholder="000000" required autocomplete="off">
            <button type="submit" class="danger" onclick="return confirm('确定要解绑吗？解绑后登录只靠密码。')">解绑</button>
        </form>

    <?php else: ?>
        <!-- 未绑定 -->
        <div class="totp-status off">
            <div class="icon">⚠️</div>
            <div class="text">
                <strong>尚未启用双因素认证</strong><br>
                建议立即绑定，保护后台安全。
            </div>
        </div>

        <div class="steps">
            <b>步骤：</b><br>
            1. 手机安装 <b>Google Authenticator</b> / <b>Microsoft Authenticator</b> / <b>Authy</b> 等<br>
            2. 用 App 扫描下方二维码（或手动输入密钥）<br>
            3. 在下方输入 App 显示的 6 位动态码，确认绑定
        </div>

        <div class="qr-area">
            <div class="qr-box" id="qrcode"></div>
            <div class="secret-info">
                <div>📱 扫码绑定</div>
                <div style="margin-top:12px;">手动输入密钥：</div>
                <div class="secret"><?= h($newSecret) ?></div>
                <div style="margin-top:12px;font-size:12px;color:#8b949e;">
                    类型：基于时间 (TOTP)<br>
                    位数：6 位　周期：30 秒　算法：SHA1
                </div>
            </div>
        </div>

        <form method="post" class="totp-form">
            <input type="hidden" name="action" value="enable">
            <input type="hidden" name="secret" value="<?= h($newSecret) ?>">
            <label>输入 App 上的 6 位动态码：</label>
            <input type="text" name="code" maxlength="6" pattern="\d{6}" placeholder="000000" required autocomplete="off">
            <button type="submit">确认绑定</button>
        </form>

        <script>
        new QRCode(document.getElementById('qrcode'), {
            text: <?= json_encode($otpauthUrl) ?>,
            width: 180,
            height: 180,
            correctLevel: QRCode.CorrectLevel.M
        });
        </script>
    <?php endif; ?>
</div>

<?php include __DIR__.'/view/footer.php'; ?>
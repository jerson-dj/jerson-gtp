<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
require_once __DIR__.'/../include/totp.php';
session_start();

if (empty($_SESSION['pending_admin_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code'] ?? '');
    $admin = DB::one("SELECT * FROM admin WHERE id=?", [$_SESSION['pending_admin_id']]);

    if ($admin && TOTP::verify($admin['totp_secret'], $code)) {
        // 动态码正确，正式登录
        $_SESSION['admin_id']   = $admin['id'];
        $_SESSION['admin_name'] = $admin['username'];
        unset($_SESSION['pending_admin_id'], $_SESSION['pending_admin_name']);
        DB::exec("UPDATE admin SET lastlogin=? WHERE id=?", [time(), $admin['id']]);
        header('Location: index.php');
        exit;
    } else {
        $error = '动态码错误，请重新输入';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>双因素验证 - NIGHT RIDE</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0d1117;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
.box{background:#161b22;padding:40px;border-radius:12px;width:400px;border:1px solid #30363d;box-shadow:0 20px 60px rgba(0,0,0,.5);text-align:center;}
.box h2{color:#00d4ff;font-size:20px;margin-bottom:12px;}
.box .subtitle{color:#8b949e;font-size:13px;margin-bottom:28px;line-height:1.6;}
.box input{width:100%;padding:14px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#00d4ff;font-size:24px;text-align:center;letter-spacing:8px;font-weight:700;outline:none;margin-bottom:20px;font-family:monospace;}
.box input:focus{border-color:#00d4ff;}
.box button{width:100%;padding:14px;background:#00d4ff;border:none;border-radius:8px;font-weight:bold;color:#0d1117;cursor:pointer;font-size:15px;}
.box button:hover{background:#00b8e0;}
.error{color:#f85149;font-size:13px;padding:10px;background:rgba(248,81,73,.1);border-radius:6px;margin-bottom:16px;}
.icon{font-size:48px;color:#00d4ff;margin-bottom:16px;}
.cancel{display:inline-block;margin-top:16px;color:#8b949e;font-size:13px;text-decoration:none;}
.cancel:hover{color:#00d4ff;}
</style>
</head>
<body>
<div class="box">
    <div class="icon">🔐</div>
    <h2>双因素验证</h2>
    <p class="subtitle">打开 Google Authenticator<br>输入当前 6 位动态码</p>
    <?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
    <form method="post">
        <input type="text" name="code" maxlength="6" pattern="\d{6}" placeholder="000000" required autofocus autocomplete="off">
        <button type="submit">验 证</button>
    </form>
    <a href="login.php" class="cancel">← 返回登录</a>
</div>
</body>
</html>
<?php include __DIR__.'/header.php'; ?>

<h1>文章管理 <a href="index.php?action=article&do=edit" class="btn">+ 写文章</a></h1>

<form method="get" class="search-bar">
    <input type="hidden" name="action" value="article">
    <input type="text" name="keyword" placeholder="搜索标题..." value="<?= h($keyword ?? '') ?>">
    <select name="status" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
        <option value="">全部状态</option>
        <option value="1" <?= ($statusFilter ?? '')==='1'?'selected':'' ?>>已发布</option>
        <option value="0" <?= ($statusFilter ?? '')==='0'?'selected':'' ?>>待审核</option>
        <option value="2" <?= ($statusFilter ?? '')==='2'?'selected':'' ?>>草稿</option>
        <option value="3" <?= ($statusFilter ?? '')==='3'?'selected':'' ?>>已拒绝</option>
    </select>
    <select name="cate_id" style="padding:8px 14px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;">
        <option value="0">全部分类</option>
        <?php foreach (($cates ?? []) as $c): ?>
        <option value="<?= $c['id'] ?>" <?= ($cateFilter ?? 0)==$c['id']?'selected':'' ?>><?= h($c['name']) ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-sm">筛选</button>
    <a href="index.php?action=article" class="btn-sm" style="background:#30363d;color:#c9d1d9;">清空</a>
</form>

<table>
<thead>
    <tr>
        <th>ID</th><th>封面</th><th>标题</th><th>分类</th><th>类型</th><th>状态</th><th>作者</th><th>浏览量</th><th>发布时间</th><th>操作</th>
    </tr>
</thead>
<tbody>
<?php if (empty($list)): ?>
    <tr><td colspan="10" style="text-align:center;color:#8b949e;padding:30px;">暂无文章，点右上角“+ 写文章”创建</td></tr>
<?php endif; ?>
<?php foreach (($list ?? []) as $a): ?>
<tr>
    <td><?= $a['id'] ?></td>
    <td>
        <?php if (!empty($a['cover'])): ?>
        <img src="<?= h($a['cover']) ?>" style="width:50px;height:35px;object-fit:cover;border-radius:4px;">
        <?php else: ?>
        <span style="color:#8b949e;font-size:12px;">无</span>
        <?php endif; ?>
    </td>
    <td><?= h($a['title']) ?><?= !empty($a['is_top']) ? ' <span class="badge badge-red">置顶</span>' : '' ?></td>
    <td><?= h($a['cate_name'] ?? '-') ?></td>
    <td>
        <?php if ($a['type']=='article'): ?><span class="badge badge-blue">文章</span>
        <?php elseif ($a['type']=='audio'): ?><span class="badge badge-green">音频</span>
        <?php elseif ($a['type']=='video'): ?><span class="badge badge-yellow">视频</span>
        <?php endif; ?>
    </td>
    <td>
        <?php if ($a['status']==0): ?><span class="badge badge-yellow">待审核</span>
        <?php elseif ($a['status']==1): ?><span class="badge badge-green">已发布</span>
        <?php elseif ($a['status']==2): ?><span class="badge">草稿</span>
        <?php elseif ($a['status']==3): ?><span class="badge badge-red">已拒绝</span>
        <?php endif; ?>
    </td>
    <td><?= h($a['author'] ?: 'admin') ?></td>
    <td><?= $a['views'] ?></td>
    <td><?= fmtTime($a['created_at']) ?></td>
    <td>
        <a href="index.php?action=article&do=edit&id=<?= $a['id'] ?>">编辑</a> |
        <a href="index.php?action=article&do=delete&id=<?= $a['id'] ?>" class="text-danger"
           onclick="return confirm('确定删除？')">删除</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?php if (!empty($total)): ?>
<?= paginate($total, $page ?? 1, $ps ?? 15, 'index.php?action=article&keyword='.urlencode($keyword ?? '').'&status='.($statusFilter ?? '').'&cate_id='.($cateFilter ?? 0)) ?>
<?php endif; ?>

<?php include __DIR__.'/footer.php'; ?>
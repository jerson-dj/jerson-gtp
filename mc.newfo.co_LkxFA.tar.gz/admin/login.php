<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
require_once __DIR__.'/../include/totp.php';
session_start();

if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['captcha_a']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    $captcha = trim($_POST['captcha'] ?? '');

    $expected = $_SESSION['captcha_a'] + $_SESSION['captcha_b'];

    if ($captcha === '' || (int)$captcha !== $expected) {
        $error = '验证码答案错误';
        $_SESSION['captcha_a'] = random_int(1, 9);
        $_SESSION['captcha_b'] = random_int(1, 9);
    } else {
        $admin = DB::one("SELECT * FROM admin WHERE username=?", [$u]);
        if ($admin && password_verify($p, $admin['password'])) {
            unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);

            // 判断是否启用 TOTP
            if (!empty($admin['totp_enabled']) && !empty($admin['totp_secret'])) {
                // 挂起，等动态码验证
                $_SESSION['pending_admin_id']   = $admin['id'];
                $_SESSION['pending_admin_name'] = $admin['username'];
                header('Location: totp_verify.php');
                exit;
            }

            // 未启用 TOTP，直接登录
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['username'];
            DB::exec("UPDATE admin SET lastlogin=? WHERE id=?", [time(), $admin['id']]);
            header('Location: index.php');
            exit;
        } else {
            $error = '用户名或密码错误';
            $_SESSION['captcha_a'] = random_int(1, 9);
            $_SESSION['captcha_b'] = random_int(1, 9);
        }
    }
}

if (empty($_SESSION['captcha_a'])) {
    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}
$captchaA = $_SESSION['captcha_a'];
$captchaB = $_SESSION['captcha_b'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>后台登录 - NIGHT RIDE</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0d1117;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
.login-box{background:#161b22;padding:40px;border-radius:12px;width:380px;border:1px solid #30363d;box-shadow:0 20px 60px rgba(0,0,0,.5);}
.login-box h2{text-align:center;margin-bottom:28px;color:#00d4ff;font-size:20px;letter-spacing:1px;}
.login-box label{display:block;color:#8b949e;font-size:13px;margin-bottom:6px;}
.login-box input{width:100%;padding:12px 14px;margin-bottom:16px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;font-size:14px;outline:none;transition:border-color .2s;}
.login-box input:focus{border-color:#00d4ff;}
.login-box button{width:100%;padding:12px;background:#00d4ff;border:none;border-radius:6px;font-weight:bold;color:#0d1117;cursor:pointer;font-size:15px;margin-top:4px;}
.login-box button:hover{background:#00b8e0;}
.error{color:#f85149;margin-bottom:16px;text-align:center;font-size:13px;padding:10px;background:rgba(248,81,73,.1);border-radius:6px;}
.captcha-row{display:flex;gap:12px;align-items:center;margin-bottom:20px;}
.captcha-row input{flex:1;margin-bottom:0;}
.captcha-question{background:linear-gradient(135deg,#e8f0fe,#d4e4fc);color:#1a3a6b;border:1px solid #b8cdf0;border-radius:6px;padding:12px 20px;font-size:16px;font-weight:800;white-space:nowrap;letter-spacing:2px;user-select:none;font-family:Georgia,serif;}
</style>
</head>
<body>
<div class="login-box">
    <h2>NIGHT RIDE 后台</h2>
    <?php if (!empty($error)): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
    <form method="post">
        <label>用户名</label>
        <input type="text" name="username" placeholder="请输入登录账号" required value="<?= h($_POST['username'] ?? '') ?>">

        <label>密码</label>
        <input type="password" name="password" placeholder="请输入密码" required>

        <label>验证码</label>
        <div class="captcha-row">
            <div class="captcha-question"><?= $captchaA ?> + <?= $captchaB ?> =</div>
            <input type="number" name="captcha" placeholder="请输入答案" required value="<?= h($_POST['captcha'] ?? '') ?>">
        </div>

        <button type="submit">下一步</button>
    </form>
</div>
</body>
</html>
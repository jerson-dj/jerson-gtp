<?php
require_once __DIR__.'/../include/auth.php';
$action=$_GET['action']??'dashboard';
$do=$_GET['do']??'list';
$id=(int)($_GET['id']??0);

switch($action){
    case 'dashboard':
        $stats=[
            'article'=>DB::one("SELECT COUNT(*) c FROM article")['c'],
            'user'=>DB::one("SELECT COUNT(*) c FROM user")['c'],
            'audio'=>DB::one("SELECT COUNT(*) c FROM audio")['c'],
            'integral'=>DB::one("SELECT SUM(integral) s FROM user")['s']?:0,
        ];
        include __DIR__.'/view/dashboard.php'; break;

    // ===== 分类/导航管理 =====
    case 'category':
        if($do=='delete'&&$id){
            DB::exec("UPDATE article SET cate_id=0 WHERE cate_id=?",[$id]);
            DB::exec("DELETE FROM category WHERE id=?",[$id]);
            alert('删除成功','index.php?action=category');
        }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $name=trim($_POST['name']??'');
            if(empty($name)) alert('名称不能为空');
            $slug=trim($_POST['slug']??'');
            if($slug===''){ $slug=$name; }
            $slug=preg_replace('/[^\p{L}\p{N}\-]+/u','-',$slug);
            $slug=trim($slug,'-');
            $link=trim($_POST['link']??'');
            $sort=(int)($_POST['sort']??0);

            if($id){
                DB::exec("UPDATE category SET name=?,slug=?,link=?,sort=? WHERE id=?",[$name,$slug,$link,$sort,$id]);
                alert('保存成功','index.php?action=category');
            } else {
                DB::insert("INSERT INTO category (name,slug,link,sort) VALUES (?,?,?,?)",[$name,$slug,$link,$sort]);
                alert('添加成功','index.php?action=category');
            }
        }
        if($do=='edit'){
            $editCate=$id?DB::one("SELECT * FROM category WHERE id=?",[$id]):null;
            include __DIR__.'/view/category_edit.php'; break;
        }
        $cates=DB::query("SELECT c.*, (SELECT COUNT(*) FROM article a WHERE a.cate_id=c.id) article_count FROM category c ORDER BY c.sort ASC, c.id ASC");
        include __DIR__.'/view/category_list.php'; break;

    // ===== 文章管理 =====
    case 'article':
        if($do=='delete'&&$id){
            DB::exec("DELETE FROM article WHERE id=?",[$id]);
            alert('删除成功','index.php?action=article');
        }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $title=trim($_POST['title']??'');
            if(empty($title)) alert('标题不能为空');
            $alias=trim($_POST['alias']??'');
            if($alias===''){ $alias=$title; }
            $alias=preg_replace('/[^\p{L}\p{N}\-]+/u','-',$alias);
            $alias=trim($alias,'-');
            $data=[
                (int)($_POST['cate_id']??0), $title, $alias,
                $_POST['content']??'', $_POST['intro']??'',
                trim($_POST['tags']??''), trim($_POST['author']??''),
                trim($_POST['cover']??''), trim($_POST['audio_url']??''),
                $_POST['type']??'article',
                (int)($_POST['status']??1), (int)($_POST['is_top']??0),
                (int)($_POST['allow_comment']??1), (int)($_POST['views']??0),
            ];
            if($id){
                $data[]=time(); $data[]=$id;
                DB::exec("UPDATE article SET cate_id=?,title=?,alias=?,content=?,intro=?,tags=?,author=?,cover=?,audio_url=?,type=?,status=?,is_top=?,allow_comment=?,views=?,updated_at=? WHERE id=?",$data);
                alert('保存成功','index.php?action=article');
            } else {
                $data[]=time(); $data[]=time();
                DB::insert("INSERT INTO article (cate_id,title,alias,content,intro,tags,author,cover,audio_url,type,status,is_top,allow_comment,views,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",$data);
                alert('发布成功','index.php?action=article');
            }
        }
        if($do=='edit'){
            $article=$id?DB::one("SELECT * FROM article WHERE id=?",[$id]):null;
            $cates=DB::query("SELECT * FROM category ORDER BY sort");
            include __DIR__.'/view/article_edit.php'; break;
        }
        $keyword=trim($_GET['keyword']??'');
        $statusFilter=$_GET['status']??'';
        $cateFilter=(int)($_GET['cate_id']??0);
        $page=max(1,(int)($_GET['page']??1)); $ps=15;
        $where="WHERE 1=1"; $params=[];
        if($keyword!==''){ $where.=" AND a.title LIKE ?"; $params[]="%{$keyword}%"; }
        if($statusFilter!==''){ $where.=" AND a.status=?"; $params[]=(int)$statusFilter; }
        if($cateFilter){ $where.=" AND a.cate_id=?"; $params[]=$cateFilter; }
        $total=DB::one("SELECT COUNT(*) c FROM article a $where",$params)['c'];
        $list=DB::query("SELECT a.*,c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id $where ORDER BY a.is_top DESC, a.id DESC LIMIT ".($page-1)*$ps.",$ps",$params);
        $cates=DB::query("SELECT * FROM category ORDER BY sort");
        include __DIR__.'/view/article_list.php'; break;

    // ===== 音频管理 =====
    case 'audio':
        if($do=='delete'&&$id){
            $a=DB::one("SELECT * FROM audio WHERE id=?",[$id]);
            if($a&&$a['source_type']=='local') @unlink(UPLOAD_DIR.basename($a['file_url']));
            DB::exec("DELETE FROM audio WHERE id=?",[$id]);
            alert('删除成功','index.php?action=audio');
        }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $st=$_POST['source_type']??'local'; $url='';
            if($st=='local'&&!empty($_FILES['audio_file']['tmp_name'])){
                $ext=strtolower(pathinfo($_FILES['audio_file']['name'],PATHINFO_EXTENSION));
                $ok=['mp3','wav','flac','aac','ogg','m4a'];
                if(!in_array($ext,$ok)) alert('格式不支持: '.implode(',',$ok));
                $fn=date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
                if(move_uploaded_file($_FILES['audio_file']['tmp_name'],UPLOAD_DIR.$fn)) $url=UPLOAD_URL.$fn;
                else alert('上传失败');
            } elseif($st=='external'){
                $url=trim($_POST['external_url']??'');
                if(!filter_var($url,FILTER_VALIDATE_URL)) alert('外部链接无效');
            }
            $dur=0;
            if($st=='local'&&$url&&function_exists('shell_exec')){
                $lp=UPLOAD_DIR.basename($url);
                $d=@shell_exec("ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 ".escapeshellarg($lp)." 2>/dev/null");
                $dur=(int)floatval($d);
            }
            $data=[$_POST['title'],$_POST['artist']??'',$_POST['cover']??'',$url,$st,$dur,0,strtolower(pathinfo($url,PATHINFO_EXTENSION))?:'mp3',(int)($_POST['cate_id']??0),(int)($_POST['sort']??0),(int)($_POST['status']??1)];
            if($id){ $data[]=$id; DB::exec("UPDATE audio SET title=?,artist=?,cover=?,file_url=?,source_type=?,duration=?,file_size=?,format=?,cate_id=?,sort=?,status=? WHERE id=?",$data); }
            else { $data[]=time(); DB::insert("INSERT INTO audio (title,artist,cover,file_url,source_type,duration,file_size,format,cate_id,sort,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",$data); }
            alert('保存成功','index.php?action=audio');
        }
        if($do=='edit'){ $audio=$id?DB::one("SELECT * FROM audio WHERE id=?",[$id]):null; $cates=DB::query("SELECT * FROM category ORDER BY sort"); include __DIR__.'/view/audio_edit.php'; break; }
        $page=max(1,(int)($_GET['page']??1)); $ps=20;
        $total=DB::one("SELECT COUNT(*) c FROM audio")['c'];
        $list=DB::query("SELECT a.*,c.name cate_name FROM audio a LEFT JOIN category c ON a.cate_id=c.id ORDER BY a.sort,a.id DESC LIMIT ".($page-1)*$ps.",$ps");
        include __DIR__.'/view/audio_list.php'; break;

    // ===== 帖子审核 =====
    case 'post':
        if($do=='approve'&&$id){ DB::exec("UPDATE article SET status=1 WHERE id=?",[$id]); alert('已通过','index.php?action=post'); }
        if($do=='reject'&&$id){ DB::exec("UPDATE article SET status=3 WHERE id=?",[$id]); alert('已拒绝','index.php?action=post'); }
        $status=$_GET['status']??0;
        $page=max(1,(int)($_GET['page']??1)); $ps=15;
        $w=$status!==''?"WHERE a.status=".(int)$status:"";
        $total=DB::one("SELECT COUNT(*) c FROM article a $w")['c'];
        $list=DB::query("SELECT a.*,c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id $w ORDER BY a.id DESC LIMIT ".($page-1)*$ps.",$ps");
        include __DIR__.'/view/post_list.php'; break;

    // ===== 积分任务 =====
    case 'task':
        if($do=='delete'&&$id){ DB::exec("DELETE FROM task_config WHERE id=?",[$id]); alert('删除成功','index.php?action=task'); }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $data=[$_POST['task_key'],$_POST['task_name'],$_POST['task_desc']??'',(int)$_POST['integral'],(int)$_POST['max_times'],(int)($_POST['status']??1),(int)($_POST['sort']??0)];
            if($id){ $data[]=$id; DB::exec("UPDATE task_config SET task_key=?,task_name=?,task_desc=?,integral=?,max_times=?,status=?,sort=? WHERE id=?",$data); }
            else { $data[]=time(); DB::insert("INSERT INTO task_config (task_key,task_name,task_desc,integral,max_times,status,sort,created_at) VALUES (?,?,?,?,?,?,?,?)",$data); }
            alert('保存成功','index.php?action=task');
        }
        if($do=='edit'){ $task=$id?DB::one("SELECT * FROM task_config WHERE id=?",[$id]):null; include __DIR__.'/view/task_config.php'; break; }
        $tasks=DB::query("SELECT * FROM task_config ORDER BY sort"); include __DIR__.'/view/task_config.php'; break;

    // ===== 用户管理 =====
    case 'user':
        if($do=='delete'&&$id){
            DB::exec("DELETE FROM integral_log WHERE user_id=?",[$id]);
            DB::exec("DELETE FROM user_task_log WHERE user_id=?",[$id]);
            DB::exec("DELETE FROM user WHERE id=?",[$id]);
            alert('删除成功','index.php?action=user');
        }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $nickname=trim($_POST['nickname']??'');
            $phone=trim($_POST['phone']??'');
            $avatar=trim($_POST['avatar']??'');
            $integral=(int)($_POST['integral']??0);
            if(empty($nickname)) alert('昵称不能为空');
            if($id){
                DB::exec("UPDATE user SET nickname=?,phone=?,avatar=? WHERE id=?",[$nickname,$phone,$avatar,$id]);
                alert('保存成功','index.php?action=user');
            } else {
                DB::insert("INSERT INTO user (nickname,phone,avatar,integral,created_at) VALUES (?,?,?,?,?)",[$nickname,$phone,$avatar,$integral,time()]);
                alert('添加成功','index.php?action=user');
            }
        }
        if($do=='edit'){
            $user=$id?DB::one("SELECT * FROM user WHERE id=?",[$id]):null;
            include __DIR__.'/view/user_edit.php'; break;
        }
        if($do=='integral'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $uid=(int)$_POST['uid']; $amount=(int)$_POST['amount']; $reason=trim($_POST['reason']);
            if($uid&&$amount!=0){
                DB::conn()->beginTransaction();
                try{
                    DB::exec("UPDATE user SET integral=integral+? WHERE id=?",[$amount,$uid]);
                    DB::insert("INSERT INTO integral_log (user_id,amount,reason,created_at) VALUES (?,?,?,?)",[$uid,$amount,$reason,time()]);
                    DB::conn()->commit();
                }catch(Exception $e){ DB::conn()->rollBack(); }
            }
            alert('调整成功','index.php?action=user');
        }
        $keyword=trim($_GET['keyword']??'');
        $page=max(1,(int)($_GET['page']??1)); $ps=15;
        $where="WHERE 1=1"; $params=[];
        if($keyword!==''){ $where.=" AND (nickname LIKE ? OR phone LIKE ?)"; $params[]="%{$keyword}%"; $params[]="%{$keyword}%"; }
        $total=DB::one("SELECT COUNT(*) c FROM user $where",$params)['c'];
        $list=DB::query("SELECT * FROM user $where ORDER BY id DESC LIMIT ".($page-1)*$ps.",$ps",$params);
        include __DIR__.'/view/user_list.php'; break;

    // ===== 积分流水 =====
    case 'integral':
        $logs=DB::query("SELECT l.*,u.nickname FROM integral_log l LEFT JOIN user u ON l.user_id=u.id ORDER BY l.id DESC LIMIT 300");
        include __DIR__.'/view/integral_list.php'; break;

    // ===== 系统设置 =====
        // ===== 充值卡管理 =====
    case 'card':
        if($do=='delete'&&$id){
            DB::exec("DELETE FROM recharge_card WHERE id=?",[$id]);
            alert('删除成功','index.php?action=card');
        }
        if($do=='do_gen'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $type = $_POST['type'] ?? 'integral';
            $amount = (int)($_POST['amount'] ?? 0);
            $vipPlanId = (int)($_POST['vip_plan_id'] ?? 0);
            $count = min(500, max(1, (int)($_POST['count'] ?? 10)));
            $batchNo = date('YmdHis') . rand(100, 999);

            $cards = [];
            for($i=0; $i<$count; $i++){
                $cardNo = strtoupper(bin2hex(random_bytes(6)));
                $cardPwd = strtoupper(bin2hex(random_bytes(4)));
                DB::insert("INSERT INTO recharge_card (card_no, card_pwd, type, amount, vip_plan_id, batch_no, status, created_at) VALUES (?,?,?,?,?,?,0,?)",
                    [$cardNo, $cardPwd, $type, $amount, $vipPlanId, $batchNo, time()]);
                $cards[] = "$cardNo | $cardPwd";
            }
            $_SESSION['card_batch_msg'] = "✅ 成功生成 $count 张卡，批次号：$batchNo<br>示例：<code>".$cards[0]."</code>";
            alert('生成成功','index.php?action=card');
        }
        if($do=='gen'){
            $plans = DB::query("SELECT * FROM vip_plan WHERE status=1 ORDER BY sort");
            include __DIR__.'/view/card_gen.php'; break;
        }
        $keyword=trim($_GET['keyword']??'');
        $status=$_GET['status']??'';
        $page=max(1,(int)($_GET['page']??1)); $ps=20;
        $where="WHERE 1=1"; $params=[];
        if($keyword!==''){ $where.=" AND (card_no LIKE ? OR batch_no LIKE ?)"; $params[]="%{$keyword}%"; $params[]="%{$keyword}%"; }
        if($status!==''){ $where.=" AND status=?"; $params[]=(int)$status; }
        $total=DB::one("SELECT COUNT(*) c FROM recharge_card $where",$params)['c'];
        $list=DB::query("SELECT * FROM recharge_card $where ORDER BY id DESC LIMIT ".($page-1)*$ps.",$ps",$params);
        include __DIR__.'/view/card_list.php'; break;
            // ===== 充值订单审核 =====
    case 'order':
        if($do=='approve'&&$id){
            $order = DB::one("SELECT * FROM recharge_order WHERE id=? AND status=0",[$id]);
            if(!$order){ alert('订单不存在或已处理','index.php?action=order'); }
            DB::conn()->beginTransaction();
            try{
                if($order['type']==='integral'){
                    DB::exec("UPDATE user SET integral=integral+?, updated_at=? WHERE id=?",[$order['integral_amount'],time(),$order['user_id']]);
                    DB::insert("INSERT INTO integral_log (user_id,amount,reason,created_at) VALUES (?,?,?,?)",
                        [$order['user_id'],$order['integral_amount'],'在线充值（订单'.$order['order_no'].'）',time()]);
                    DB::insert("INSERT INTO recharge_log (user_id,type,amount,remark,created_at) VALUES (?,'integral',?,?,?)",
                        [$order['user_id'],$order['integral_amount'],'在线充值：'.$order['order_no'],time()]);
                } else {
                    $plan = DB::one("SELECT * FROM vip_plan WHERE id=?",[$order['vip_plan_id']]);
                    if($plan){
                        $user = DB::one("SELECT vip_expire FROM user WHERE id=?",[$order['user_id']]);
                        $expire = max(time(), (int)$user['vip_expire']) + $plan['days']*86400;
                        DB::exec("UPDATE user SET vip_level=?, vip_expire=?, updated_at=? WHERE id=?",
                            [$plan['level'],$expire,time(),$order['user_id']]);
                        DB::insert("INSERT INTO recharge_log (user_id,type,amount,remark,created_at) VALUES (?,'vip',?,?,?)",
                            [$order['user_id'],$plan['days'],'在线开通：'.$plan['name'],time()]);
                    }
                }
                DB::exec("UPDATE recharge_order SET status=1, reviewed_at=? WHERE id=?",[time(),$id]);
                DB::conn()->commit();
                alert('已通过，积分/VIP已发放','index.php?action=order');
            }catch(Exception $e){
                DB::conn()->rollBack();
                alert('操作失败：'.$e->getMessage(),'index.php?action=order');
            }
        }
        if($do=='reject'&&$id){
            DB::exec("UPDATE recharge_order SET status=2, reviewed_at=? WHERE id=?",[time(),$id]);
            alert('已拒绝','index.php?action=order');
        }
        $keyword=trim($_GET['keyword']??'');
        $status=$_GET['status']??'';
        $page=max(1,(int)($_GET['page']??1)); $ps=20;
        $where="WHERE 1=1"; $params=[];
        if($keyword!==''){ $where.=" AND (o.order_no LIKE ? OR o.pay_account LIKE ?)"; $params[]="%{$keyword}%"; $params[]="%{$keyword}%"; }
        if($status!==''){ $where.=" AND o.status=?"; $params[]=(int)$status; }
        $total=DB::one("SELECT COUNT(*) c FROM recharge_order o $where",$params)['c'];
        $list=DB::query("SELECT o.*, u.nickname FROM recharge_order o LEFT JOIN user u ON o.user_id=u.id $where ORDER BY o.id DESC LIMIT ".($page-1)*$ps.",$ps",$params);
        include __DIR__.'/view/order_list.php'; break;
    case 'setting':
        if($_SERVER['REQUEST_METHOD']==='POST'){ foreach($_POST as $k=>$v) DB::exec("REPLACE INTO setting (`key`,`value`) VALUES (?,?)",[$k,$v]); alert('保存成功','index.php?action=setting'); }
        $settings=[]; foreach(DB::query("SELECT * FROM setting") as $r) $settings[$r['key']]=$r['value'];
        include __DIR__.'/view/setting.php'; break;

    default: include __DIR__.'/view/dashboard.php';
}
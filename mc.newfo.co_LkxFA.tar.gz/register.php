<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';
session_start();

// 生成验证码题目（每次进入页面时生成，提交失败后重新生成）
if (empty($_SESSION['captcha_a']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nickname  = trim($_POST['nickname'] ?? '');
    $phone     = trim($_POST['phone'] ?? '');
    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    $captcha   = trim($_POST['captcha'] ?? '');

    // 验证码校验
    $expected = $_SESSION['captcha_a'] + $_SESSION['captcha_b'];

    if ($captcha === '' || (int)$captcha !== $expected) {
        $msg = '验证码答案错误';
        // 重新生成题目
        $_SESSION['captcha_a'] = random_int(1, 9);
        $_SESSION['captcha_b'] = random_int(1, 9);
    } elseif (empty($nickname) || empty($phone) || empty($password)) {
        $msg = '请填写完整信息';
    } elseif (!preg_match('/^1[3-9]\d{9}$/', $phone)) {
        $msg = '手机号格式不正确';
    } elseif (strlen($password) < 6) {
        $msg = '密码至少6位';
    } elseif ($password !== $password2) {
        $msg = '两次密码不一致';
    } else {
        $exists = DB::one("SELECT id FROM user WHERE phone=?", [$phone]);
        if ($exists) {
            $msg = '该手机号已注册';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $uid = DB::insert("INSERT INTO user (nickname,phone,password,integral,created_at) VALUES (?,?,?,?,?)",
                [$nickname, $phone, $hash, 100, time()]);
            $_SESSION['user_id'] = $uid;
            $_SESSION['user_name'] = $nickname;
            $_SESSION['user_integral'] = 100;
            // 注册成功，清掉验证码
            unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
            header('Location: /'); exit;
        }
    }
}

// 如果提交失败，保证题目存在
if (empty($_SESSION['captcha_a'])) {
    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}
$captchaA = $_SESSION['captcha_a'];
$captchaB = $_SESSION['captcha_b'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>注册 - NIGHT RIDE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0a0a0f;color:#e0e0e0;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;
background-image:radial-gradient(circle at center, transparent 30%, rgba(8,10,18,.95) 90%),url('https://images.unsplash.com/photo-1508253730651-e5ace80a7025?auto=format&fit=crop&w=1920&q=80');
background-size:cover;background-position:center;background-blend-mode:multiply;}
.box{background:rgba(18,22,36,.75);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:40px;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(0,0,0,.5);}
h1{font-size:24px;text-align:center;margin-bottom:8px;color:#fff}
.subtitle{text-align:center;color:#8a99ad;font-size:13px;margin-bottom:28px}
label{display:block;color:#8a99ad;font-size:13px;margin-bottom:6px}
input{width:100%;padding:12px 14px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#e0e0e0;font-size:14px;margin-bottom:16px;outline:none;transition:border-color .2s}
input:focus{border-color:#00f3ff}
button{width:100%;padding:12px;background:linear-gradient(90deg,#00f3ff,#0077ff);color:#000;border:none;border-radius:8px;font-weight:700;font-size:15px;cursor:pointer;margin-top:4px}
button:hover{opacity:.9}
.msg{padding:10px 14px;background:rgba(248,81,73,.15);color:#f85149;border-radius:8px;font-size:13px;margin-bottom:16px;text-align:center}
.links{text-align:center;margin-top:20px;font-size:13px;color:#8a99ad}
.links a{color:#00f3ff;text-decoration:none}
.links a:hover{text-decoration:underline}
.back{position:absolute;top:24px;left:24px;color:#8a99ad;font-size:14px;text-decoration:none}
.back:hover{color:#00f3ff}
/* 验证码行 */
.captcha-row{display:flex;gap:12px;align-items:center;margin-bottom:16px}
.captcha-row input{flex:1;margin-bottom:0}
.captcha-question{background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:12px 20px;font-size:16px;font-weight:700;color:#00f3ff;white-space:nowrap;letter-spacing:1px;user-select:none}
</style>
</head>
<body>
<a href="/" class="back"><i class="fa-solid fa-arrow-left"></i> 返回首页</a>
<div class="box">
    <h1>加入 NIGHT RIDE</h1>
    <p class="subtitle">注册即送 100 音浪积分</p>
    <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
    <form method="post">
        <label>昵称</label>
        <input type="text" name="nickname" placeholder="给自己起个名字" required value="<?= h($_POST['nickname'] ?? '') ?>">

        <label>手机号</label>
        <input type="text" name="phone" placeholder="11位手机号" required value="<?= h($_POST['phone'] ?? '') ?>">

        <label>密码</label>
        <input type="password" name="password" placeholder="至少6位" required>

        <label>确认密码</label>
        <input type="password" name="password2" placeholder="再次输入密码" required>

        <label>验证码</label>
        <div class="captcha-row">
            <div class="captcha-question"><?= $captchaA ?> + <?= $captchaB ?> = ?</div>
            <input type="number" name="captcha" placeholder="输入答案" required value="<?= h($_POST['captcha'] ?? '') ?>">
        </div>

        <button type="submit">注 册</button>
    </form>
    <div class="links">已有账号？<a href="/login.php">立即登录</a></div>
</div>
</body>
</html>
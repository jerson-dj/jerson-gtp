<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';

$pdo = DB::conn();

$sqls = [
// VIP套餐
"CREATE TABLE IF NOT EXISTS `vip_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `level` int(11) DEFAULT 1,
  `days` int(11) DEFAULT 30,
  `price_integral` int(11) DEFAULT 0,
  `price_money` decimal(10,2) DEFAULT 0,
  `desc` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

// 充值卡
"CREATE TABLE IF NOT EXISTS `recharge_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_no` varchar(32) NOT NULL,
  `card_pwd` varchar(32) NOT NULL,
  `type` enum('integral','vip') DEFAULT 'integral',
  `amount` int(11) DEFAULT 0,
  `vip_plan_id` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0 COMMENT '0未用1已用',
  `used_by` int(11) DEFAULT 0,
  `used_at` int(11) DEFAULT 0,
  `batch_no` varchar(32) DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_no` (`card_no`),
  KEY `batch_no` (`batch_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

// 充值记录
"CREATE TABLE IF NOT EXISTS `recharge_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('integral','vip') DEFAULT 'integral',
  `amount` int(11) DEFAULT 0,
  `card_id` int(11) DEFAULT 0,
  `remark` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
];

foreach ($sqls as $sql) $pdo->exec($sql);

// 插入默认套餐
$exists = $pdo->query("SELECT COUNT(*) FROM vip_plan")->fetchColumn();
if ($exists == 0) {
    $plans = [
        ['月卡VIP', 1, 30, 500, 9.90, '30天VIP特权，文章免积分阅读', 1],
        ['季卡VIP', 2, 90, 1300, 25.00, '90天VIP特权，超值优惠', 2],
        ['年卡VIP', 3, 365, 4500, 88.00, '365天VIP特权，全年畅享', 3],
        ['终身VIP', 9, 36500, 15000, 298.00, '终身VIP，一次购买永久有效', 4],
    ];
    $stmt = $pdo->prepare("INSERT INTO vip_plan (name, level, days, price_integral, price_money, `desc`, sort, status, created_at) VALUES (?,?,?,?,?,?,?,1,?)");
    foreach ($plans as $p) {
        $stmt->execute([$p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $p[6], time()]);
    }
}

echo "✅ 建表完成<br>";
echo "已创建：vip_plan、recharge_card、recharge_log<br>";
echo "已插入 4 个默认 VIP 套餐<br>";
echo "<br><strong style='color:red;'>请立即删除 alter8.php</strong>";
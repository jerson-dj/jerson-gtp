<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';
session_start();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: /article_list.php'); exit; }

$article = DB::one("SELECT a.*, c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id WHERE a.id=? AND a.status=1", [$id]);
if (!$article) {
    echo '文章不存在或未发布';
    exit;
}

DB::exec("UPDATE article SET views = views + 1 WHERE id=?", [$id]);

// 读取开关
$cfg = [];
foreach (DB::query("SELECT * FROM setting") as $row) $cfg[$row['key']] = $row['value'];
$canLike    = ($cfg['like_enabled'] ?? '1') === '1';
$canComment = ($cfg['comment_enabled'] ?? '1') === '1';

// 收藏 / 点赞状态
$isFav = false;
$isLiked = false;
if (!empty($_SESSION['user_id'])) {
    $isFav = (bool)DB::one("SELECT id FROM user_favorite WHERE user_id=? AND article_id=?",
        [$_SESSION['user_id'], $article['id']]);
    $isLiked = (bool)DB::one("SELECT id FROM article_like WHERE user_id=? AND article_id=?",
        [$_SESSION['user_id'], $article['id']]);
}
$likeCount = DB::one("SELECT COUNT(*) c FROM article_like WHERE article_id=?", [$article['id']])['c'];
$commentCount = DB::one("SELECT COUNT(*) c FROM article_comment WHERE article_id=? AND status=1", [$article['id']])['c'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($article['title']) ?> - NIGHT RIDE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0a0a0f;color:#e0e0e0}
a{color:#00f3ff;text-decoration:none}
a:hover{text-decoration:underline}
.header{padding:20px 40px;background:rgba(10,10,15,.95);border-bottom:1px solid #1a1a2e;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;backdrop-filter:blur(10px)}
.logo{font-size:18px;font-weight:bold;color:#00f3ff}
.container{max-width:820px;margin:40px auto;padding:0 40px}
.article-title{font-size:32px;font-weight:700;margin-bottom:16px;line-height:1.3;color:#fff}
.article-meta{font-size:14px;color:#8a99ad;margin-bottom:32px;padding-bottom:20px;border-bottom:1px solid #21262d;display:flex;flex-wrap:wrap;align-items:center;gap:12px}
.article-meta span{margin-right:8px}
.article-audio{margin-bottom:28px;padding:20px;background:#161b22;border:1px solid #30363d;border-radius:12px}
.article-audio .audio-label{font-size:13px;color:#00f3ff;margin-bottom:12px;font-weight:600}
.article-audio audio{width:100%;}
.article-content{font-size:16px;line-height:1.9;color:#c9d1d9}
.article-content img{max-width:100%;border-radius:8px;margin:16px 0}
.article-content h2,.article-content h3{margin:24px 0 12px;color:#fff}
.article-content p{margin-bottom:16px}
.article-content ul,.article-content ol{margin:16px 0 16px 24px}
.article-content code{background:#161b22;padding:2px 6px;border-radius:4px;font-size:14px}
.article-content pre{background:#161b22;padding:16px;border-radius:8px;overflow-x:auto;margin:16px 0}
.article-content audio{width:100%;max-width:100%;margin:12px 0}
.back{margin-top:40px;display:inline-block}
.footer{text-align:center;padding:40px;color:#8a99ad;font-size:13px;border-top:1px solid #1a1a2e;margin-top:60px}

/* 点赞、收藏按钮 */
.action-btn-sm{padding:6px 14px;border-radius:6px;cursor:pointer;font-size:13px;border:1px solid #30363d;background:transparent;color:#8a99ad;transition:all .2s}
.action-btn-sm:hover{border-color:#00f3ff;color:#00f3ff}

/* 评论区 */
.comment-section{margin-top:40px;padding-top:32px;border-top:1px solid #21262d}
.comment-section h3{font-size:18px;color:#fff;margin-bottom:20px}
.comment-input{width:100%;padding:12px;background:#161b22;border:1px solid #30363d;border-radius:8px;color:#c9d1d9;font-size:14px;resize:vertical;outline:none;font-family:inherit}
.comment-input:focus{border-color:#00f3ff}
.comment-item{padding:16px 0;border-bottom:1px solid #21262d}
.comment-item:last-child{border-bottom:none}
.comment-avatar{width:40px;height:40px;border-radius:50%;flex-shrink:0;object-fit:cover}
.comment-body{flex:1;min-width:0}
.comment-name{color:#00f3ff;font-weight:600;font-size:14px}
.comment-time{font-size:12px;color:#8a99ad}
.comment-content{font-size:14px;color:#c9d1d9;line-height:1.7;margin:8px 0}
.comment-reply{margin-left:52px;margin-top:12px;padding:12px;background:#161b22;border-radius:8px}
.btn{padding:8px 20px;background:#00f3ff;color:#0a0a0f;border:none;border-radius:6px;font-weight:700;cursor:pointer;font-size:13px}
.btn:hover{background:#00b8e0}
</style>
</head>
<body>

<div class="header">
    <div class="logo">🎵 NIGHT RIDE / 车音坊</div>
    <a href="/">返回首页</a>
</div>

<div class="container">
    <h1 class="article-title"><?= h($article['title']) ?></h1>

    <div class="article-meta">
        <span>📁 <?= h($article['cate_name'] ?? '未分类') ?></span>
        <span>👤 <?= h($article['author'] ?: 'admin') ?></span>
        <span>📅 <?= date('Y-m-d H:i', $article['created_at']) ?></span>
        <span>👁 <?= $article['views'] ?> 阅读</span>

        <?php if ($canLike): ?>
        <button id="likeBtn" class="action-btn-sm" onclick="toggleLike(<?= $article['id'] ?>)"
            style="<?= $isLiked ? 'background:rgba(0,243,255,.15);border-color:#00f3ff;color:#00f3ff;' : '' ?>">
            👍 <span id="likeCount"><?= $likeCount ?></span>
        </button>
        <?php endif; ?>

        <?php if (!empty($_SESSION['user_id'])): ?>
        <button id="favBtn" class="action-btn-sm" onclick="toggleFav(<?= $article['id'] ?>)"
            style="<?= $isFav ? 'background:rgba(240,185,11,.15);border-color:#f0b90b;color:#f0b90b;' : '' ?>">
            <?= $isFav ? '⭐ 已收藏' : '☆ 收藏' ?>
        </button>
        <?php endif; ?>
    </div>

    <?php if (!empty($article['audio_url'])): ?>
    <div class="article-audio">
        <div class="audio-label">🎵 音频播放</div>
        <audio controls src="<?= h($article['audio_url']) ?>"></audio>
    </div>
    <?php endif; ?>

    <div class="article-content">
        <?= $article['content'] ?>
    </div>

    <!-- ========== 评论区 ========== -->
    <?php if ($canComment): ?>
    <div class="comment-section">
        <h3>💬 评论 (<span id="commentCount"><?= $commentCount ?></span>)</h3>

        <?php if (!empty($_SESSION['user_id'])): ?>
        <div style="margin-bottom:24px;">
            <textarea id="commentInput" class="comment-input" rows="3" placeholder="说点什么..." maxlength="500"></textarea>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px;">
                <span id="commentMsg" style="font-size:12px;color:#8a99ad;"></span>
                <button type="button" onclick="submitComment()" class="btn">发表评论</button>
            </div>
        </div>
        <?php else: ?>
        <p style="color:#8a99ad;font-size:14px;margin-bottom:24px;">请先 <a href="/login.php">登录</a> 后发表评论</p>
        <?php endif; ?>

        <div id="commentList">
        <?php
        $comments = DB::query(
            "SELECT c.*, u.nickname, u.avatar FROM article_comment c 
             LEFT JOIN user u ON c.user_id=u.id 
             WHERE c.article_id=? AND c.status=1 AND c.parent_id=0 
             ORDER BY c.id DESC LIMIT 50",
            [$article['id']]
        );
        foreach ($comments as $c):
            $replies = DB::query(
                "SELECT c.*, u.nickname, u.avatar FROM article_comment c 
                 LEFT JOIN user u ON c.user_id=u.id 
                 WHERE c.parent_id=? AND c.status=1 ORDER BY c.id ASC",
                [$c['id']]
            );
        ?>
        <div class="comment-item">
            <div style="display:flex;gap:12px;">
                <img class="comment-avatar" src="<?= h($c['avatar'] ?: 'https://ui-avatars.com/api/?name='.urlencode($c['nickname']).'&background=00f3ff&color=0a0a0f') ?>" alt="">
                <div class="comment-body">
                    <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
                        <span class="comment-name"><?= h($c['nickname']) ?></span>
                        <span class="comment-time"><?= date('Y-m-d H:i', $c['created_at']) ?></span>
                    </div>
                    <div class="comment-content"><?= nl2br(h($c['content'])) ?></div>
                    <?php if (!empty($_SESSION['user_id']) && $_SESSION['user_id'] == $c['user_id']): ?>
                    <a href="javascript:;" onclick="deleteComment(<?= $c['id'] ?>)" style="font-size:12px;color:#f85149;">删除</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php foreach ($replies as $r): ?>
            <div class="comment-reply">
                <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
                    <span class="comment-name" style="font-size:13px;"><?= h($r['nickname']) ?></span>
                    <span class="comment-time"><?= date('Y-m-d H:i', $r['created_at']) ?></span>
                </div>
                <div style="font-size:13px;color:#c9d1d9;line-height:1.6;"><?= nl2br(h($r['content'])) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>

        <?php if (empty($comments)): ?>
        <p style="color:#8a99ad;text-align:center;padding:40px;font-size:14px;">还没有评论，来抢沙发吧~</p>
        <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <a href="/article_list.php" class="back">← 返回文章列表</a>
</div>

<div class="footer">© 2026 NIGHT RIDE. 保留所有权利.</div>

<script>
// ===== 点赞 =====
function toggleLike(aid) {
    fetch('/api/like.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'article_id=' + aid
    })
    .then(r => r.json())
    .then(function(res) {
        if (!res.success) { alert(res.msg); return; }
        document.getElementById('likeCount').textContent = res.count;
        var btn = document.getElementById('likeBtn');
        if (res.liked) {
            btn.style.background = 'rgba(0,243,255,.15)';
            btn.style.borderColor = '#00f3ff';
            btn.style.color = '#00f3ff';
        } else {
            btn.style.background = 'transparent';
            btn.style.borderColor = '#30363d';
            btn.style.color = '#8a99ad';
        }
    });
}

// ===== 收藏 =====
function toggleFav(aid) {
    fetch('/api/favorite.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=toggle&article_id=' + aid
    })
    .then(r => r.json())
    .then(function(res) {
        if (res.success) {
            var btn = document.getElementById('favBtn');
            if (res.favorited) {
                btn.textContent = '⭐ 已收藏';
                btn.style.background = 'rgba(240,185,11,.15)';
                btn.style.borderColor = '#f0b90b';
                btn.style.color = '#f0b90b';
            } else {
                btn.textContent = '☆ 收藏';
                btn.style.background = 'transparent';
                btn.style.borderColor = '#30363d';
                btn.style.color = '#8a99ad';
            }
        } else { alert(res.msg); }
    });
}

// ===== 发表评论 =====
function submitComment() {
    var input = document.getElementById('commentInput');
    var content = input.value.trim();
    var msg = document.getElementById('commentMsg');

    if (!content) {
        msg.textContent = '请输入评论内容';
        msg.style.color = '#f85149';
        return;
    }

    msg.textContent = '提交中...';
    msg.style.color = '#8a99ad';

    var fd = new FormData();
    fd.append('action', 'add');
    fd.append('article_id', <?= (int)$article['id'] ?>);
    fd.append('content', content);

    console.log('提交评论：', {
        action: 'add',
        article_id: <?= (int)$article['id'] ?>,
        content: content
    });

    fetch('/api/comment.php', {
        method: 'POST',
        body: fd
    })
    .then(function(r) {
        console.log('HTTP 状态:', r.status);
        return r.text();
    })
    .then(function(text) {
        console.log('返回内容:', text);
        try {
            var res = JSON.parse(text);
            if (res.success) {
                msg.textContent = res.msg;
                msg.style.color = '#3fb950';
                input.value = '';
                if (!res.need_audit) {
                    setTimeout(function() { location.reload(); }, 1000);
                }
            } else {
                msg.textContent = res.msg;
                msg.style.color = '#f85149';
            }
        } catch (e) {
            msg.textContent = '服务器返回异常：' + text.substring(0, 100);
            msg.style.color = '#f85149';
        }
    })
    .catch(function(err) {
        console.error('请求失败：', err);
        msg.textContent = '网络错误：' + err.message;
        msg.style.color = '#f85149';
    });
}

// ===== 删除评论 =====
function deleteComment(id) {
    if (!confirm('确定删除这条评论？')) return;
    var fd = new FormData();
    fd.append('action', 'delete');
    fd.append('id', id);
    fetch('/api/comment.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(function(res) {
            if (res.success) location.reload();
            else alert(res.msg);
        });
}
</script>

</body>
</html>
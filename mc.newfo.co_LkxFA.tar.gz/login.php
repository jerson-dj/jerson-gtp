<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';
session_start();

if (!empty($_SESSION['user_id'])) { header('Location: /'); exit; }

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($phone) || empty($password)) {
        $msg = '请填写手机号和密码';
    } else {
        $user = DB::one("SELECT * FROM user WHERE phone=?", [$phone]);
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nickname'];
            $_SESSION['user_integral'] = $user['integral'];
            header('Location: /'); exit;
        } else {
            $msg = '手机号或密码错误';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>登录 - NIGHT RIDE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0a0a0f;color:#e0e0e0;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;
background-image:radial-gradient(circle at center, transparent 30%, rgba(8,10,18,.95) 90%),url('https://images.unsplash.com/photo-1508253730651-e5ace80a7025?auto=format&fit=crop&w=1920&q=80');
background-size:cover;background-position:center;background-blend-mode:multiply;}
.box{background:rgba(18,22,36,.75);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:40px;width:100%;max-width:400px;box-shadow:0 20px 60px rgba(0,0,0,.5);}
h1{font-size:24px;text-align:center;margin-bottom:8px;color:#fff}
.subtitle{text-align:center;color:#8a99ad;font-size:13px;margin-bottom:28px}
label{display:block;color:#8a99ad;font-size:13px;margin-bottom:6px}
input{width:100%;padding:12px 14px;background:#0d1117;border:1px solid #30363d;border-radius:8px;color:#e0e0e0;font-size:14px;margin-bottom:16px;outline:none;transition:border-color .2s}
input:focus{border-color:#00f3ff}
button{width:100%;padding:12px;background:linear-gradient(90deg,#00f3ff,#0077ff);color:#000;border:none;border-radius:8px;font-weight:700;font-size:15px;cursor:pointer;margin-top:4px}
button:hover{opacity:.9}
.msg{padding:10px 14px;background:rgba(248,81,73,.15);color:#f85149;border-radius:8px;font-size:13px;margin-bottom:16px;text-align:center}
.links{text-align:center;margin-top:20px;font-size:13px;color:#8a99ad}
.links a{color:#00f3ff;text-decoration:none}
.links a:hover{text-decoration:underline}
.back{position:absolute;top:24px;left:24px;color:#8a99ad;font-size:14px;text-decoration:none}
.back:hover{color:#00f3ff}
</style>
</head>
<body>
<a href="/" class="back"><i class="fa-solid fa-arrow-left"></i> 返回首页</a>
<div class="box">
    <h1>欢迎回来</h1>
    <p class="subtitle">登录 NIGHT RIDE 车音坊</p>
    <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
    <form method="post">
        <label>手机号</label>
        <input type="text" name="phone" placeholder="11位手机号" required value="<?= h($_POST['phone'] ?? '') ?>">

        <label>密码</label>
        <input type="password" name="password" placeholder="输入密码" required>

        <button type="submit">登 录</button>
    </form>
    <div class="links">还没有账号？<a href="/register.php">立即注册</a></div>
</div>
</body>
</html>
<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';

$pdo = DB::conn();
$cols = $pdo->query("SHOW COLUMNS FROM `admin`")->fetchAll(PDO::FETCH_COLUMN);
$adds = [];

if (!in_array('totp_secret', $cols)) {
    $adds[] = "ADD COLUMN `totp_secret` varchar(64) DEFAULT NULL COMMENT 'TOTP密钥' AFTER `password`";
}
if (!in_array('totp_enabled', $cols)) {
    $adds[] = "ADD COLUMN `totp_enabled` tinyint(1) DEFAULT 0 COMMENT '是否启用TOTP' AFTER `totp_secret`";
}

if (empty($adds)) {
    echo "✅ 字段已存在，无需操作";
} else {
    $pdo->exec("ALTER TABLE `admin` " . implode(', ', $adds));
    echo "✅ 已添加：" . implode(', ', array_map(function($s){
        preg_match('/ADD COLUMN `(\w+)`/', $s, $m); return $m[1];
    }, $adds));
}
echo "<br><br><strong style='color:red;'>请立即删除 alter4.php</strong>";
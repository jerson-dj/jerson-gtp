<?php
// ============================================
// NIGHT RIDE 车音坊 一键安装脚本
// 访问此文件即可自动生成所有文件和数据库表
// 安装完成后请立即删除本文件
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

$dbHost = 'localhost';
$dbName = 'nightride';
$dbUser = 'nightride';
$dbPass = 'nightride';   // ← 改成你的密码

// 数据库连接
try {
    $pdo = new PDO("mysql:host=$dbHost;charset=utf8mb4", $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` DEFAULT CHARSET utf8mb4");
    $pdo->exec("USE `$dbName`");
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 建表 SQL
$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastlogin` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `sort` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL,
  `content` longtext,
  `cover` varchar(255) DEFAULT NULL,
  `type` enum('article','audio','video') DEFAULT 'article',
  `status` tinyint(1) DEFAULT 1 COMMENT '1=已发布,0=待审核,2=草稿,3=已拒绝',
  `views` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cate_id` (`cate_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `audio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `artist` varchar(100) DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `file_url` varchar(500) DEFAULT NULL,
  `source_type` enum('local','external') DEFAULT 'local',
  `duration` int(11) DEFAULT 0,
  `file_size` int(11) DEFAULT 0,
  `format` varchar(20) DEFAULT 'mp3',
  `cate_id` int(11) DEFAULT 0,
  `sort` int(11) DEFAULT 0,
  `play_count` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cate_id` (`cate_id`),
  KEY `source_type` (`source_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `integral` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `integral_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `task_id` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `task_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_key` varchar(50) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  `task_desc` varchar(255) DEFAULT NULL,
  `integral` int(11) NOT NULL DEFAULT 0,
  `max_times` int(11) DEFAULT 1,
  `status` tinyint(1) DEFAULT 1,
  `sort` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_key` (`task_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `user_task_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `integral` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `setting` (
  `key` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `admin` (`username`, `password`) VALUES
('admin', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JuywdBqSf2V3jXw5W6u');

INSERT IGNORE INTO `category` (`name`, `slug`, `sort`) VALUES
('听车电台', 'radio', 1),
('音乐频道', 'music', 2),
('技术分享', 'tech', 3),
('车主社区', 'community', 4);

INSERT IGNORE INTO `task_config` (`task_key`, `task_name`, `task_desc`, `integral`, `max_times`, `sort`) VALUES
('post_create', '发布帖子', '发布包含爱车照片或车载音响调试的帖子', 150, 1, 1),
('post_like', '点赞帖子', '为喜欢的帖子点赞', 5, 10, 2),
('daily_login', '每日登录', '每天首次登录', 20, 1, 3),
('exchange_coupon', '兑换洗车券', '使用积分兑换合作门店洗车券', -500, 0, 4);
SQL;

foreach (explode(';', $sql) as $stmt) {
    $stmt = trim($stmt);
    if ($stmt) $pdo->exec($stmt);
}

// ========== 生成文件 ==========
$files = [];

$files['include/config.php'] = <<<'PHP'
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'nightride');
define('DB_USER', 'root');
define('DB_PASS', '你的数据库密码');
define('SITE_NAME', 'NIGHT RIDE 车音坊');
define('UPLOAD_DIR', __DIR__ . '/../uploads/audio/');
define('UPLOAD_URL', '/uploads/audio/');
PHP;

$files['include/db.php'] = <<<'PHP'
<?php
class DB {
    private static $pdo = null;
    public static function conn() {
        if (self::$pdo === null) {
            try {
                self::$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
            } catch (PDOException $e) { die('DB Error: '.$e->getMessage()); }
        }
        return self::$pdo;
    }
    public static function query($sql, $p=[]) { $s=self::conn()->prepare($sql); $s->execute($p); return $s->fetchAll(); }
    public static function one($sql, $p=[])   { $s=self::conn()->prepare($sql); $s->execute($p); return $s->fetch(); }
    public static function exec($sql, $p=[])  { $s=self::conn()->prepare($sql); $s->execute($p); return $s->rowCount(); }
    public static function insert($sql, $p=[]){ self::exec($sql,$p); return self::conn()->lastInsertId(); }
}
PHP;

$files['include/function.php'] = <<<'PHP'
<?php
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect($u){ header("Location: $u"); exit; }
function alert($m,$u=''){ echo "<script>alert('".addslashes($m)."');".($u?"location.href='$u';":"")."</script>"; exit; }
function fmtTime($t){ return $t ? date('Y-m-d H:i',$t) : '-'; }
function paginate($total,$page,$size,$url){
    $tp=ceil($total/$size); $h='<div class="pagination">';
    for($i=1;$i<=$tp;$i++){ $a=$i==$page?' class="active"':''; $h.="<a href=\"{$url}&page={$i}\"$a>$i</a>"; }
    return $h.'</div>';
}
function executeTask($userId,$taskKey){
    $task=DB::one("SELECT * FROM task_config WHERE task_key=? AND status=1",[$taskKey]);
    if(!$task) return ['success'=>false,'msg'=>'任务不存在','integral'=>0];
    if($task['max_times']>0){
        $c=DB::one("SELECT COUNT(*) c FROM user_task_log WHERE user_id=? AND task_id=? AND created_at>=?",[$userId,$task['id'],strtotime('today')])['c'];
        if($c>=$task['max_times']) return ['success'=>false,'msg'=>'今日已完成','integral'=>0];
    }
    DB::conn()->beginTransaction();
    try{
        DB::exec("UPDATE user SET integral=integral+? WHERE id=?",[$task['integral'],$userId]);
        DB::insert("INSERT INTO integral_log (user_id,amount,reason,task_id,created_at) VALUES (?,?,?,?,?)",[$userId,$task['integral'],$task['task_name'],$task['id'],time()]);
        DB::insert("INSERT INTO user_task_log (user_id,task_id,integral,created_at) VALUES (?,?,?,?)",[$userId,$task['id'],$task['integral'],time()]);
        DB::conn()->commit();
        return ['success'=>true,'msg'=>'完成','integral'=>$task['integral']];
    }catch(Exception $e){ DB::conn()->rollBack(); return ['success'=>false,'msg'=>$e->getMessage(),'integral'=>0]; }
}
PHP;

$files['include/auth.php'] = <<<'PHP'
<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/db.php';
require_once __DIR__.'/function.php';
session_start();
if(empty($_SESSION['admin_id'])) redirect('login.php');
PHP;

$files['admin/login.php'] = <<<'PHP'
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $u=$_POST['username']??''; $p=$_POST['password']??'';
    $a=DB::one("SELECT * FROM admin WHERE username=?",[$u]);
    if($a && password_verify($p,$a['password'])){
        $_SESSION['admin_id']=$a['id']; $_SESSION['admin_name']=$a['username'];
        DB::exec("UPDATE admin SET lastlogin=? WHERE id=?",[time(),$a['id']]);
        redirect('index.php');
    }
    $error='用户名或密码错误';
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>后台登录</title><link rel="stylesheet" href="../assets/style.css"></head>
<body class="login-page"><div class="login-box"><h2>NIGHT RIDE 后台</h2>
<?php if(!empty($error)):?><p class="error"><?=h($error)?></p><?php endif;?>
<form method="post"><input type="text" name="username" placeholder="用户名" required><input type="password" name="password" placeholder="密码" required><button type="submit">登录</button></form>
</div></body></html>
PHP;

$files['admin/logout.php'] = <<<'PHP'
<?php session_start(); session_destroy(); header('Location: login.php');
PHP;

$files['admin/index.php'] = <<<'PHP'
<?php
require_once __DIR__.'/../include/auth.php';
$action=$_GET['action']??'dashboard';
$do=$_GET['do']??'list';
$id=(int)($_GET['id']??0);

switch($action){
    case 'dashboard':
        $stats=[
            'article'=>DB::one("SELECT COUNT(*) c FROM article")['c'],
            'user'=>DB::one("SELECT COUNT(*) c FROM user")['c'],
            'audio'=>DB::one("SELECT COUNT(*) c FROM audio")['c'],
            'integral'=>DB::one("SELECT SUM(integral) s FROM user")['s']?:0,
        ];
        include __DIR__.'/view/dashboard.php'; break;

    case 'audio':
        if($do=='delete'&&$id){
            $a=DB::one("SELECT * FROM audio WHERE id=?",[$id]);
            if($a&&$a['source_type']=='local') @unlink(UPLOAD_DIR.basename($a['file_url']));
            DB::exec("DELETE FROM audio WHERE id=?",[$id]);
            alert('删除成功','index.php?action=audio');
        }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $st=$_POST['source_type']??'local'; $url='';
            if($st=='local'&&!empty($_FILES['audio_file']['tmp_name'])){
                $ext=strtolower(pathinfo($_FILES['audio_file']['name'],PATHINFO_EXTENSION));
                $ok=['mp3','wav','flac','aac','ogg','m4a'];
                if(!in_array($ext,$ok)) alert('格式不支持: '.implode(',',$ok));
                $fn=date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
                if(move_uploaded_file($_FILES['audio_file']['tmp_name'],UPLOAD_DIR.$fn)) $url=UPLOAD_URL.$fn;
                else alert('上传失败');
            } elseif($st=='external'){
                $url=trim($_POST['external_url']??'');
                if(!filter_var($url,FILTER_VALIDATE_URL)) alert('外部链接无效');
            }
            $dur=0;
            if($st=='local'&&$url&&function_exists('shell_exec')){
                $lp=UPLOAD_DIR.basename($url);
                $d=@shell_exec("ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 ".escapeshellarg($lp)." 2>/dev/null");
                $dur=(int)floatval($d);
            }
            $data=[$_POST['title'],$_POST['artist']??'',$_POST['cover']??'',$url,$st,$dur,0,strtolower(pathinfo($url,PATHINFO_EXTENSION))?:'mp3',(int)($_POST['cate_id']??0),(int)($_POST['sort']??0),(int)($_POST['status']??1)];
            if($id){ $data[]=$id; DB::exec("UPDATE audio SET title=?,artist=?,cover=?,file_url=?,source_type=?,duration=?,file_size=?,format=?,cate_id=?,sort=?,status=? WHERE id=?",$data); }
            else { $data[]=time(); DB::insert("INSERT INTO audio (title,artist,cover,file_url,source_type,duration,file_size,format,cate_id,sort,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",$data); }
            alert('保存成功','index.php?action=audio');
        }
        if($do=='edit'){ $audio=$id?DB::one("SELECT * FROM audio WHERE id=?",[$id]):null; $cates=DB::query("SELECT * FROM category ORDER BY sort"); include __DIR__.'/view/audio_edit.php'; break; }
        $page=max(1,(int)($_GET['page']??1)); $ps=20;
        $total=DB::one("SELECT COUNT(*) c FROM audio")['c'];
        $list=DB::query("SELECT a.*,c.name cate_name FROM audio a LEFT JOIN category c ON a.cate_id=c.id ORDER BY a.sort,a.id DESC LIMIT ".($page-1)*$ps.",$ps");
        include __DIR__.'/view/audio_list.php'; break;

    case 'post':
        if($do=='approve'&&$id){ DB::exec("UPDATE article SET status=1 WHERE id=?",[$id]); alert('已通过','index.php?action=post'); }
        if($do=='reject'&&$id){ DB::exec("UPDATE article SET status=3 WHERE id=?",[$id]); alert('已拒绝','index.php?action=post'); }
        $status=$_GET['status']??0;
        $page=max(1,(int)($_GET['page']??1)); $ps=15;
        $w=$status!==''?"WHERE a.status=".(int)$status:"";
        $total=DB::one("SELECT COUNT(*) c FROM article a $w")['c'];
        $list=DB::query("SELECT a.*,c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id $w ORDER BY a.id DESC LIMIT ".($page-1)*$ps.",$ps");
        include __DIR__.'/view/post_list.php'; break;

    case 'task':
        if($do=='delete'&&$id){ DB::exec("DELETE FROM task_config WHERE id=?",[$id]); alert('删除成功','index.php?action=task'); }
        if($do=='save'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $data=[$_POST['task_key'],$_POST['task_name'],$_POST['task_desc']??'',(int)$_POST['integral'],(int)$_POST['max_times'],(int)($_POST['status']??1),(int)($_POST['sort']??0)];
            if($id){ $data[]=$id; DB::exec("UPDATE task_config SET task_key=?,task_name=?,task_desc=?,integral=?,max_times=?,status=?,sort=? WHERE id=?",$data); }
            else { $data[]=time(); DB::insert("INSERT INTO task_config (task_key,task_name,task_desc,integral,max_times,status,sort,created_at) VALUES (?,?,?,?,?,?,?,?)",$data); }
            alert('保存成功','index.php?action=task');
        }
        if($do=='edit'){ $task=$id?DB::one("SELECT * FROM task_config WHERE id=?",[$id]):null; include __DIR__.'/view/task_config.php'; break; }
        $tasks=DB::query("SELECT * FROM task_config ORDER BY sort"); include __DIR__.'/view/task_config.php'; break;

    case 'user':
        if($do=='integral'&&$_SERVER['REQUEST_METHOD']==='POST'){
            $uid=(int)$_POST['uid']; $amt=(int)$_POST['amount']; $r=trim($_POST['reason']);
            if($uid&&$amt!=0){ DB::exec("UPDATE user SET integral=integral+? WHERE id=?",[$amt,$uid]); DB::insert("INSERT INTO integral_log (user_id,amount,reason,created_at) VALUES (?,?,?,?)",[$uid,$amt,$r,time()]); }
            alert('调整成功','index.php?action=user');
        }
        $users=DB::query("SELECT * FROM user ORDER BY id DESC LIMIT 200"); include __DIR__.'/view/user_list.php'; break;

    case 'integral':
        $logs=DB::query("SELECT l.*,u.nickname FROM integral_log l LEFT JOIN user u ON l.user_id=u.id ORDER BY l.id DESC LIMIT 300");
        include __DIR__.'/view/integral_list.php'; break;

    case 'setting':
        if($_SERVER['REQUEST_METHOD']==='POST'){ foreach($_POST as $k=>$v) DB::exec("REPLACE INTO setting (`key`,`value`) VALUES (?,?)",[$k,$v]); alert('保存成功','index.php?action=setting'); }
        $settings=[]; foreach(DB::query("SELECT * FROM setting") as $r) $settings[$r['key']]=$r['value'];
        include __DIR__.'/view/setting.php'; break;

    default: include __DIR__.'/view/dashboard.php';
}
PHP;

// 后台视图（header, footer, dashboard, audio_list, audio_edit, post_list, task_config, user_list, integral_list, setting）
// 因篇幅限制，这里仅列出核心几个，其余可参考上一轮完整代码
$files['admin/view/header.php'] = <<<'PHP'
<!DOCTYPE html><html><head><meta charset="utf-8"><title>后台</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="admin-wrap"><aside class="sidebar"><h2>NIGHT RIDE</h2><nav>
<a href="index.php?action=dashboard">仪表盘</a>
<a href="index.php?action=audio">音频管理</a>
<a href="index.php?action=post">帖子审核</a>
<a href="index.php?action=task">积分任务</a>
<a href="index.php?action=user">用户管理</a>
<a href="index.php?action=integral">积分流水</a>
<a href="index.php?action=setting">系统设置</a>
<a href="logout.php" class="logout">退出</a>
</nav></aside><main class="main">
PHP;
$files['admin/view/footer.php'] = <<<'PHP'
</main></div></body></html>
PHP;
$files['admin/view/dashboard.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>仪表盘</h1>
<div class="stats">
<div class="stat-card"><span>文章</span><strong><?=$stats['article']?></strong></div>
<div class="stat-card"><span>用户</span><strong><?=$stats['user']?></strong></div>
<div class="stat-card"><span>音频</span><strong><?=$stats['audio']?></strong></div>
<div class="stat-card"><span>积分总额</span><strong><?=$stats['integral']?></strong></div>
</div>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/audio_list.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>音频管理 <a href="index.php?action=audio&do=edit" class="btn">+ 添加</a></h1>
<table><thead><tr><th>ID</th><th>标题</th><th>来源</th><th>时长</th><th>播放</th><th>状态</th><th>操作</th></tr></thead><tbody>
<?php foreach($list as $r):?><tr>
<td><?=$r['id']?></td><td><?=h($r['title'])?><br><small><?=h($r['artist'])?></small></td>
<td><span class="badge <?=$r['source_type']=='local'?'badge-green':'badge-blue'?>"><?=$r['source_type']=='local'?'本地':'外链'?></span></td>
<td><?=$r['duration']?gmdate('i:s',$r['duration']):'-'?></td><td><?=$r['play_count']?></td>
<td><?=$r['status']?'上架':'下架'?></td>
<td><a href="index.php?action=audio&do=edit&id=<?=$r['id']?>">编辑</a> | <a href="index.php?action=audio&do=delete&id=<?=$r['id']?>" onclick="return confirm('删除？')">删除</a></td>
</tr><?php endforeach;?></tbody></table>
<?=paginate($total,$page,$ps,'index.php?action=audio')?>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/audio_edit.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1><?=$audio?'编辑':'添加'?>音频</h1>
<form method="post" class="form-box" enctype="multipart/form-data" action="index.php?action=audio&do=save<?=$id?'&id='.$id:''?>">
<label>标题<input type="text" name="title" value="<?=h($audio['title']??'')?>" required></label>
<label>艺术家<input type="text" name="artist" value="<?=h($audio['artist']??'')?>"></label>
<label>封面URL<input type="text" name="cover" value="<?=h($audio['cover']??'')?>"></label>
<label>分类<select name="cate_id"><?php foreach($cates as $c):?><option value="<?=$c['id']?>" <?=($audio['cate_id']??0)==$c['id']?'selected':''?>><?=h($c['name'])?></option><?php endforeach;?></select></label>
<label>来源<select name="source_type" id="st" onchange="toggle()"><option value="local" <?=($audio['source_type']??'local')=='local'?'selected':''?>>本地上传</option><option value="external" <?=($audio['source_type']??'')=='external'?'selected':''?>>外部链接</option></select></label>
<div id="local" style="display:<?=($audio['source_type']??'local')=='local'?'block':'none'?>"><label>文件<input type="file" name="audio_file" accept="audio/*"></label><?php if(!empty($audio['file_url'])&&$audio['source_type']=='local'):?><audio controls src="<?=h($audio['file_url'])?>" style="width:100%"></audio><?php endif;?></div>
<div id="ext" style="display:<?=($audio['source_type']??'')=='external'?'block':'none'?>"><label>链接<input type="text" name="external_url" value="<?=h($audio['source_type']=='external'?$audio['file_url']:'')?>" placeholder="https://..."></label><?php if(!empty($audio['file_url'])&&$audio['source_type']=='external'):?><audio controls src="<?=h($audio['file_url'])?>" style="width:100%"></audio><?php endif;?></div>
<label>排序<input type="number" name="sort" value="<?=h($audio['sort']??0)?>"></label>
<label>状态<select name="status"><option value="1" <?=($audio['status']??1)==1?'selected':''?>>上架</option><option value="0" <?=($audio['status']??1)==0?'selected':''?>>下架</option></select></label>
<button type="submit" class="btn">保存</button></form>
<script>function toggle(){var v=document.getElementById('st').value;document.getElementById('local').style.display=v=='local'?'block':'none';document.getElementById('ext').style.display=v=='external'?'block':'none';}</script>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/post_list.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>帖子审核</h1>
<div class="tabs">
<a href="index.php?action=post&status=0" class="<?=($status??0)==0?'active':''?>">待审核</a>
<a href="index.php?action=post&status=1" class="<?=($status??0)==1?'active':''?>">已通过</a>
<a href="index.php?action=post&status=3" class="<?=($status??0)==3?'active':''?>">已拒绝</a>
<a href="index.php?action=post&status=" class="<?=($status??'')===''?'active':''?>">全部</a></div>
<table><thead><tr><th>ID</th><th>标题</th><th>分类</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody>
<?php foreach($list as $r):?><tr>
<td><?=$r['id']?></td><td><?=h($r['title'])?></td><td><?=h($r['cate_name']??'-')?></td>
<td><?php if($r['status']==0):?><span class="badge badge-yellow">待审</span><?php elseif($r['status']==1):?><span class="badge badge-green">通过</span><?php elseif($r['status']==3):?><span class="badge badge-red">拒绝</span><?php endif;?></td>
<td><?=fmtTime($r['created_at'])?></td>
<td><?php if($r['status']==0):?><a href="index.php?action=post&do=approve&id=<?=$r['id']?>" class="btn-sm">通过</a> <a href="index.php?action=post&do=reject&id=<?=$r['id']?>" class="btn-sm btn-danger" onclick="return confirm('拒绝？')">拒绝</a><?php endif;?></td>
</tr><?php endforeach;?></tbody></table>
<?=paginate($total,$page,$ps,'index.php?action=post&status='.$status)?>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/task_config.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>积分任务配置</h1>
<div class="two-col"><div><table><thead><tr><th>ID</th><th>标识</th><th>名称</th><th>积分</th><th>上限</th><th>状态</th><th>操作</th></tr></thead><tbody>
<?php foreach($tasks as $t):?><tr>
<td><?=$t['id']?></td><td><code><?=h($t['task_key'])?></code></td><td><?=h($t['task_name'])?></td>
<td class="<?=$t['integral']>0?'plus':'minus'?>"><?=$t['integral']>0?'+':''?><?=$t['integral']?></td>
<td><?=$t['max_times']?:'不限'?></td><td><?=$t['status']?'启用':'禁用'?></td>
<td><a href="index.php?action=task&do=edit&id=<?=$t['id']?>">编辑</a> | <a href="index.php?action=task&do=delete&id=<?=$t['id']?>" onclick="return confirm('删除？')">删除</a></td>
</tr><?php endforeach;?></tbody></table></div>
<div class="form-box"><h3><?=$task?'编辑':'新增'?>任务</h3>
<form method="post" action="index.php?action=task&do=save<?=$task?'&id='.$task['id']:''?>">
<label>标识<input type="text" name="task_key" value="<?=h($task['task_key']??'')?>" required></label>
<label>名称<input type="text" name="task_name" value="<?=h($task['task_name']??'')?>" required></label>
<label>描述<input type="text" name="task_desc" value="<?=h($task['task_desc']??'')?>"></label>
<label>积分<input type="number" name="integral" value="<?=h($task['integral']??0)?>" required></label>
<label>每日上限<input type="number" name="max_times" value="<?=h($task['max_times']??1)?>"></label>
<label>排序<input type="number" name="sort" value="<?=h($task['sort']??0)?>"></label>
<label>状态<select name="status"><option value="1" <?=($task['status']??1)==1?'selected':''?>>启用</option><option value="0" <?=($task['status']??1)==0?'selected':''?>>禁用</option></select></label>
<button type="submit" class="btn">保存</button></form></div></div>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/user_list.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>用户管理</h1>
<table><thead><tr><th>ID</th><th>昵称</th><th>手机</th><th>积分</th><th>操作</th></tr></thead><tbody>
<?php foreach($users as $u):?><tr>
<td><?=$u['id']?></td><td><?=h($u['nickname'])?></td><td><?=h($u['phone'])?></td><td><?=$u['integral']?></td>
<td><form method="post" action="index.php?action=user&do=integral" class="inline-form"><input type="hidden" name="uid" value="<?=$u['id']?>"><input type="number" name="amount" placeholder="±积分" required><input type="text" name="reason" placeholder="原因"><button class="btn-sm">调整</button></form></td>
</tr><?php endforeach;?></tbody></table>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/integral_list.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>积分流水</h1>
<table><thead><tr><th>ID</th><th>用户</th><th>变动</th><th>原因</th><th>时间</th></tr></thead><tbody>
<?php foreach($logs as $l):?><tr>
<td><?=$l['id']?></td><td><?=h($l['nickname']??'未知')?></td>
<td class="<?=$l['amount']>0?'plus':'minus'?>"><?=$l['amount']>0?'+':''?><?=$l['amount']?></td>
<td><?=h($l['reason'])?></td><td><?=fmtTime($l['created_at'])?></td>
</tr><?php endforeach;?></tbody></table>
<?php include __DIR__.'/footer.php';?>
PHP;
$files['admin/view/setting.php'] = <<<'PHP'
<?php include __DIR__.'/header.php';?><h1>系统设置</h1>
<form method="post" class="form-box">
<label>网站名称<input type="text" name="site_name" value="<?=h($settings['site_name']??'NIGHT RIDE')?>"></label>
<label>发帖积分<input type="number" name="post_integral" value="<?=h($settings['post_integral']??150)?>"></label>
<label>兑换门槛<input type="number" name="exchange_min" value="<?=h($settings['exchange_min']??500)?>"></label>
<button type="submit" class="btn">保存</button></form>
<?php include __DIR__.'/footer.php';?>
PHP;

// 前台文件
$files['index.php'] = <<<'PHP'
<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';
require_once __DIR__.'/include/function.php';
session_start();
$audios=DB::query("SELECT * FROM audio WHERE status=1 ORDER BY sort,id DESC LIMIT 20");
$posts=DB::query("SELECT a.*,c.name cate_name FROM article a LEFT JOIN category c ON a.cate_id=c.id WHERE a.status=1 ORDER BY a.id DESC LIMIT 10");
$cates=DB::query("SELECT * FROM category ORDER BY sort");
?>
<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NIGHT RIDE / 车音坊</title><link rel="stylesheet" href="assets/front.css"></head><body>
<header class="front-header"><div class="logo">🎵 NIGHT RIDE / 车音坊</div><div class="search-box"><input type="text" placeholder="搜索电台、频道或车主..."></div><div class="header-right"><span class="points">⚡ 积分: <?=$_SESSION['user_integral']??2480?></span><a href="admin/login.php" class="btn-login">登录/注册</a></div></header>
<nav class="front-nav"><?php foreach($cates as $c):?><a href="#"><?=h($c['name'])?></a><?php endforeach;?></nav>
<section class="hero"><div class="hero-content"><h1>深夜车舱避风港<br>海量无损 DJ 随心享</h1><p>专为车主打造的沉浸式音浪空间。分享你的爱车故事获取音浪积分，免费解锁 24BIT/96KHZ 车载顶级舞曲，享受全国合作门店养车优惠。</p>
<?php if(!empty($audios)): $f=$audios[0];?>
<div class="audio-player"><div class="player-cover"><?php if($f['cover']):?><img src="<?=h($f['cover'])?>" alt=""><?php else:?><span>🎧</span><?php endif;?></div><div class="player-info"><div class="player-title"><?=h($f['title'])?> <span class="tag-hot">热播</span></div><div class="player-artist"><?=h($f['artist']?:'驻场 DJ')?></div><audio controls id="audioEl" style="width:100%;margin-top:6px;"><source src="<?=h($f['file_url'])?>" type="audio/mpeg"></audio></div></div>
<?php endif;?></div>
<aside class="side-cards"><div class="card"><div class="card-header"><span>📝 发帖晒车 → 领DJ专辑</span><span class="tag-points">+150积分</span></div><p>发布 1 条包含爱车照片或车载音响调试的帖子，即可免费下载《深夜跑山特调DJ包》。</p><a href="post.php" class="btn-primary">+ 立即发帖领积分</a></div>
<div class="card"><div class="card-header"><span>🔧 合作门店养车券</span><span class="tag-points">可抵扣</span></div><p>使用 500 音浪积分，兑换周边合作门店【精细洗车/全车镀膜/小保养】专属折扣。</p><a href="exchange.php" class="btn-danger">500积分兑换洗车券</a></div></aside></section>
<section class="post-section"><h2>车主社区</h2><div class="post-grid"><?php foreach($posts as $p):?><a href="post_view.php?id=<?=$p['id']?>" class="post-card"><div class="post-cate"><?=h($p['cate_name']??'社区')?></div><h3><?=h($p['title'])?></h3><div class="post-meta"><?=fmtTime($p['created_at'])?> · <?=$p['views']?> 阅读</div></a><?php endforeach;?></div></section>
<footer class="front-footer"><p>© 2026 NIGHT RIDE. 保留所有权利.</p><p>粤ICP备2026000000号-1 | 隐私政策 | 服务条款 | 联系我们</p></footer>
<script>document.querySelectorAll('.audio-item').forEach(function(el){el.addEventListener('click',function(){var url=this.dataset.url;document.getElementById('audioEl').src=url;document.getElementById('audioEl').play();});});</script>
</body></html>
PHP;

$files['api/submit_post.php'] = <<<'PHP'
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){ echo json_encode(['success'=>false,'msg'=>'无效请求']); exit; }
$title=trim($_POST['title']??''); $content=trim($_POST['content']??''); $cateId=(int)($_POST['cate_id']??0);
if(empty($title)||empty($content)){ echo json_encode(['success'=>false,'msg'=>'标题和内容不能为空']); exit; }
$id=DB::insert("INSERT INTO article (cate_id,title,content,type,status,created_at) VALUES (?,?,?,'article',0,?)",[$cateId,$title,$content,time()]);
echo json_encode(['success'=>true,'msg'=>'提交成功，等待审核','id'=>$id]);
PHP;

$files['api/get_audios.php'] = <<<'PHP'
<?php
require_once __DIR__.'/../include/config.php';
require_once __DIR__.'/../include/db.php';
require_once __DIR__.'/../include/function.php';
header('Content-Type: application/json; charset=utf-8');
$cateId=(int)($_GET['cate_id']??0);
$sql="SELECT id,title,artist,cover,file_url,source_type,duration,play_count FROM audio WHERE status=1";
$p=[]; if($cateId){ $sql.=" AND cate_id=?"; $p[]=$cateId; }
$sql.=" ORDER BY sort,id DESC LIMIT 50";
echo json_encode(['data'=>DB::query($sql,$p)]);
PHP;

$files['assets/style.css'] = <<<'CSS'
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0d1117;color:#c9d1d9}
a{color:#00d4ff;text-decoration:none}a:hover{text-decoration:underline}
.login-page{display:flex;justify-content:center;align-items:center;height:100vh;background:#0d1117}
.login-box{background:#161b22;padding:40px;border-radius:12px;width:360px;border:1px solid #30363d}
.login-box h2{text-align:center;margin-bottom:24px;color:#00d4ff;font-size:20px}
.login-box input{width:100%;padding:12px;margin-bottom:16px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9}
.login-box button{width:100%;padding:12px;background:#00d4ff;border:none;border-radius:6px;font-weight:bold;color:#0d1117;cursor:pointer}
.error{color:#f85149;margin-bottom:12px;text-align:center}
.admin-wrap{display:flex;min-height:100vh}
.sidebar{width:220px;background:#161b22;border-right:1px solid #30363d;padding:24px 0;position:fixed;height:100vh;overflow-y:auto}
.sidebar h2{font-size:16px;color:#00d4ff;padding:0 24px 20px;border-bottom:1px solid #30363d;margin-bottom:12px}
.sidebar nav a{display:block;padding:10px 24px;color:#8b949e;border-left:3px solid transparent}
.sidebar nav a:hover{color:#00d4ff;background:#0d1117;text-decoration:none;border-left-color:#00d4ff}
.sidebar nav a.logout{margin-top:20px;color:#f85149}
.main{flex:1;margin-left:220px;padding:32px 40px}
h1{font-size:22px;margin-bottom:24px;display:flex;align-items:center;gap:16px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-bottom:32px}
.stat-card{background:#161b22;padding:20px;border-radius:10px;border:1px solid #30363d}
.stat-card span{display:block;color:#8b949e;font-size:13px;margin-bottom:8px}
.stat-card strong{font-size:26px;color:#00d4ff}
table{width:100%;border-collapse:collapse;background:#161b22;border-radius:10px;overflow:hidden;border:1px solid #30363d}
th,td{padding:12px 16px;text-align:left;border-bottom:1px solid #21262d;font-size:14px}
th{background:#0d1117;color:#8b949e;font-weight:600}
tr:last-child td{border-bottom:none}.plus{color:#3fb950}.minus{color:#f85149}
.form-box{background:#161b22;padding:24px;border-radius:10px;border:1px solid #30363d;max-width:800px}
.form-box label{display:block;margin-bottom:16px;color:#8b949e;font-size:14px}
.form-box input,.form-box select,.form-box textarea{width:100%;margin-top:6px;padding:10px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#c9d1d9;font-size:14px}
.btn{display:inline-block;padding:8px 18px;background:#00d4ff;color:#0d1117;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:14px}
.btn:hover{background:#00b8e0;text-decoration:none}
.btn-sm{padding:5px 12px;font-size:13px;background:#00d4ff;color:#0d1117;border:none;border-radius:4px;cursor:pointer}
.btn-danger{background:#f85149;color:#fff}
.inline-form{display:inline-flex;gap:6px;align-items:center}
.inline-form input{padding:5px 8px;font-size:13px}
.two-col{display:grid;grid-template-columns:1fr 380px;gap:24px}
.pagination{margin-top:20px;display:flex;gap:6px}
.pagination a{padding:6px 12px;background:#161b22;border:1px solid #30363d;border-radius:4px;color:#8b949e}
.pagination a.active{background:#00d4ff;color:#0d1117;border-color:#00d4ff}
.badge{display:inline-block;padding:2px 10px;border-radius:4px;font-size:12px}
.badge-green{background:rgba(63,185,80,.15);color:#3fb950}
.badge-blue{background:rgba(0,212,255,.15);color:#00d4ff}
.badge-yellow{background:rgba(240,185,11,.15);color:#f0b90b}
.badge-red{background:rgba(248,81,73,.15);color:#f85149}
.tabs{display:flex;gap:8px;margin-bottom:20px}
.tabs a{padding:8px 16px;border-radius:6px;color:#8b949e;background:#161b22;border:1px solid #30363d}
.tabs a.active{background:#00d4ff;color:#0d1117;border-color:#00d4ff}
CSS;

$files['assets/front.css'] = <<<'CSS'
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0a0a0f;color:#e0e0e0}
a{color:#00d4ff;text-decoration:none}
.front-header{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:rgba(10,10,15,.95);backdrop-filter:blur(10px);position:sticky;top:0;z-index:100;border-bottom:1px solid #1a1a2e}
.logo{font-size:18px;font-weight:bold;color:#00d4ff}
.search-box input{width:400px;padding:10px 16px;background:#161b22;border:1px solid #30363d;border-radius:8px;color:#e0e0e0}
.header-right{display:flex;align-items:center;gap:16px}
.points{color:#f0b90b;font-weight:600}
.btn-login{padding:8px 18px;background:#00d4ff;color:#0a0a0f;border-radius:6px;font-weight:600}
.front-nav{display:flex;gap:8px;padding:12px 40px;background:#0a0a0f;border-bottom:1px solid #1a1a2e}
.front-nav a{padding:8px 16px;border-radius:6px;color:#8b949e;font-size:14px}
.front-nav a.active,.front-nav a:hover{background:#161b22;color:#00d4ff}
.hero{display:grid;grid-template-columns:1fr 380px;gap:40px;padding:60px 40px;background:linear-gradient(135deg,#0a0a0f 0%,#1a1025 50%,#0a0a0f 100%);min-height:70vh}
.hero-content h1{font-size:42px;line-height:1.3;margin-bottom:20px;background:linear-gradient(90deg,#fff,#00d4ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero-content p{color:#8b949e;margin-bottom:32px;line-height:1.8}
.audio-player{display:flex;gap:20px;background:rgba(22,27,34,.8);backdrop-filter:blur(10px);padding:20px;border-radius:16px;border:1px solid #30363d;max-width:600px}
.player-cover{width:80px;height:80px;border-radius:12px;background:#1a1a2e;display:flex;align-items:center;justify-content:center;font-size:32px;overflow:hidden;flex-shrink:0}
.player-cover img{width:100%;height:100%;object-fit:cover}
.player-info{flex:1}
.player-title{font-size:16px;font-weight:600;margin-bottom:4px}
.tag-hot{font-size:11px;background:#f85149;color:#fff;padding:2px 6px;border-radius:4px;margin-left:6px}
.player-artist{font-size:13px;color:#8b949e;margin-bottom:8px}
.side-cards{display:flex;flex-direction:column;gap:20px}
.card{background:rgba(22,27,34,.8);backdrop-filter:blur(10px);border:1px solid #30363d;border-radius:16px;padding:24px}
.card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;font-weight:600}
.tag-points{font-size:13px;color:#f0b90b}
.card p{color:#8b949e;font-size:14px;line-height:1.6;margin-bottom:16px}
.btn-primary{display:block;text-align:center;padding:12px;background:#00d4ff;color:#0a0a0f;border-radius:8px;font-weight:600}
.btn-danger{display:block;text-align:center;padding:12px;background:linear-gradient(90deg,#f85149,#ff6b6b);color:#fff;border-radius:8px;font-weight:600}
.post-section{padding:40px}
.post-section h2{margin-bottom:24px}
.post-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px}
.post-card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:20px;transition:border-color .2s}
.post-card:hover{border-color:#00d4ff}
.post-cate{font-size:12px;color:#00d4ff;margin-bottom:8px}
.post-card h3{font-size:16px;margin-bottom:12px}
.post-meta{font-size:12px;color:#8b949e}
.front-footer{text-align:center;padding:32px;color:#8b949e;font-size:13px;border-top:1px solid #1a1a2e}
CSS;

// 写入文件
$baseDir = __DIR__;
foreach ($files as $path => $content) {
    $full = $baseDir . '/' . $path;
    $dir = dirname($full);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents($full, $content);
}

// 创建上传目录
if (!is_dir($baseDir . '/uploads/audio')) mkdir($baseDir . '/uploads/audio', 0755, true);

echo "<h1>✅ 安装完成</h1>";
echo "<p>已生成所有文件和数据库表。</p>";
echo "<p><strong>前台：</strong> <a href='/' target='_blank'>http://你的域名/</a></p>";
echo "<p><strong>后台：</strong> <a href='/admin/login.php' target='_blank'>http://你的域名/admin/login.php</a>（账号 admin / 密码 admin123）</p>";
echo "<p style='color:red;'>⚠️ 请立即删除本文件 install.php，避免安全风险。</p>";
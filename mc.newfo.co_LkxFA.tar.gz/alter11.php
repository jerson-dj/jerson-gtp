<?php
require_once __DIR__.'/include/config.php';
require_once __DIR__.'/include/db.php';

$pdo = DB::conn();
$cols = $pdo->query("SHOW COLUMNS FROM `user`")->fetchAll(PDO::FETCH_COLUMN);

$adds = [];
if (!in_array('id_card', $cols))      $adds[] = "ADD COLUMN `id_card` varchar(20) DEFAULT NULL COMMENT '身份证号' AFTER `real_name`";
if (!in_array('verify_time', $cols))  $adds[] = "ADD COLUMN `verify_time` int(11) DEFAULT 0 COMMENT '认证时间' AFTER `is_verified`";
if (!in_array('phone_verified', $cols)) $adds[] = "ADD COLUMN `phone_verified` tinyint(1) DEFAULT 0 COMMENT '手机是否验证' AFTER `phone`";

if (empty($adds)) {
    echo "✅ 字段已存在，无需操作";
} else {
    $pdo->exec("ALTER TABLE `user` " . implode(', ', $adds));
    echo "✅ 已添加 " . count($adds) . " 个字段：<br>";
    foreach ($adds as $s) {
        preg_match('/ADD COLUMN `(\w+)`/', $s, $m);
        echo "- {$m[1]}<br>";
    }
}
echo "<br><br><strong style='color:red;'>请立即删除 alter11.php</strong>";